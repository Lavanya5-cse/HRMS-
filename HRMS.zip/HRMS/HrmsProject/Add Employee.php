<?php include ("connection.php");?>

<!DOCTYPE html>
<html>

<head>
   <meta charset="UTF-8">
   <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
   <title>Grexa - Admin Dashboard Template</title>
   <!-- General CSS Files -->
   <link rel="stylesheet" href="assets/css/app.min.css">
   <!-- Template CSS -->
   <link rel="stylesheet" href="assets/css/style.css">
   <link rel="stylesheet" href="assets/css/components.css">
   <!-- Custom style CSS -->
   <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.ico' />
   <script async src="https://www.googletagmanager.com/gtag/js?id=UA-94034622-3"></script>
</head>

<body>
   <div class="loader"></div>
   <div id="app">
      <div class="main-wrapper main-wrapper-1">
         <div class="navbar-bg"></div>
         <nav class="navbar navbar-expand-lg main-navbar">
            <div class="form-inline mr-auto">
               <ul class="navbar-nav mr-3">
                  <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg collapse-btn"><i
                           class="fas fa-bars"></i></a></li>
               </ul>
            </div>
         </nav>
         <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <div class="sidebar-brand">
            <a href="index.php">
              <img alt="image" src="assets/img/logo.png" class="header-logo" />
              <span class="logo-name">Grexa</span>
            </a>
          </div>
          <ul class="sidebar-menu">
            <li class="menu-header">Main</li>
            <li class="dropdown">
              <a href="#" class="nav-link has-dropdown"><i class="fas fa-home"></i><span>Dashboard</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="index.php">Admin Dashboard</a></li>
               </ul>
            </li>
         
            <li class="dropdown active">
              <a href="#" class="nav-link has-dropdown"><i class="fas fa-leaf"></i><span>Employee
                  </span></a>
              <ul class="dropdown-menu">
                <li class=""><a class="nav-link" href="Employee dashboard.php">Employee Dashboard</a></li>
                <li class="active"><a class="nav-link" href="Add Employee.php">Add Employee</a></li>
               </ul>
            </li>
            <li class="dropdown">
              <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Leaves</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="Apply leave.php">Apply Leave</a></li>
                <li><a class="nav-link" href="Leave list.php">Leave List</a></li>
              </ul>
            </li>
            <li class="dropdown">
              <a href="#" class="nav-link has-dropdown"><i class="fas fa-anchor"></i><span> Project</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link active" href="Project lists.php">Project lists</a></li>
                <li><a class="nav-link" href="Projects_page.php">Projects</a></li>

              </ul>
            </li>
            
            <li class="dropdown ">
              <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Tickets</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="Tickets list.php">Tickets list</a></li>
                
              </ul>
            </li>
  <li class="dropdown">
    <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Payroll</span></a>
    <ul class="dropdown-menu">
      <li><a class="nav-link" href="Employee salary.php">Employee salary</a></li>
      <li><a class="nav-link" href="payslip.php">payslip</a></li>
      
    </ul>
  </li>
  <li class="dropdown">
    <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Clients</span></a>
    <ul class="dropdown-menu">
      <li><a class="nav-link active" href="Clients_page.php">Client form</a></li>
      
    </ul>
  </li>
  <li class="dropdown">
    <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Leads</span></a>
    <ul class="dropdown-menu">
      <li><a class="nav-link" href="Leads.php">Leads</a></li>
      
    </ul>
  </li>
  
  <li class="dropdown">
    <a href="#" class="nav-link has-dropdown"><i class="fas fa-hand-point-down"></i><span>Assets</span></a>
    <ul class="dropdown-menu">
     <li>  <a class="nav-link" href="Assests.php">Assets</a></li>
    </ul>
    </li>
      


  <li class="dropdown">
    <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Performance</span></a>
    <ul class="dropdown-menu">
      <li><a class="nav-link" href="performance indicator.php">Performance Indicator</a></li>
      <li><a class="nav-link" href="performance Review.php">Performance Review</a></li>
      <li><a class="nav-link" href="performance Appraisal.php">Performance Appraisal  </a></li>
      
    </ul>
  </li>
  <li class="dropdown">
    <a href="#" class="nav-link has-dropdown"><i class="fas fa-crosshairs"></i><span>Goals</span></a>
    <ul class="dropdown-menu">
      <li><a class="nav-link" href="goals-list.php">Goal List</a></li>
      <li><a class="nav-link" href="goals-type.php">Goal type</a></li>
       
    </ul>
    </li>
    <li class="dropdown">
      <a href="#" class="nav-link has-dropdown"><i class="fas fa-pencil-alt"></i><span>Training</span></a>
      <ul class="dropdown-menu">
        <li class=""><a class="nav-link" href="training-list.php">Training List</a></li>
        <li><a class="nav-link" href="Trainers.php">Trainers</a></li>
         
      </ul>
      </li>
      <li class="dropdown">
        <a href="#" class="nav-link has-dropdown"><i class="fas fa-clipboard-check"></i><span>Jobs</span></a>
        <ul class="dropdown-menu">
          <li><a class="nav-link" href="job-dashboard.php">Jobs dashboard</a></li>
          <li><a class="nav-link" href="job-manage.php">ManageJobs</a></li>
          <li><a class="nav-link" href="job-resume.php">Manage Resumes</a></li>

        </ul>
        </li>
        <li class="dropdown">
          <a href="#" class="nav-link has-dropdown"><i class="fas fa-user-tie"></i><span>Interviews</span></a>
          <ul class="dropdown-menu">
            <li><a class="nav-link active" href="interview-shortlist.php">Shortlist Candidates</a></li>
            <li><a class="nav-link" href="interview-schedule.php">Schedule time</a></li>
            <li><a class="nav-link" href="interview-offer.php">Offer  Approvals </a></li>
           </ul>
          </li>
          
                    <li class="dropdown">
                      <a href="#" class="nav-link has-dropdown"><i class="far fa-file-alt"></i><span>Special Pages</span></a>
                      <ul class="dropdown-menu">
                        
                        
                        <li><a class="nav-link" href="policies.php">Policies</a></li>
        <li><a class="nav-link" href="FAQ.php">FAQ</a></li>
                        <li><a class="nav-link" href="Terms of service.php">Terms Of Services</a></li>
                       
                      </ul>
                    </li>
                   
</ul>
                  </aside>
        
      </div>
         <!-- Main Content -->
         <div class="main-content">
            <section class="section">
               <div class="section-header">
                  <h1>Employee Profiles</h1>
                  <div class="section-header-breadcrumb">
                     <div class="breadcrumb-item active"><a href="index.php">Dashboard</a></div>
                     <div class="breadcrumb-item"><a href="Employee dashboard.php">Employee Dashboard</a></div>
                     <div class="breadcrumb-item"><a href="Add Employee.php"> Add Employee</a></div>
                  </div>
               </div>
            </section>
            <section class="section">
               <div class="section-body">
                  <div class="row">
                     <div class="col-12 col-md-12 col-lg-12  ">
                        <div class="card">
                           <div class="card-body">
                              <button type="button" class="btn btn-info " data-toggle="modal" data-target="#basicModal">
                                 + Add New Profile
                              </button>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <div class="modal fade" id="basicModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
               aria-hidden="true">
               <div class="modal-dialog  modal-dialog-centered modal-lg" role="document">
                  <div class="modal-content">
                     <div class="modal-header">
                        <h5 class="modal-title">Enter new employee</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                        </button>
                     </div>
                     <div class="modal-body">
                        <div class="card ">
                           <div class="card-body">
                              <form action="addemployee.php" method="post">
                                 <div class="row" style="margin-bottom:30px">
                                 <div class="col-md-8">
                                 <label class=" form-label"> Company Name</label>
                  <input type="text" class="form-control"  
                     name="cmpny">
</div>    </div>                      
<div class="row" style="margin-bottom:30px">
                                 <div class="col-md-8">
                                 <label class=" form-label">Name</label>
                  <input type="text" class="form-control"  
                     name="empname">
</div>    </div>         
<div class="row" style="margin-bottom:30px">
                                 <div class="col-md-8">
                                 <label class=" form-label">Department</label>
                  <input type="text" class="form-control"  
                     name="dept">
</div>    </div>            
<div class="row" style="margin-bottom:30px">
<div class="col-md-12">
<button type="submit" class="btn btn-primary"
                 >Submit</button>
               <button type="button" class="btn btn-secondary"
                  data-dismiss="modal">Close</button> 
                  </div>    </div>                       
                                     </form>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="container">
            <div class="row">
            <?php
                           $mysql="select * from addemp";
                           $query=mysqli_query($con,$mysql);
                           while($data=mysqli_fetch_assoc($query)){
                              ?>
                  <div class="col-sm-4">
                     <div class="card">
                        <div class="card-body">
                        
                           <div class="text-center">
                              <img class="rounded-circle  " src="assets/img/users/user-1.png" width="90px"
                                 height="90px">
                           </div>
                           <h5 class=" mt-4 mb-0 d-block text-center"> <?php echo $data["Company"];?></h5>
                           <div class="  lead d-block text-center"><?php echo $data["Name"];?></div>
                           <div class=" text-muted  d-block text-center"><?php echo $data["Department"];?></div>
                           <div class="text-center "><a href="#"
                                 class="btn btn-white btn-sm me-1 ms-1 text-center mt-3 border">Message</a></div>
                           <div class="text-center "><a href="Add Employee1.php"
                                 class="btn btn-white btn-sm ms-1  mt-3 border">View Profile</a></div>
                                
                           
                        </div>

                     </div>
                  </div>
              
               <!--   <div class="col-sm-4">
                     <div class="card">
                        <div class="card-body">
                           <div class="text-center">
                              <img class="rounded-circle  " src="assets/img/users/user-1.png" width="90px"
                                 height="90px">
                           </div>
                           <h5 class=" mt-4 mb-0 d-block text-center">Global Technologies</h5>
                           <div class="  lead d-block text-center">Revanth Raj</div>
                           <div class=" text-muted  d-block text-center">IT Dept</div>
                           <div class="text-center "><a href="#"
                                 class="btn btn-white btn-sm me-1 ms-1 text-center mt-3 border">Message</a></div>
                           <div class="text-center "><a href="Add Employee1.php"
                                 class="btn btn-white btn-sm ms-1  mt-3 border">View Profile</a></div>
                        </div>
                     </div>
                  </div>
                  <div class="col-sm-4">
                     <div class="card ">
                        <div class="card-body">
                           <div class="text-center">
                              <img class="rounded-circle  " src="assets/img/users/user-2.png" width="90px"
                                 height="90px">
                           </div>
                           <h5 class=" mt-4 mb-0 d-block text-center">Global Technologies</h5>
                           <div class="  lead d-block text-center">Ditya Patel</div>
                           <div class=" text-muted  d-block text-center">Sales Dept</div>
                           <div class="text-center "><a href="#"
                                 class="btn btn-white btn-sm me-1 ms-1 text-center mt-3 border">Message</a></div>
                           <div class="text-center "><a href="Add Employee1.php"
                                 class="btn btn-white btn-sm ms-1  mt-3 border">View Profile</a></div>
                        </div>
                     </div>
                  </div>
                           </div>-->
                           <?php
                           }?>
               </div>
             
               </div>
            </div>
            <div class="settingSidebar">
               <a href="javascript:void(0)" class="settingPanelToggle"> <i class="fa fa-spin fa-cog"></i>
               </a>
               <div class="settingSidebar-body ps-container ps-theme-default">
                  <div class=" fade show active">
                     <div class="setting-panel-header">Theme Customizer</div>
                     <div class="p-15 border-bottom">
                        <h6 class="font-medium m-b-10">Theme Layout</h6>
                        <div class="selectgroup layout-color w-50">
                           <label> <span class="control-label p-r-20">Light</span>
                              <input type="radio" name="custom-switch-input" value="1" class="custom-switch-input"
                                 checked> <span class="custom-switch-indicator"></span>
                           </label>
                        </div>
                        <div class="selectgroup layout-color  w-50">
                           <label> <span class="control-label p-r-20">Dark&nbsp;</span>
                              <input type="radio" name="custom-switch-input" value="2" class="custom-switch-input">
                              <span class="custom-switch-indicator"></span>
                           </label>
                        </div>
                     </div>
                  </div>
                  <div class="p-15 border-bottom">
                     <h6 class="font-medium m-b-10">Sidebar Colors</h6>
                     <div class="sidebar-setting-options">
                        <ul class="sidebar-color list-unstyled mb-0">
                           <li title="white" class="active">
                              <div class="white"></div>
                           </li>
                           <li title="blue">
                              <div class="blue"></div>
                           </li>
                           <li title="coral">
                              <div class="coral"></div>
                           </li>
                           <li title="purple">
                              <div class="purple"></div>
                           </li>
                           <li title="allports">
                              <div class="allports"></div>
                           </li>
                           <li title="barossa">
                              <div class="barossa"></div>
                           </li>
                           <li title="fancy">
                              <div class="fancy"></div>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="p-15 border-bottom">
                     <h6 class="font-medium m-b-10">Theme Colors</h6>
                     <div class="theme-setting-options">
                        <ul class="choose-theme list-unstyled mb-0">
                           <li title="white" class="active">
                              <div class="white"></div>
                           </li>
                           <li title="blue">
                              <div class="blue"></div>
                           </li>
                           <li title="coral">
                              <div class="coral"></div>
                           </li>
                           <li title="purple">
                              <div class="purple"></div>
                           </li>
                           <li title="allports">
                              <div class="allports"></div>
                           </li>
                           <li title="barossa">
                              <div class="barossa"></div>
                           </li>
                           <li title="fancy">
                              <div class="fancy"></div>
                           </li>
                           <li title="cyan">
                              <div class="cyan"></div>
                           </li>
                           <li title="orange">
                              <div class="orange"></div>
                           </li>
                           <li title="green">
                              <div class="green"></div>
                           </li>
                           <li title="red">
                              <div class="red"></div>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="p-15 border-bottom">
                     <h6 class="font-medium m-b-10">Layout Options</h6>
                     <div class="theme-setting-options">
                        <label> <span class="control-label p-r-20">Compact
                              Sidebar Menu</span> <input type="checkbox" name="custom-switch-checkbox"
                              class="custom-switch-input" id="mini_sidebar_setting"> <span
                              class="custom-switch-indicator"></span>
                        </label>
                     </div>
                  </div>
                  <div class="mt-3 mb-3 align-center">
                     <a href="#" class="btn btn-icon icon-left btn-outline-primary btn-restore-theme">
                        <i class="fas fa-undo"></i> Restore Default
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <!--------------------mainwrap div-->
         <footer class="main-footer">
            <div class="footer-left">
               Copyright &copy; 2022
               <div class="bullet"></div>
               Design By <a href="#">Snkthemes</a>
            </div>
            <div class="footer-right">
            </div>
         </footer>
      </div>
   </div>
   <!-- General JS Scripts -->
   <script src="assets/js/app.min.js"></script>
   <!-- JS Libraies -->
   <!-- Page Specific JS File -->
   <!-- Template JS File -->
   <script src="assets/js/scripts.js"></script>
</body>
<script>
   /* country*/
   $("#country10").change(function () {
      $("#country10 option:selected").each(function () {
         if ($(this).prop('selected')) {
            var drop = this.value;
            console.log("selected country" + drop);
         }
      });
   });
   /* state*/
   $("#state10").change(function () {
      $("#state10 option:selected").each(function () {
         if ($(this).prop('selected')) {
            var drop = this.value;
            console.log("selected state" + drop);
         }
      });
   });
   /* religion*/
   $("#Religion10").change(function () {
      $("#Religion10 option:selected").each(function () {
         if ($(this).prop('selected')) {
            var drop = this.value;
            console.log("selected Religion" + drop);
         }
      });
   });

   $("#sub10").click(function () {
      $(".error").hide();
      var ename = $("#name10").val();
      var email_pattern = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
      var email1 = $("#email10").val();
      var error = false;
      var phone = $("#mob10").val();
      var country = $("#country10").val();
      var birth = $("#birthday10").val();
      var state = $("#state10").val();
      var passport = $("#pass10").val();
      var gender = document.getElementsByName('gen');
      var aadhar = $("#adhar10").val();
      var pan = $("#pan10").val();
      var city = $("#city10").val();
      var Religion = $("#Religion10").val();
      var tempaddress = $("#paddress10").val();
      var permanentaddress = $("#nadd10").val();
      var emrgcyname = $("#ename10").val();
      var emrgcycontact = $("#econtact10").val();
      var emrgcyadd = $("#eadd10").val();
      var emrgcyname1 = $("#sname10").val();
      var emrgcycontact1 = $("#scontact10").val();
      var emrgcyadd1 = $("#sadd10").val();
      var school = $("#school10").val();
      var Intermediate = $("#inter10").val();
      var Graduate = $("#graduate10").val();
      var PostGraduate = $("#pg10").val();
      var Projects = $("#project10").val();
      var sscobtain = $("#sccob10").val();
      var interobtain = $("#inter0b10").val();
      var graduateobtain = $("#graduateob10").val();
      var postgraduateobtain = $("#pgob10").val();
      var bank = $("#bank10").val();
      var AccountNumber = $("#bkacctno10").val();
      var Branch = $("#branch10").val();
      var FullBankName = $("#bkname10").val();
      var IFCCode = $("#ifsc10").val();
      var bankCode = $("#bkcode10").val();

      var joiningdate = $("#joining10").val();
      var JoiningPosition = $("#position10").val();
      var EmployeeId = $("#empid10").val();
      var Emailid = $("#offemail10").val();
      var ManagerName = $("#manager10").val();
      var ProjectName = $("#projectname10").val();

      var PfNumber = $("#pf10").val();
      var PFAccountName = $("#pfacct10").val();
      var UANNumber = $("#uan10").val();
      var PFBranch = $("#pfbranch10").val();
      var ESINumber = $("#esi10").val();
      var ESIBranch = $("#esibranch10").val();




      console.log("name" + ename);

      if (ename == '') {
         $("#name10").after('<div class="error" style="color:red">Please enter full name</div>')
         error = true;
      }

      if (email1 == '') {
         $("#email10").after('<div class="error" style="color:red;">Please enter your email</div>')
         error = true;
      }
      if (!email_pattern.test(email1)) {
         $("#email10").after('<div class="error" style="color:red;">Please enter your valid email</div>')
         error = true;
      }
      if (phone == '') {
         $("#mob10").after('<div class="error" style="color:red">Please enter mobile number</div>')
         error = true;
      }
      if ((phone.length > 10) || (phone.length < 10) && (phone.length != 0)) {
         $("#mob10").after('<div class="error" style="color:red">Please enter 10 digit valid mobile number</div>')
         error = true;
      }
      if (country == "") {
         $("#country10").after('<div class="error" style="color:red">please select country</div>')
         error = true;
      }
      if (state == "") {
         $("#state10").after('<div class="error" style="color:red">please select state</div>')
         error = true;
      }
      if (birth == "") {
         $("#birthday10").after('<div class="error" style="color:red">Please select birthday</div>')
         error = true;
      }
      if (passport == "") {
         $("#pass10").after('<div class="error" style="color:red">Please enter passport number</div>')
         error = true;
      }
      if ((passport.length > 12) || (passport.length < 12) && (passport.length != 0)) {
         $("#pass10").after('<div class="error" style="color:red">Please enter 12 digit valid passport number</div>')
         error = true;
      }
      if (!(gender[0].checked || gender[1].checked)) {
         $("#female").after('<div class="error" style="color:red;">Please enter your Gender</div>')
         error = true;
      }
      if (aadhar == "") {
         $("#adhar10").after('<div class="error" style="color:red">Please enter aadhar number</div>')
         error = true;
      }
      if ((aadhar.length > 12) || (aadhar.length < 12) && (aadhar.length != 0)) {
         $("#adhar10").after('<div class="error" style="color:red">Please enter 12 digit valid aadhar number</div>')
         error = true;
      }
      if (pan == "") {
         $("#pan10").after('<div class="error" style="color:red">Please enter valid pan number</div>')
         error = true;
      }
      if (city == "") {
         $("#city10").after('<div class="error" style="color:red">Please enter your city name</div>')
         error = true;
      }
      if (Religion == "") {
         $("#Religion10").after('<div class="error" style="color:red">Please select religion</div>')
         error = true;
      }
      if (tempaddress == "") {
         $("#paddress10").after('<div class="error" style="color:red">Please enter temporary address</div>')
         error = true;
      }
      if (permanentaddress == "") {
         $("#nadd10").after('<div class="error" style="color:red">Please enter permanent address</div>')
         error = true;
      }
      if (emrgcyname == "") {
         $("#ename10").after('<div class="error" style="color:red">Please enter emergency contact name </div>')
         error = true;
      }
      if (emrgcycontact == "") {
         $("#econtact10").after('<div class="error" style="color:red">Please enter contact number</div>')
         error = true;
      }
      if ((emrgcycontact.length > 10) || (emrgcycontact.length < 10) && (emrgcycontact.length != 0)) {
         $("#econtact10").after('<div class="error" style="color:red">Please enter 10 digit valid mob number</div>')
         error = true;
      }
      if (emrgcyadd == "") {
         $("#eadd10").after('<div class="error" style="color:red">Please enter emergency contact address</div>')
         error = true;
      }
      if (emrgcyname1 == "") {
         $("#sname10").after('<div class="error" style="color:red">Please enter emergency contact name </div>')
         error = true;
      }
      if (emrgcycontact1 == "") {
         $("#scontact10").after('<div class="error" style="color:red">Please enter contact number</div>')
         error = true;
      }
      if ((emrgcycontact1.length > 10) || (emrgcycontact1.length < 10) && (emrgcycontact1.length != 0)) {
         $("#scontact10").after('<div class="error" style="color:red">Please enter 10 digit valid mob number</div>')
         error = true;
      }
      if (emrgcyadd1 == "") {
         $("#sadd10").after('<div class="error" style="color:red">Please enter emergency contact address</div>')
         error = true;
      }
      if (school == "") {
         $("#school10").after('<div class="error" style="color:red">Please enter your school name</div>')
         error = true;
      }
      if (Intermediate == "") {
         $("#inter10").after('<div class="error" style="color:red">Please enter your college name</div>')
         error = true;
      }
      if (Graduate == "") {
         $("#graduate10").after('<div class="error" style="color:red">Please enter your college name</div>')
         error = true;
      }
      if (PostGraduate == "") {
         $("#pg10").after('<div class="error" style="color:red">Please enter your college name</div>')
         error = true;
      }
      if (Projects == "") {
         $("#project10").after('<div class="error" style="color:red">Please enter your project name</div>')
         error = true;
      }
      if (sscobtain == '') {
         $("#sccob10").after('<div class="error" style="color:red">Please enter ssc percentage </div>')
         error = true;
      }
      if (interobtain == '') {
         $("#inter0b10").after('<div class="error" style="color:red">Please enter inter percentage </div>')
         error = true;
      }
      if (graduateobtain == '') {
         $("#graduateob10").after('<div class="error" style="color:red">Please enter graduate percentage </div>')
         error = true;
      }
      if (postgraduateobtain == '') {
         $("#pgob10").after('<div class="error" style="color:red">Please enter postgraduate percentage </div>')
         error = true;
      }
      if (bank == '') {
         $("#bank10").after('<div class="error" style="color:red">Please enter bank name </div>')
         error = true;
      }
      if (AccountNumber == '') {
         $("#bkacctno10").after('<div class="error" style="color:red">Please enter bank account number </div>')
         error = true;
      }
      if (Branch == '') {
         $("#branch10").after('<div class="error" style="color:red">Please enter branch location </div>')
         error = true;
      }
      if (FullBankName == '') {
         $("#bkname10").after('<div class="error" style="color:red">Please enter bank full name </div>')
         error = true;
      }
      if (IFCCode == '') {
         $("#ifsc10").after('<div class="error" style="color:red">Please enter ifsc code </div>')
         error = true;
      }
      if (bankCode == '') {
         $("#bkcode10").after('<div class="error" style="color:red">Please enter bank code  </div>')
         error = true;
      }
      if (joiningdate == '') {
         $("#joining10").after('<div class="error" style="color:red">Please select joining date  </div>')
         error = true;
      }
      if (JoiningPosition == '') {
         $("#position10").after('<div class="error" style="color:red">Please enter position  </div>')
         error = true;
      }
      if (EmployeeId == '') {
         $("#empid10").after('<div class="error" style="color:red">Please enter employee id  </div>')
         error = true;
      }
      if (Emailid == '') {
         $("#offemail10").after('<div class="error" style="color:red">Please enter company email id  </div>')
         error = true;
      }
      if (!email_pattern.test(Emailid)) {
         $("#offemail10").after('<div class="error" style="color:red;">Please enter your valid email</div>')
         error = true;
      }
      if (ManagerName == '') {
         $("#manager10").after('<div class="error" style="color:red">Please enter manager name  </div>')
         error = true;
      }
      if (ProjectName == '') {
         $("#projectname10").after('<div class="error" style="color:red">Please enter recent project name  </div>')
         error = true;
      }


      if (PfNumber == '') {
         $("#pf10").after('<div class="error" style="color:red">Please enter pf number  </div>')
         error = true;
      }
      if (PFAccountName == '') {
         $("#pfacct10").after('<div class="error" style="color:red">Please enter pf account name name  </div>')
         error = true;
      }
      if (UANNumber == '') {
         $("#uan10").after('<div class="error" style="color:red">Please enter uan number  </div>')
         error = true;
      }
      if (PFBranch == '') {
         $("#pfbranch10").after('<div class="error" style="color:red">Please enter pf branch location  </div>')
         error = true;
      }
      if (ESINumber == '') {
         $("#esi10").after('<div class="error" style="color:red">Please enter esi number  </div>')
         error = true;
      }
      if (ESIBranch == '') {
         $("#esibranch10").after('<div class="error" style="color:red">Please enter esi branch name </div>')
         error = true;
      }

      if (error == true) {
         return false;
      }
   });
</script>

</html>