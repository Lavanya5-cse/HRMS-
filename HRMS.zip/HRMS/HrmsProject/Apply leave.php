<!DOCTYPE html>
<html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
      <title>Grexa - Admin Dashboard Template</title>
      <!-- General CSS Files -->
      <link rel="stylesheet" href="assets/css/app.min.css">
      <!-- Template CSS -->
      <link rel="stylesheet" href="assets/css/style.css">
      <link rel="stylesheet" href="assets/css/components.css">
      <!-- Custom style CSS -->
      <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.ico' />
      <script async src="https://www.googletagmanager.com/gtag/js?id=UA-94034622-3"></script>
   </head>
   <body>
      <div class="loader"></div>
      <div id="app">
         <div class="main-wrapper main-wrapper-1">
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar">
               <div class="form-inline mr-auto">
                  <ul class="navbar-nav mr-3">
                     <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg collapse-btn"><i
                        class="fas fa-bars"></i></a></li>
                  </ul>
               </div>
            </nav>
            <div class="main-sidebar sidebar-style-2">
               <aside id="sidebar-wrapper">
                  <div class="sidebar-brand">
                     <a href="index.html">
                     <img alt="image" src="assets/img/logo.png" class="header-logo" />
                     <span class="logo-name">Grexa</span>
                     </a>
                  </div>
                  <ul class="sidebar-menu">
                  <li class="menu-header">Main</li>
                  <li class="dropdown">
                     <a href="#" class="nav-link has-dropdown"><i class="fas fa-home"></i><span>Dashboard</span></a>
                     <ul class="dropdown-menu">
                        <li><a class="nav-link" href="index.php">Admin Dashboard</a></li>
                     </ul>
                  </li>
                  <li class="dropdown ">
                     <a href="#" class="nav-link has-dropdown"><i class="fas fa-leaf"></i><span>Employee
                     </span></a>
                     <ul class="dropdown-menu">
                        <li class=""><a class="nav-link" href="Employee dashboard.php">Employee Dashboard</a></li>
                        <li><a class="nav-link" href="Add Employee.php">Add Employee</a></li>
                     </ul>
                  </li>
                  <li class="dropdown active">
                     <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Leaves</span></a>
                     <ul class="dropdown-menu">
                        <li class="active"><a class="nav-link" href="Apply leave.php">Apply Leave</a></li>
                        <li><a class="nav-link" href="Leave list.php">Leave List</a></li>
                     </ul>
                  </li>
                  <li class="dropdown">
                     <a href="#" class="nav-link has-dropdown"><i class="fas fa-anchor"></i><span> Project</span></a>
                     <ul class="dropdown-menu">
                        <li><a class="nav-link active" href="Project lists.php">Project lists</a></li>
                        <li><a class="nav-link" href="Projects_page.php">Projects</a></li>
                     </ul>
                  </li>
                  <li class="dropdown ">
                     <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Tickets</span></a>
                     <ul class="dropdown-menu">
                        <li><a class="nav-link" href="Tickets list.php">Tickets list</a></li>
                     </ul>
                  </li>
                  <li class="dropdown ">
                     <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Payroll</span></a>
                     <ul class="dropdown-menu">
                        <li><a class="nav-link" href="Employee salary.php">Employee salary</a></li>
                        <li><a class="nav-link" href="payslip.html">payslip</a></li>
                     </ul>
                  </li>
                  <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Clients</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="Clients_page.php">Client form</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Leads</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Leads.php">Leads</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-hand-point-down"></i><span>Assets</span></a>
         <ul class="dropdown-menu">
         <li>  <a class="nav-link" href="Assests.php">Assets</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Performance</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="performance indicator.php">Performance Indicator</a></li>
         <li><a class="nav-link" href="performance Review.php">Performance Review</a></li>
         <li><a class="nav-link" href="performance Appraisal.php">Performance Appraisal  </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-crosshairs"></i><span>Goals</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="goals-list.php">Goal List</a></li>
         <li><a class="nav-link" href="goals-type.php">Goal type</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-pencil-alt"></i><span>Training</span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="training-list.php">Training List</a></li>
         <li><a class="nav-link" href="Trainers.php">Trainers</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-clipboard-check"></i><span>Jobs</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="job-dashboard.php">Jobs dashboard</a></li>
         <li><a class="nav-link" href="job-manage.php">ManageJobs</a></li>
         <li><a class="nav-link" href="job-resume.php">Manage Resumes</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-user-tie"></i><span>Interviews</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="interview-shortlist.php">Shortlist Candidates</a></li>
         <li><a class="nav-link" href="interview-schedule.php">Schedule time</a></li>
         <li><a class="nav-link" href="interview-offer.php">Offer  Approvals </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-file-alt"></i><span>Special Pages</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="policies.php">Policies</a></li>
         <li><a class="nav-link" href="FAQ.php">FAQ</a></li>
         <li><a class="nav-link" href="Terms of service.php">Terms Of Services</a></li>
         </ul>
         </li>
               </aside>
            </div>
            <!-- Main Content -->
            <div class="main-content">
               <section class="section">
                  <div class="section-header">
                     <h1>Leaves</h1>
                     <div class="section-header-breadcrumb">
                        <div class="breadcrumb-item active"><a href="index.php">Dashboard</a></div>
                        <div class="breadcrumb-item"> Apply Leave</div>
                        <div class="breadcrumb-item"><a href="Leave list.php"> Leave list</a></div>
                     </div>
                  </div>
               </section>
               <section class="section">
                  <div class="section-body">
                     <div class="row">
                        <div class="col-12 col-md-12 col-lg-12  ">
                           <div class="card">
                              <div class="card-body">
                                 <button type="button" class="btn btn-info " data-toggle="modal"
                                    data-target="#basicModal">
                                 + Employee Leave
                                 </button>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </section>
               <div class="modal fade" id="basicModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                  aria-hidden="true">
                  <div class="modal-dialog" role="document">
                     <div class="modal-content">
                        <div class="modal-header">
                           <h5 class="modal-title" id="exampleModalLabel">Add Leave</h5>
                           <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                           </button>
                        </div>
                        <div class="modal-body">
                           <div class="card-body">
                              <form action="applyLeave.php" method="post">
                                 <div class="row">
                                    <div class="col-md-12">
                                       <div class="row">
                                          <div class="col-md-5">
                                             <div class="form-group row">
                                                <label class=" col-form-label">Emp Name</label>
                                                <input type="text" class="form-control" id="ename" name="empname">
                                             </div>
                                             <div class="form-group row">
                                                <label class="col-form-label">Leave Type</label><br> 
                                                <select class="form-control" id="pleave" name="type">
                                                   <option  value=""></option>
                                                   <option  value="Casual">Casual Leave</option>
                                                   <option  value="Earn">Earn Leave</option>
                                                   <option  value="Loss">Loss Of Pay</option>
                                                </select>
                                             </div>
                                             <div class="form-group row">
                                                <label class=" col-form-label">Todate</label>
                                                <input type="date" class="form-control" id="pdate" name="to">
                                             </div>
                                              
                                             <div class="form-group row">
                                                <label class=" col-form-label">Reason</label>
                                                <input type="text" class="form-control" id="preason" name="reason">
                                             </div>
                                             <div class="form-group row">
                                                <label class=" col-form-label">	Approved by</label>
                                                <input type="text" class="form-control" id="approved" name="approved">
                                             </div>
                                          </div>
                                          <div class="col-md-1" ></div>
                                          <div class="col-md-5">
                                             <div class="form-group row">
                                                <label class="col-form-label">Employee ID</label>
                                                <input type="text" class="form-control"  id="pid" name="id">
                                             </div>
                                             <div class="form-group row">
                                                <label class=" col-form-label">Fromdate</label>
                                                <input type="date" class="form-control" id="pform" name="from">
                                             </div>
                                             <div class="form-group row">
                                                <label class=" col-form-label">Days</label>
                                                <input type="number" class="form-control" id="pday" name="days">
                                             </div>
                                             <div class="form-group row">
                                                <label class="col-form-label">Status</label><br> 
                                                <select class="form-control" id="status10" name="status">
                                                   <option value=""></option>
                                                   <option  value="Rejected">Rejected</option>
                                                   <option  value="Pending">Pending</option>
                                                   <option  value="Accepted">Accepted</option>
                                                </select>
                                             </div>
                                              
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="text-right">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                 </div>
                                 <!---------------------------------->
                              </form>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="container">
                  <div class="row">
                     <div class="col-sm-3">
                        <div class="card">
                           <div class="card-body">
                              <p>Today Presents</p>
                              <h5>12 / 5</h5>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-3">
                        <div class="card ">
                           <div class="card-body">
                              <p>Planned Leaves</p>
                              <h5>8 <span>Today</span></h5>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-3">
                        <div class="card ">
                           <div class="card-body">
                              <p>Unplanned Leaves</p>
                              <h5>1 <span>Today</span></h5>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-3">
                        <div class="card">
                           <div class="card-body">
                              <p>Pending Requests</p>
                              <h5>12</h5>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="container">
                  <div class="row">
                     <div class="col-sm-2">
                        <div class="form-group ">
                           <input type="text" class="form-control " placeholder="Emp Name"> 
                        </div>
                     </div>
                     <div class="col-sm-2">
                        <div class="form-group ">
                           <select class="form-control" placeholder="Leave Type">
                              <option>-Select leave-</option>
                              <option>Casual Leave</option>
                              <option>Medical Leave</option>
                              <option>Earn Leave</option>
                              <option>Loss Of Pay</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-sm-2">
                        <div class="form-group ">
                           <select class="form-control" placeholder="Status">
                              <option>-leave status-</option>
                              <option>Approved</option>
                              <option>Pending</option>
                              <option>Rejected</option>
                           </select>
                        </div>
                     </div>
                     <div class="col-sm-2">
                        <div class="form-group ">
                           <input type="date" class="form-control " placeholder="From"> 
                        </div>
                     </div>
                     <div class="col-sm-2">
                        <div class="form-group ">
                           <input type="date" class="form-control " placeholder="To"> 
                        </div>
                     </div>
                     <div class="col-sm-2">
                        <button type="submit" class="btn  btn-lg btn-success">Search</button>
                     </div>
                  </div>
               </div>
               <div class="container">
                  <div class="row">
                     <div class="col-md-12">
                        <div class="card">
                           <div class="card-header">
                              <div class="text-center">
                                 <h4>Holiday List of Jan 2012</h4>
                              </div>
                           </div>
                           <div class="card-body">
                              <div class="col-sm-12">
                                 <table class="table table-bordered table-striped table-hover">
                                    <thead>
                                       <tr class="info  bg-light ">
                                          <th class="text-center">Date</th>
                                          <th class="text-center">Month</th>
                                          <th class="text-center">Day</th>
                                       </tr>
                                    </thead>
                                    <tbody>
                                       <tr class="text-center">
                                          <td>
                                             <h5>1<small>st</small> </h5>
                                          </td>
                                          <td>January</td>
                                          <td>New Year/Saturday</td>
                                       </tr>
                                       <tr class="text-center">
                                          <td>
                                             <h5>2<small>st</small> </h5>
                                          </td>
                                          <td>January</td>
                                          <td>Sunday</td>
                                       </tr>
                                       <tr class="text-center">
                                          <td>
                                             <h5>8<small>th</small> </h5>
                                          </td>
                                          <td>January</td>
                                          <td>Saturday</td>
                                       </tr>
                                       <tr class="text-center">
                                          <td>
                                             <h5>9<small>th</small> </h5>
                                          </td>
                                          <td>January</td>
                                          <td>Sunday</td>
                                       </tr>
                                       <tr class="text-center">
                                          <td>
                                             <h5>15<small>th</small> </h5>
                                          </td>
                                          <td>January</td>
                                          <td>Saturday</td>
                                       </tr>
                                       <tr class="text-center">
                                          <td>
                                             <h5>16<small>th</small> </h5>
                                          </td>
                                          <td>January</td>
                                          <td>Sunday</td>
                                       </tr>
                                       <tr class="text-center">
                                          <td>
                                             <h5>22<small>th</small> </h5>
                                          </td>
                                          <td>January</td>
                                          <td>Saturday</td>
                                       </tr>
                                       <tr class="text-center">
                                          <td>
                                             <h5>23<small>th</small> </h5>
                                          </td>
                                          <td>January</td>
                                          <td>Sunday</td>
                                       </tr>
                                       <tr class="text-center">
                                          <td>
                                             <h5>29<small>th</small> </h5>
                                          </td>
                                          <td>January</td>
                                          <td>Saturday</td>
                                       </tr>
                                       <tr class="text-center" >
                                          <td>
                                             <h5>30<small>th</small> </h5>
                                          </td>
                                          <td>January</td>
                                          <td>Sunday</td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </div>
                              <div class="col-sm-6">
                                 <div></div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="settingSidebar">
                  <a href="javascript:void(0)" class="settingPanelToggle"> <i
                     class="fa fa-spin fa-cog"></i>
                  </a>
                  <div class="settingSidebar-body ps-container ps-theme-default">
                     <div class=" fade show active">
                        <div class="setting-panel-header">Theme Customizer</div>
                        <div class="p-15 border-bottom">
                           <h6 class="font-medium m-b-10">Theme Layout</h6>
                           <div class="selectgroup layout-color w-50">
                              <label> <span class="control-label p-r-20">Light</span>
                              <input type="radio" name="custom-switch-input" value="1"
                                 class="custom-switch-input" checked> <span
                                 class="custom-switch-indicator"></span>
                              </label>
                           </div>
                           <div class="selectgroup layout-color  w-50">
                              <label> <span class="control-label p-r-20">Dark&nbsp;</span>
                              <input type="radio" name="custom-switch-input" value="2"
                                 class="custom-switch-input"> <span
                                 class="custom-switch-indicator"></span>
                              </label>
                           </div>
                        </div>
                     </div>
                     <div class="p-15 border-bottom">
                        <h6 class="font-medium m-b-10">Sidebar Colors</h6>
                        <div class="sidebar-setting-options">
                           <ul class="sidebar-color list-unstyled mb-0">
                              <li title="white" class="active">
                                 <div class="white"></div>
                              </li>
                              <li title="blue">
                                 <div class="blue"></div>
                              </li>
                              <li title="coral">
                                 <div class="coral"></div>
                              </li>
                              <li title="purple">
                                 <div class="purple"></div>
                              </li>
                              <li title="allports">
                                 <div class="allports"></div>
                              </li>
                              <li title="barossa">
                                 <div class="barossa"></div>
                              </li>
                              <li title="fancy">
                                 <div class="fancy"></div>
                              </li>
                           </ul>
                        </div>
                     </div>
                     <div class="p-15 border-bottom">
                        <h6 class="font-medium m-b-10">Theme Colors</h6>
                        <div class="theme-setting-options">
                           <ul class="choose-theme list-unstyled mb-0">
                              <li title="white" class="active">
                                 <div class="white"></div>
                              </li>
                              <li title="blue">
                                 <div class="blue"></div>
                              </li>
                              <li title="coral">
                                 <div class="coral"></div>
                              </li>
                              <li title="purple">
                                 <div class="purple"></div>
                              </li>
                              <li title="allports">
                                 <div class="allports"></div>
                              </li>
                              <li title="barossa">
                                 <div class="barossa"></div>
                              </li>
                              <li title="fancy">
                                 <div class="fancy"></div>
                              </li>
                              <li title="cyan">
                                 <div class="cyan"></div>
                              </li>
                              <li title="orange">
                                 <div class="orange"></div>
                              </li>
                              <li title="green">
                                 <div class="green"></div>
                              </li>
                              <li title="red">
                                 <div class="red"></div>
                              </li>
                           </ul>
                        </div>
                     </div>
                     <div class="p-15 border-bottom">
                        <h6 class="font-medium m-b-10">Layout Options</h6>
                        <div class="theme-setting-options">
                           <label> <span class="control-label p-r-20">Compact
                           Sidebar Menu</span> <input type="checkbox"
                              name="custom-switch-checkbox" class="custom-switch-input"
                              id="mini_sidebar_setting"> <span
                              class="custom-switch-indicator"></span>
                           </label>
                        </div>
                     </div>
                     <div class="mt-3 mb-3 align-center">
                        <a href="#"
                           class="btn btn-icon icon-left btn-outline-primary btn-restore-theme">
                        <i class="fas fa-undo"></i> Restore Default
                        </a>
                     </div>
                  </div>
               </div>
            </div>
            <!--------------------mainwrap div-->
            <footer class="main-footer">
               <div class="footer-left">
                  Copyright &copy; 2022 
                  <div class="bullet"></div>
                  Design By <a href="#">Snkthemes</a>
               </div>
               <div class="footer-right">
               </div>
            </footer>
         </div>
      </div>
      <!-- General JS Scripts -->
      <script src="assets/js/app.min.js"></script>
      <!-- JS Libraies -->
      <script src="assets/bundles/amcharts4/core.js"></script>
      <script src="assets/bundles/amcharts4/charts.js"></script>
      <script src="assets/bundles/amcharts4/animated.js"></script>
      <script src="assets/bundles/amcharts4/worldLow.js"></script>
      <script src="assets/bundles/amcharts4/maps.js"></script>
      <!-- Page Specific JS File -->
      <script src="assets/js/page/chart-amchart.js"></script>
      <!-- Template JS File -->
      <script src="assets/js/scripts.js"></script>
   </body>
   <script>
      $("#pleave").change(function()
      {
      $("#pleave option:selected").each(function()
      {
      if($(this).prop('selected'))
      {
      var drop=this.value;
      console.log("selected degree"+drop);
      }
      });
      });
      $("#status10").change(function()
      {
      $("#status10 option:selected").each(function()
      {
      if($(this).prop('selected'))
      {
      var drop10=this.value;
      console.log("selected status10"+drop10);
      }
      });
      });
      $("#pclose").click(function(){
      $(".perror").hide();
      var empid=$("#pid").val();
      var approve=$("#approved").val();
      var empname=$("#ename").val();
      var leave =$("#pleave").val();
      var from =$("#pform").val();
      var to =$("#pdate").val();
      var days=$("#pday").val();
      var reason=$("#preason").val();
      var status10=$("#status10").val();
      
      var error=false;
      console.log("emp"+empid);
       if(empid==""){
         $("#pid").after('<span class="perror" style="color:red">Please Enter your employee id</span>')
         error==true;
       }
       if(approve==""){
         $("#approved").after('<span class="perror" style="color:red">Please enter name</span>')
         error==true;
       }
       
       if(status10==""){
         $("#status10").after('<span class="perror" style="color:red">Please select status</span>')
         error==true;
       }
       
       if(empname==""){
         $("#ename").after('<span class="perror" style="color:red">Please enter your name</span>')
         error==true;
       }
       if(leave==""){
         $("#pleave").after('<span class="perror" style="color:red">Please select leave type</span>')
         error==true;
       }
       if(from==""){
         $("#pform").after('<span class="perror" style="color:red">Please select leave from date</span>')
         error==true;
       }
       if(to==""){
         $("#pdate").after('<span class="perror" style="color:red">Please select leave to date</span>')
         error==true;
       }
       if(days=='')
      {
         $("#pday").after('<div class="perror" style="color:red">Please enter number of days</div>')
         error=true;
      }
      if(reason=='')
      {
         $("#preason").after('<div class="perror" style="color:red">Please enter reason</div>')
         error=true;
      }
       if(error="true"){
         return false;
       }
      
      });
   </script>
 </html>