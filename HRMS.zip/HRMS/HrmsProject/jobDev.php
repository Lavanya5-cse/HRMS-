<?php include("connection.php");?>
<?php
$type=$_POST['type'];
$salary=$_POST['salary']; 
$experience=$_POST['experience'];
$vacancy=$_POST['vacancy'];
$loc=$_POST['loc'];

 $mysql="Insert into designer values('$type','$salary','$experience','$vacancy','$loc')";
if(mysqli_query($con,$mysql))
{
    header("Location:job-dev.php");
    exit();
}
else{
    echo "Error";
}
mysqli_close($con);
?>