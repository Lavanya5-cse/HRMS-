<?php include("connection.php");?>
<?php
$type=$_POST['type'];
$target=$_POST['target'];
$description=$_POST['description']; 
$strt=$_POST['strt'];
$end=$_POST['end'];
$progress=$_POST['progress'];
 
  $mysql="Insert into  goallist values('$type','$target','$description','$strt','$end','$progress')";
if(mysqli_query($con,$mysql))
{
    header("Location:goals-list.php");
    exit();
}
else{
    echo "Error";
}
mysqli_close($con);
?>