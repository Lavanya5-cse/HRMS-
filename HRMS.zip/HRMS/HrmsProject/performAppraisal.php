<?php include("connection.php");?>
<?php
 $empid=$_POST['empid'];
 $employee=$_POST['employee'];
 $desgn=$_POST['desgn'];
$dept=$_POST['dept']; 
$appr=$_POST['appr'];
 $star=$_POST['star'];
  

 $mysql="Insert into performanceappraisal values('$empid','$employee', '$desgn','$dept','$appr', '$star' )";
if(mysqli_query($con,$mysql))
{
    header("Location:performance Appraisal.php");
    exit();
}
else{
    echo "Error";
}
mysqli_close($con);
?>