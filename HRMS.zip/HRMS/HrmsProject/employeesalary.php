<?php include("connection.php");?>
<?php
$name=$_POST['name'];
$id=$_POST['id']; 
$email=$_POST['email'];
$date=$_POST['date'];
$role=$_POST['role'];
$salary=$_POST['salary'];
 
$mysql="insert into employeesalary values('$name','$id','$email','$date','$role','$salary')";
if(mysqli_query($con,$mysql))
{
    header("Location: Employee salary.php");
    exit();
}
else{
    echo "Error";
}
mysqli_close($con);
?>