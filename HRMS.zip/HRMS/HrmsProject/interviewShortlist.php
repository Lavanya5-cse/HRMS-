<?php include("connection.php");?>
<?php
 $sname=$_POST['sname'];
$jobtitle=$_POST['jobtitle']; 
$type=$_POST['type'];
 $status=$_POST['status'];
 $mysql="Insert into shortlistcandidates values('$sname', '$jobtitle','$type','$status' )";
if(mysqli_query($con,$mysql))
{
    header("Location:interview-shortlist.php");
    exit();
}
else{
    echo "Error";
}
mysqli_close($con);
?>