<!DOCTYPE html>
<html lang="en">
   <!-- Mirrored from radixtouch.in/templates/snkthemes/grexa/source/light/chart-amchart.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 06 Feb 2021 10:39:31 GMT -->
   <head>
      <meta charset="UTF-8">
      <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
      <title>Grexa - Admin Dashboard Template</title>
      <!-- General CSS Files -->
      <link rel="stylesheet" href="assets/css/app.min.css">
      <!-- Template CSS -->
      <link rel="stylesheet" href="assets/css/style.css">
      <link rel="stylesheet" href="assets/css/components.css">
      <!-- Custom style CSS -->
      <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.ico' />
      <script async src="https://www.googletagmanager.com/gtag/js?id=UA-94034622-3"></script>
   </head>
   <body>
      <div class="loader"></div>
      <div id="app">
      <div class="main-wrapper main-wrapper-1">
         <div class="navbar-bg"></div>
         <nav class="navbar navbar-expand-lg main-navbar">
            <div class="form-inline mr-auto">
               <ul class="navbar-nav mr-3">
                  <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg collapse-btn"><i
                     class="fas fa-bars"></i></a></li>
               </ul>
            </div>
         </nav>
         <div class="main-sidebar sidebar-style-2">
            <aside id="sidebar-wrapper">
               <div class="sidebar-brand">
                  <a href="index.html">
                  <img alt="image" src="assets/img/logo.png" class="header-logo" />
                  <span class="logo-name">Grexa</span>
                  </a>
               </div>
               <ul class="sidebar-menu">
               <li class="dropdown">
                  <a href="#" class="nav-link has-dropdown"><i class="fas fa-home"></i><span>Dashboard</span></a>
                  <ul class="dropdown-menu">
                     <li><a class="nav-link" href="index.php">Admin Dashboard</a></li>
                  </ul>
               </li>
               <li class="dropdown ">
                  <a href="#" class="nav-link has-dropdown"><i class="fas fa-leaf"></i><span>Employee
                  </span></a>
                  <ul class="dropdown-menu">
                     <li class=""><a class="nav-link" href="Employee dashboard.php">Employee Dashboard</a></li>
                     <li><a class="nav-link" href="Add Employee.php">Add Employee</a></li>
                  </ul>
               </li>
               <li class="dropdown active">
                  <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Leaves</span></a>
                  <ul class="dropdown-menu">
                     <li><a class="nav-link" href="Apply leave.php">Apply Leave</a></li>
                     <li class="active"><a class="nav-link active" href="Leave list.php">Leave List</a></li>
                  </ul>
               </li>
               <li class="dropdown">
                     <a href="#" class="nav-link has-dropdown"><i class="fas fa-anchor"></i><span> Project</span></a>
                     <ul class="dropdown-menu">
                        <li><a class="nav-link active" href="Project lists.php">Project lists</a></li>
                        <li><a class="nav-link" href="Projects_page.php">Projects</a></li>
                     </ul>
                  </li>
                  <li class="dropdown ">
                     <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Tickets</span></a>
                     <ul class="dropdown-menu">
                        <li><a class="nav-link" href="Tickets list.php">Tickets list</a></li>
                     </ul>
                  </li>
                  <li class="dropdown ">
                     <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Payroll</span></a>
                     <ul class="dropdown-menu">
                        <li><a class="nav-link" href="Employee salary.php">Employee salary</a></li>
                        <li><a class="nav-link" href="payslip.html">payslip</a></li>
                     </ul>
                  </li>
               <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Clients</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="Clients_page.php">Client form</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Leads</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Leads.php">Leads</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-hand-point-down"></i><span>Assets</span></a>
         <ul class="dropdown-menu">
         <li>  <a class="nav-link" href="Assests.php">Assets</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Performance</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="performance indicator.php">Performance Indicator</a></li>
         <li><a class="nav-link" href="performance Review.php">Performance Review</a></li>
         <li><a class="nav-link" href="performance Appraisal.php">Performance Appraisal  </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-crosshairs"></i><span>Goals</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="goals-list.php">Goal List</a></li>
         <li><a class="nav-link" href="goals-type.php">Goal type</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-pencil-alt"></i><span>Training</span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="training-list.php">Training List</a></li>
         <li><a class="nav-link" href="Trainers.php">Trainers</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-clipboard-check"></i><span>Jobs</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="job-dashboard.php">Jobs dashboard</a></li>
         <li><a class="nav-link" href="job-manage.php">ManageJobs</a></li>
         <li><a class="nav-link" href="job-resume.php">Manage Resumes</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-user-tie"></i><span>Interviews</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="interview-shortlist.php">Shortlist Candidates</a></li>
         <li><a class="nav-link" href="interview-schedule.php">Schedule time</a></li>
         <li><a class="nav-link" href="interview-offer.php">Offer  Approvals </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-file-alt"></i><span>Special Pages</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="policies.php">Policies</a></li>
         <li><a class="nav-link" href="FAQ.php">FAQ</a></li>
         <li><a class="nav-link" href="Terms of service.php">Terms Of Services</a></li>
         </ul>
         </li>
            </aside>
         </div>
         <!-- Main Content -->
         <div class="main-content">
            <section class="section">
               <div class="section-header ms-5 ">
                  <div class="card w-50 bg-light text-center">
                     <div class="card-body">
                        <h1 class="text-danger ">Leaves List for the year 2022</h1>
                     </div>
                  </div>
                  <div class="section-header-breadcrumb">
                     <div class="breadcrumb-item active"><a href="index.php">Dashboard</a></div>
                     <div class="breadcrumb-item"><a href="Apply leave.php">  Apply Leave</a></div>
                     <div class="breadcrumb-item">  Leave list </div>
                  </div>
               </div>
            </section>
            <div class="container">
               <div class="row">
                  <div class="col-md-2">
                     <div class="card h-100 bg-light text-danger ">
                        <div class="card-body">
                           <div class="text-center">
                              <h5 class="mt-2">Leaves</h5>
                              <br>
                              <ul class="nav flex-column nav-pills nav-pills-custom  " >
                                 <li class="">
                                    <a class="nav-link active" id="home-tab4" data-toggle="tab" href="#jan" role="tab" aria-controls="" aria-selected="false">Jan</a>
                                 </li>
                                 <li class="">
                                    <a class="nav-link " id="home-tab4" data-toggle="tab" href="#feb" 
                                       role="tab" aria-controls="feb" aria-selected="false">Feb</a>
                                 </li>
                                 <li class="">
                                    <a class="nav-link " id="home-tab4" data-toggle="tab" href="#mar" 
                                       role="tab" aria-controls="mar" aria-selected="true">Mar</a>
                                 </li>
                                 <li class="">
                                    <a class="nav-link " id="home-tab4" data-toggle="tab" href="#apr" 
                                       role="tab" aria-controls="apr" aria-selected="true">Apr</a>
                                 </li>
                                 <li class="">
                                    <a class="nav-link " id="home-tab4" data-toggle="tab" href="#may" 
                                       role="tab" aria-controls="may" aria-selected="true">May</a>
                                 </li>
                                 <li class="">
                                    <a class="nav-link " id="home-tab4" data-toggle="tab" href="#jun" 
                                       role="tab" aria-controls="jun" aria-selected="false">Jun</a>
                                 </li>
                                 <li class="">
                                    <a class="nav-link " id="home-tab4" data-toggle="tab" href="#jly" 
                                       role="tab" aria-controls="jly" aria-selected="false">July</a>
                                 </li>
                                 <li class="">
                                    <a class="nav-link " id="home-tab4" data-toggle="tab" href="#agu" 
                                       role="tab" aria-controls="agu" aria-selected="false">Agu</a>
                                 </li>
                                 <li class="">
                                    <a class="nav-link " id="home-tab4" data-toggle="tab" href="#sep" 
                                       role="tab" aria-controls="sep" aria-selected="false">Sep</a>
                                 </li>
                                 <li class="">
                                    <a class="nav-link " id="home-tab4" data-toggle="tab" href="#oct" 
                                       role="tab" aria-controls="oct" aria-selected="false">Oct</a>
                                 </li>
                                 <li class="">
                                    <a class="nav-link " id="home-tab4" data-toggle="tab" href="#nov" 
                                       role="tab" aria-controls="nov" aria-selected="false">Nov</a>
                                 </li>
                                 <li class="">
                                    <a class="nav-link " id="home-tab4" data-toggle="tab" href="#dec" 
                                       role="tab" aria-controls="dec" aria-selected="false">Dec</a>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-10">
                     <div class="card h-100">
                        <div class="card-body bg-light  ">
                           <div class="tab-content">
                              <div class="tab-pane fade  active show" id="jan" role="tabpanel" aria-labelledby="jan">
                                 <h5 class="text-danger mb-4 text-center" >Leaves For The Month Of January 2022</h5>
                                 <table class="table table-bordered table-striped table-hover table-responsive">
                                    <thead>
                                       <tr class="info  bg-light">
                                          <th>S.No</th>
                                          <th>Emp Name</th>
                                          <th>Emp ID</th>
                                          <th>Leave Type</th>
                                          <th>From</th>
                                          <th>To</th>
                                          <th>Days</th>
                                          <th>Reason</th>
                                          <th>Status</th>
                                          <th>Approved by</th>
                                       </tr>
                                    </thead>
                                    <tbody>
                                       <tr>
                                          <td>1</td>
                                          <td>Trivikram</td>
                                          <td>901791</td>
                                          <td>Causal</td>
                                          <td>01-jan-2022</td>
                                          <td>02-jan-2022</td>
                                          <td>1 day</td>
                                          <td>Health Issue</td>
                                          <td>
                                             <select class="form-select form-select-lg rounded-pill text-center bg-danger">
                                                <option value="high"  selected="">Rejected</option>
                                                <option value="Software Engineer">Pending</option>
                                                <option value="Software developer"></option>
                                             </select>
                                          </td>
                                          <td>Deepika</td>
                                       </tr>
                                       <tr>
                                          <td>2</td>
                                          <td>vicky</td>
                                          <td>901791</td>
                                          <td>Causal</td>
                                          <td>01-jan-2022</td>
                                          <td>02-jan-2022</td>
                                          <td>1 day</td>
                                          <td>going to village</td>
                                          <td>
                                             <select class="form-select form-select-lg rounded-pill text-center bg-success">
                                                <option value="high" selected="">Approved</option>
                                                <option value="Software Engineer">Pending</option>
                                                <option value="Software developer">Rejected</option>
                                             </select>
                                          </td>
                                          <td>Deepika</td>
                                       </tr>
                                       <tr>
                                          <td>3</td>
                                          <td>Sanjay</td>
                                          <td>901791</td>
                                          <td>Causal</td>
                                          <td>01-jan-2022</td>
                                          <td>02-jan-2022</td>
                                          <td>1 day</td>
                                          <td>going to village</td>
                                          <td>
                                             <select class="form-select form-select-lg rounded-pill text-center bg-success">
                                                <option value="high" selected="">Approved</option>
                                                <option value="Software Engineer">Pending</option>
                                                <option value="Software developer">Rejected</option>
                                             </select>
                                          </td>
                                          <td>Deepika</td>
                                       </tr>
                                       <tr>
                                          <td>4</td>
                                          <td>Kumaran</td>
                                          <td>901791</td>
                                          <td>Causal</td>
                                          <td>01-jan-2022</td>
                                          <td>02-jan-2022</td>
                                          <td>1 day</td>
                                          <td>going to village</td>
                                          <td>
                                             <select class="form-select form-select-lg rounded-pill text-center bg-yellow">
                                                <option value="high" selected="">Pending</option>
                                                <option value="Software Engineer">Aproved</option>
                                                <option value="Software developer">Rejected</option>
                                             </select>
                                          </td>
                                          <td>Deepika</td>
                                       </tr>
                                       <tr>
                                          <td>5</td>
                                          <td>Trivikram</td>
                                          <td>901791</td>
                                          <td>Causal</td>
                                          <td>01-jan-2022</td>
                                          <td>02-jan-2022</td>
                                          <td>1 day</td>
                                          <td>going to village</td>
                                          <td>
                                             <select class="form-select form-select-lg rounded-pill text-center bg-danger">
                                                <option value="high" selected="">Approved</option>
                                                <option value="Software Engineer">Pending</option>
                                                <option value="Software developer">Rejected</option>
                                             </select>
                                          </td>
                                          <td>Deepika</td>
                                       </tr>
                                       <tr>
                                          <td>6</td>
                                          <td>Sai</td>
                                          <td>901720</td>
                                          <td>Causal</td>
                                          <td>01-jan-2022</td>
                                          <td>02-jan-2022</td>
                                          <td>1 day</td>
                                          <td>Personal Work</td>
                                          <td>
                                             <select class="form-select form-select-lg rounded-pill text-center bg-success">
                                                <option value="high" selected="">Approved</option>
                                                <option value="Software Engineer">Pending</option>
                                                <option value="Software developer">Rejected</option>
                                             </select>
                                          </td>
                                          <td>Deepika</td>
                                       </tr>
                                       <tr>
                                          <td>7</td>
                                          <td>Sunny</td>
                                          <td>901722</td>
                                          <td>Sick</td>
                                          <td>01-jan-2022</td>
                                          <td>05-jan-2022</td>
                                          <td>5 days</td>
                                          <td>Health Issue</td>
                                          <td>
                                             <select class="form-select form-select-lg rounded-pill text-center  bg-success">
                                                <option value="high" selected="">Approved</option>
                                                <option value="Software Engineer">Pending</option>
                                                <option value="Software developer">Rejected</option>
                                             </select>
                                          </td>
                                          <td>Deepika</td>
                                       </tr>
                                       <tr>
                                          <td>8</td>
                                          <td>Faima</td>
                                          <td>901731</td>
                                          <td>Causal</td>
                                          <td>01-jan-2022</td>
                                          <td>02-jan-2022</td>
                                          <td>1 day</td>
                                          <td>Personal</td>
                                          <td>
                                             <select class="form-select form-select-lg rounded-pill text-center bg-danger">
                                                <option value="high" selected="">Rejected</option>
                                                <option value="Software Engineer">Pending</option>
                                                <option value="Software developer">Approved</option>
                                             </select>
                                          </td>
                                          <td>Deepika</td>
                                       </tr>
                                       <tr>
                                          <td>9</td>
                                          <td>Rohini</td>
                                          <td>901781</td>
                                          <td>Causal</td>
                                          <td>01-jan-2022</td>
                                          <td>02-jan-2022</td>
                                          <td>1 day</td>
                                          <td>Hometown Visit</td>
                                          <td>
                                             <select class="form-select form-select-lg rounded-pill text-center bg-success">
                                                <option value="high" selected="">Approved</option>
                                                <option value="Software Engineer">Pending</option>
                                                <option value="Software developer">Rejected</option>
                                             </select>
                                          </td>
                                          <td>Deepika</td>
                                       </tr>
                                       <tr>
                                          <td>10</td>
                                          <td>Reventh</td>
                                          <td>901731</td>
                                          <td>Causal</td>
                                          <td>01-jan-2022</td>
                                          <td>02-jan-2022</td>
                                          <td>1 day</td>
                                          <td>Personal</td>
                                          <td>
                                             <select class="form-select form-select-lg rounded-pill text-center bg-yellow">
                                                <option value="high" selected="">Pending</option>
                                                <option value="Software Engineer">Approved</option>
                                                <option value="Software developer">Rejected</option>
                                             </select>
                                          </td>
                                          <td>Deepika</td>
                                       </tr>
                                       <tr>
                                          <td>11</td>
                                          <td>Rakesh</td>
                                          <td>901711</td>
                                          <td>Causal</td>
                                          <td>01-jan-2022</td>
                                          <td>02-jan-2022</td>
                                          <td>1 day</td>
                                          <td>Function</td>
                                          <td>
                                             <select class="form-select form-select-lg rounded-pill text-center bg-yellow">
                                                <option value="high" selected="">Pending</option>
                                                <option value="Software Engineer">Approved</option>
                                                <option value="Software developer">Rejected</option>
                                             </select>
                                          </td>
                                          <td>Deepika</td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </div>
                              <div class="tab-pane fade " id="feb" role="tabpanel" aria-labelledby="feb">
                                 <h5 class="text-danger mb-4 text-center" >Leaves For The Month Of February 2012</h5>
                                 <div class="col-sm-12">
                                    <table class="table table-bordered table-striped table-hover table-responsive">
                                       <thead>
                                          <tr class="info  bg-light">
                                             <th>S.No</th>
                                             <th>Emp Name</th>
                                             <th>Emp ID</th>
                                             <th>Leave Type</th>
                                             <th>From</th>
                                             <th>To</th>
                                             <th>Days</th>
                                             <th>Reason</th>
                                             <th>Status</th>
                                             <th>Approved by</th>
                                          </tr>
                                       </thead>
                                       <tbody>
                                          <tr>
                                             <td>1</td>
                                             <td>Ram</td>
                                             <td>901794</td>
                                             <td>Causal</td>
                                             <td>01-feb-2022</td>
                                             <td>02-feb-2022</td>
                                             <td>1 day</td>
                                             <td>Personal</td>
                                             <td>
                                                <select class="form-select form-select-lg rounded-pill text-center bg-success">
                                                   <option value="high" selected="">Approved</option>
                                                   <option value="Software Engineer">Pending</option>
                                                   <option value="Software developer">Rejected</option>
                                                </select>
                                             </td>
                                             <td>Deepika</td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </div>
                              </div>
                              <div class="tab-pane " id="mar" role="tabpanel" aria-labelledby="mar">
                                 <h5 class="text-danger mb-4 text-center" >Leaves For The Month Of March 2012</h5>
                                 <div class="col-sm-12" >
                                    <table class="table table-bordered table-striped table-hover table-responsive">
                                       <thead>
                                          <tr class="info  bg-light">
                                             <th>S.No</th>
                                             <th>Emp Name</th>
                                             <th>Emp ID</th>
                                             <th>Leave Type</th>
                                             <th>From</th>
                                             <th>To</th>
                                             <th>Days</th>
                                             <th>Reason</th>
                                             <th>Status</th>
                                             <th>Approved by</th>
                                          </tr>
                                       </thead>
                                       <tbody>
                                          <tr>
                                             <td>1</td>
                                             <td>Kiran</td>
                                             <td>901731</td>
                                             <td>Sick</td>
                                             <td>01-jan-2022</td>
                                             <td>03-jan-2022</td>
                                             <td>3 days</td>
                                             <td>Health issue</td>
                                             <td>
                                                <select class="form-select form-select-lg rounded-pill text-center bg-success">
                                                   <option value="high" selected="">Approved</option>
                                                   <option value="Software Engineer">Pending</option>
                                                   <option value="Software developer">Rejected</option>
                                                </select>
                                             </td>
                                             <td>Deepika</td>
                                          </tr>
                                          <tr>
                                             <td>2</td>
                                             <td>CAt</td>
                                             <td>901767</td>
                                             <td>Causal</td>
                                             <td>01-jan-2022</td>
                                             <td>02-jan-2022</td>
                                             <td>1 day</td>
                                             <td>Personal Work</td>
                                             <td>
                                                <select class="form-select form-select-lg rounded-pill text-center bg-danger">
                                                   <option value="high" selected="">Rejected</option>
                                                   <option value="Software Engineer">Pending</option>
                                                   <option value="Software developer">Approved</option>
                                                </select>
                                             </td>
                                             <td>Deepika</td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </div>
                              </div>
                              <div class="tab-pane " id="apr" role="tabpanel" aria-labelledby="apr">
                                 <h5 class="text-danger mb-4 text-center" >Leaves For The Month Of April 2012</h5>
                                 <div class="col-sm-12" >
                                    <table class="table table-bordered table-striped table-hover table-responsive">
                                       <thead>
                                          <tr class="info  bg-light">
                                             <th>S.No</th>
                                             <th>Emp Name</th>
                                             <th>Emp ID</th>
                                             <th>Leave Type</th>
                                             <th>From</th>
                                             <th>To</th>
                                             <th>Days</th>
                                             <th>Reason</th>
                                             <th>Status</th>
                                             <th>Approved by</th>
                                          </tr>
                                       </thead>
                                       <tbody>
                                          <tr>
                                             <td>2</td>
                                             <td>Ram</td>
                                             <td>901791</td>
                                             <td>Causal</td>
                                             <td>01-apr-2022</td>
                                             <td>02-apr-2022</td>
                                             <td>1 day</td>
                                             <td>Function</td>
                                             <td>
                                                <select class="form-select form-select-lg rounded-pill text-center bg-success">
                                                   <option value="high" selected="">Approved</option>
                                                   <option value="Software Engineer">Pending</option>
                                                   <option value="Software developer">Rejected</option>
                                                </select>
                                             </td>
                                             <td>Sita</td>
                                          </tr>
                                          <tr>
                                             <td>1</td>
                                             <td>Trivikram</td>
                                             <td>901791</td>
                                             <td>Causal</td>
                                             <td>01-apr-2022</td>
                                             <td>02-apr-2022</td>
                                             <td>1 day</td>
                                             <td>Party</td>
                                             <td>
                                                <select class="form-select form-select-lg rounded-pill text-center bg-danger">
                                                   <option value="high" selected="">Rejected</option>
                                                   <option value="Software Engineer">Pending</option>
                                                   <option value="Software developer">Approved</option>
                                                </select>
                                             </td>
                                             <td>Dev</td>
                                          </tr>
                                          <tr>
                                             <td>3</td>
                                             <td>Laxmi</td>
                                             <td>901410</td>
                                             <td>Causal</td>
                                             <td>01-apr-2022</td>
                                             <td>02-apr-2022</td>
                                             <td>3 days</td>
                                             <td>Function</td>
                                             <td>
                                                <select class="form-select form-select-lg rounded-pill text-center bg-success">
                                                   <option value="high" selected="">Approved</option>
                                                   <option value="Software Engineer">Pending</option>
                                                   <option value="Software developer">Rejected</option>
                                                </select>
                                             </td>
                                             <td>Sita</td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </div>
                              </div>
                              <div class="tab-pane " id="may" role="tabpanel" aria-labelledby="may">
                                 <h5 class="text-danger mb-4 text-center" >Leaves For The Month Of May 2012</h5>
                                 <div class="col-sm-12" >
                                    <table class="table table-bordered table-striped table-hover table-responsive">
                                       <thead>
                                          <tr class="info  bg-light">
                                             <th>S.No</th>
                                             <th>Emp Name</th>
                                             <th>Emp ID</th>
                                             <th>Leave Type</th>
                                             <th>From</th>
                                             <th>To</th>
                                             <th>Days</th>
                                             <th>Reason</th>
                                             <th>Status</th>
                                             <th>Approved by</th>
                                          </tr>
                                       </thead>
                                       <tbody>
                                          <tr>
                                             <td>1</td>
                                             <td>Vivek</td>
                                             <td>901291</td>
                                             <td>Causal</td>
                                             <td>01-jan-2022</td>
                                             <td>02-jan-2022</td>
                                             <td>2 days</td>
                                             <td>Hometown Visit</td>
                                             <td>
                                                <select class="form-select form-select-lg rounded-pill text-center bg-success">
                                                   <option value="high" selected="">Approved</option>
                                                   <option value="Software Engineer">Pending</option>
                                                   <option value="Software developer">Rejected</option>
                                                </select>
                                             </td>
                                             <td>Deepika</td>
                                          </tr>
                                          <tr>
                                             <td>1</td>
                                             <td>Krishna</td>
                                             <td>901741</td>
                                             <td>Causal</td>
                                             <td>01-jan-2022</td>
                                             <td>02-jan-2022</td>
                                             <td>1 day</td>
                                             <td>Function</td>
                                             <td>
                                                <select class="form-select form-select-lg rounded-pill text-center bg-success">
                                                   <option value="high" selected="">Approved</option>
                                                   <option value="Software Engineer">Pending</option>
                                                   <option value="Software developer">Rejected</option>
                                                </select>
                                             </td>
                                             <td>Ram</td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </div>
                              </div>
                              <div class="tab-pane " id="jun" role="tabpanel" aria-labelledby="jun">
                                 <h5 class="text-danger mb-4 text-center" >Leaves For The Month Of June 2012</h5>
                                 <div class="col-sm-12" >
                                    <table class="table table-bordered table-striped table-hover table-responsive">
                                       <thead>
                                          <tr class="info  bg-light">
                                             <th>S.No</th>
                                             <th>Emp Name</th>
                                             <th>Emp ID</th>
                                             <th>Leave Type</th>
                                             <th>From</th>
                                             <th>To</th>
                                             <th>Days</th>
                                             <th>Reason</th>
                                             <th>Status</th>
                                             <th>Approved by</th>
                                          </tr>
                                       </thead>
                                       <tbody>
                                          <tr>
                                             <td>1</td>
                                             <td>Lavanya</td>
                                             <td>901491</td>
                                             <td>Causal</td>
                                             <td>01-jan-2022</td>
                                             <td>02-jan-2022</td>
                                             <td>1 day</td>
                                             <td>Event</td>
                                             <td>
                                                <select class="form-select form-select-lg rounded-pill text-center bg-success">
                                                   <option value="high" selected="">Approved</option>
                                                   <option value="Software Engineer">Pending</option>
                                                   <option value="Software developer">Rejected</option>
                                                </select>
                                             </td>
                                             <td>Deepika</td>
                                          </tr>
                                          <tr>
                                             <td>2</td>
                                             <td>Kittu</td>
                                             <td>901791</td>
                                             <td>Causal</td>
                                             <td>01-jan-2022</td>
                                             <td>02-jan-2022</td>
                                             <td>1 day</td>
                                             <td>going to village</td>
                                             <td>
                                                <select class="form-select form-select-lg rounded-pill text-center bg-success">
                                                   <option value="high" selected="">Approved</option>
                                                   <option value="Software Engineer">Pending</option>
                                                   <option value="Software developer">Rejected</option>
                                                </select>
                                             </td>
                                             <td>Deepika</td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </div>
                              </div>
                              <div class="tab-pane " id="jly" role="tabpanel" aria-labelledby="jly">
                                 <h5 class="text-danger mb-4 text-center" >Leaves For The Month Of July 2012</h5>
                                 <div class="col-sm-12" >
                                    <table class="table table-bordered table-striped table-hover table-responsive">
                                       <thead>
                                          <tr class="info  bg-light">
                                             <th>S.No</th>
                                             <th>Emp Name</th>
                                             <th>Emp ID</th>
                                             <th>Leave Type</th>
                                             <th>From</th>
                                             <th>To</th>
                                             <th>Days</th>
                                             <th>Reason</th>
                                             <th>Status</th>
                                             <th>Approved by</th>
                                          </tr>
                                       </thead>
                                       <tbody>
                                          <tr>
                                             <td>1</td>
                                             <td>Vyshu</td>
                                             <td>901701</td>
                                             <td>Causal</td>
                                             <td>01-jan-2022</td>
                                             <td>02-jan-2022</td>
                                             <td>1 day</td>
                                             <td>going to village</td>
                                             <td>
                                                <select class="form-select form-select-lg rounded-pill text-center bg-success">
                                                   <option value="high" selected="">Approved</option>
                                                   <option value="Software Engineer">Pending</option>
                                                   <option value="Software developer">Rejected</option>
                                                </select>
                                             </td>
                                             <td>Deepika</td>
                                          </tr>
                                          <tr>
                                             <td>1</td>
                                             <td>ravi</td>
                                             <td>901791</td>
                                             <td>Causal</td>
                                             <td>01-jan-2022</td>
                                             <td>02-jan-2022</td>
                                             <td>1 day</td>
                                             <td>going to village</td>
                                             <td>
                                                <select class="form-select form-select-lg rounded-pill text-center bg-success">
                                                   <option value="high" selected="">Approved</option>
                                                   <option value="Software Engineer">Pending</option>
                                                   <option value="Software developer">Rejected</option>
                                                </select>
                                             </td>
                                             <td>Deepika</td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </div>
                              </div>
                              <div class="tab-pane " id="agu" role="tabpanel" aria-labelledby="agu">
                                 <h5 class="text-danger mb-4 text-center" >Leaves For The Month Of August 2012</h5>
                                 <div class="col-sm-12" >
                                    <table class="table table-bordered table-striped table-hover table-responsive">
                                       <thead>
                                          <tr class="info  bg-light">
                                             <th>S.No</th>
                                             <th>Emp Name</th>
                                             <th>Emp ID</th>
                                             <th>Leave Type</th>
                                             <th>From</th>
                                             <th>To</th>
                                             <th>Days</th>
                                             <th>Reason</th>
                                             <th>Status</th>
                                             <th>Approved by</th>
                                          </tr>
                                       </thead>
                                       <tbody>
                                          <tr>
                                             <td>1</td>
                                             <td>rani</td>
                                             <td>901791</td>
                                             <td>Causal</td>
                                             <td>01-jan-2022</td>
                                             <td>02-jan-2022</td>
                                             <td>1 day</td>
                                             <td>going to village</td>
                                             <td>
                                                <select class="form-select form-select-lg rounded-pill text-center bg-success">
                                                   <option value="high" selected="">Approved</option>
                                                   <option value="Software Engineer">Pending</option>
                                                   <option value="Software developer">Rejected</option>
                                                </select>
                                             </td>
                                             <td>Deepika</td>
                                          </tr>
                                          <tr>
                                             <td>2</td>
                                             <td>Jaya</td>
                                             <td>901791</td>
                                             <td>Causal</td>
                                             <td>01-jan-2022</td>
                                             <td>02-jan-2022</td>
                                             <td>1 day</td>
                                             <td>going to village</td>
                                             <td>
                                                <select class="form-select form-select-lg rounded-pill text-center bg-success">
                                                   <option value="high" selected="">Approved</option>
                                                   <option value="Software Engineer">Pending</option>
                                                   <option value="Software developer">Rejected</option>
                                                </select>
                                             </td>
                                             <td>Deepika</td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </div>
                              </div>
                              <div class="tab-pane " id="sep" role="tabpanel" aria-labelledby="sep">
                                 <h5 class="text-danger mb-4 text-center" >Leaves For The Month Of September 2012</h5>
                                 <div class="col-sm-12" >
                                    <table class="table table-bordered table-striped table-hover table-responsive">
                                       <thead>
                                          <tr class="info  bg-light">
                                             <th>S.No</th>
                                             <th>Emp Name</th>
                                             <th>Emp ID</th>
                                             <th>Leave Type</th>
                                             <th>From</th>
                                             <th>To</th>
                                             <th>Days</th>
                                             <th>Reason</th>
                                             <th>Status</th>
                                             <th>Approved by</th>
                                          </tr>
                                       </thead>
                                       <tbody>
                                          <tr>
                                             <td>1</td>
                                             <td>Laxmi</td>
                                             <td>901791</td>
                                             <td>Causal</td>
                                             <td>01-jan-2022</td>
                                             <td>02-jan-2022</td>
                                             <td>1 day</td>
                                             <td>going to village</td>
                                             <td>
                                                <select class="form-select form-select-lg rounded-pill text-center bg-danger">
                                                   <option value="high" selected="">Rejected</option>
                                                   <option value="Software Engineer">Pending</option>
                                                   <option value="Software developer">Approved</option>
                                                </select>
                                             </td>
                                             <td>Deepika</td>
                                          </tr>
                                          <tr>
                                             <td>1</td>
                                             <td>Trivikram</td>
                                             <td>901791</td>
                                             <td>Causal</td>
                                             <td>01-jan-2022</td>
                                             <td>02-jan-2022</td>
                                             <td>1 day</td>
                                             <td>going to village</td>
                                             <td>
                                                <select class="form-select form-select-lg rounded-pill text-center bg-success">
                                                   <option value="high" selected="">Approved</option>
                                                   <option value="Software Engineer">Pending</option>
                                                   <option value="Software developer">Rejected</option>
                                                </select>
                                             </td>
                                             <td>Deepika</td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </div>
                              </div>
                              <div class="tab-pane " id="oct" role="tabpanel" aria-labelledby="oct">
                                 <h5 class="text-danger mb-4 text-center" >Leaves For The Month Of October 2012</h5>
                                 <div class="col-sm-12" >
                                    <table class="table table-bordered table-striped table-hover table-responsive">
                                       <thead>
                                          <tr class="info  bg-light">
                                             <th>S.No</th>
                                             <th>Emp Name</th>
                                             <th>Emp ID</th>
                                             <th>Leave Type</th>
                                             <th>From</th>
                                             <th>To</th>
                                             <th>Days</th>
                                             <th>Reason</th>
                                             <th>Status</th>
                                             <th>Approved by</th>
                                          </tr>
                                       </thead>
                                       <tbody>
                                          <tr>
                                             <td>1</td>
                                             <td>Ramya</td>
                                             <td>901791</td>
                                             <td>Causal</td>
                                             <td>01-jan-2022</td>
                                             <td>04-jan-2022</td>
                                             <td>4 day</td>
                                             <td>Personal Work</td>
                                             <td>
                                                <select class="form-select form-select-lg rounded-pill text-center bg-success">
                                                   <option value="high" selected="">Approved</option>
                                                   <option value="Software Engineer">Pending</option>
                                                   <option value="Software developer">Rejected</option>
                                                </select>
                                             </td>
                                             <td>Deepika</td>
                                          </tr>
                                          <tr>
                                             <td>2</td>
                                             <td>Sanju</td>
                                             <td>901791</td>
                                             <td>Causal</td>
                                             <td>01-jan-2022</td>
                                             <td>02-jan-2022</td>
                                             <td>1 day</td>
                                             <td>Party</td>
                                             <td>
                                                <select class="form-select form-select-lg rounded-pill text-center bg-danger">
                                                   <option value="high" selected="">Rejected</option>
                                                   <option value="Software Engineer">Pending</option>
                                                   <option value="Software developer">Approved</option>
                                                </select>
                                             </td>
                                             <td>Deepika</td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </div>
                              </div>
                              <div class="tab-pane " id="nov" role="tabpanel" aria-labelledby="nov">
                                 <h5 class="text-danger mb-4 text-center" >Leaves For The Month Of November 2012</h5>
                                 <div class="col-sm-12" >
                                    <table class="table table-bordered table-striped table-hover table-responsive">
                                       <thead>
                                          <tr class="info  bg-light">
                                             <th>S.No</th>
                                             <th>Emp Name</th>
                                             <th>Emp ID</th>
                                             <th>Leave Type</th>
                                             <th>From</th>
                                             <th>To</th>
                                             <th>Days</th>
                                             <th>Reason</th>
                                             <th>Status</th>
                                             <th>Approved by</th>
                                          </tr>
                                       </thead>
                                       <tbody>
                                          <tr>
                                             <td>1</td>
                                             <td>Trivikram</td>
                                             <td>901791</td>
                                             <td>Causal</td>
                                             <td>01-jan-2022</td>
                                             <td>02-jan-2022</td>
                                             <td>1 day</td>
                                             <td>Health issue</td>
                                             <td>
                                                <select class="form-select form-select-lg rounded-pill text-center bg-success">
                                                   <option value="high" selected="">Approved</option>
                                                   <option value="Software Engineer">Pending</option>
                                                   <option value="Software developer">Rejected</option>
                                                </select>
                                             </td>
                                             <td>Deepika</td>
                                          </tr>
                                          <tr>
                                             <td>2</td>
                                             <td>Ramya</td>
                                             <td>901791</td>
                                             <td>Causal</td>
                                             <td>01-dec-2022</td>
                                             <td>02-dec-2022</td>
                                             <td>1 day</td>
                                             <td>Exam</td>
                                             <td>
                                                <select class="form-select form-select-lg rounded-pill text-center bg-success">
                                                   <option value="high" selected="">Approved</option>
                                                   <option value="Software Engineer">Pending</option>
                                                   <option value="Software developer">Rejected</option>
                                                </select>
                                             </td>
                                             <td>Deepika</td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </div>
                              </div>
                              <div class="tab-pane " id="dec" role="tabpanel" aria-labelledby="dec">
                                 <h5 class="text-danger mb-4 text-center" >Leaves For The Month Of December 2012</h5>
                                 <div class="col-sm-12" >
                                    <table class="table table-bordered table-striped table-hover table-responsive">
                                       <thead>
                                          <tr class="info  bg-light">
                                             <th>S.No</th>
                                             <th>Emp Name</th>
                                             <th>Emp ID</th>
                                             <th>Leave Type</th>
                                             <th>From</th>
                                             <th>To</th>
                                             <th>Days</th>
                                             <th>Reason</th>
                                             <th>Status</th>
                                             <th>Approved by</th>
                                          </tr>
                                       </thead>
                                       <tbody>
                                          <tr>
                                             <td>1</td>
                                             <td>Cat</td>
                                             <td>901795</td>
                                             <td>sick</td>
                                             <td>04-dec-2022</td>
                                             <td>06-dec-2022</td>
                                             <td>2days</td>
                                             <td>accident</td>
                                             <td>
                                                <select class="form-select form-select-lg rounded-pill text-center bg-danger">
                                                   <option value="high" selected="">Rejected</option>
                                                   <option value="Software Engineer">Pending</option>
                                                   <option value="Software developer">Approved</option>
                                                </select>
                                             </td>
                                             <td>Badhri</td>
                                          </tr>
                                          <tr>
                                             <td>2</td>
                                             <td>Justina</td>
                                             <td>901796</td>
                                             <td>Loss Of Pay</td>
                                             <td>05-dec-2022</td>
                                             <td>06-dec-2022</td>
                                             <td>1 day</td>
                                             <td>Personal</td>
                                             <td>
                                                <select class="form-select form-select-lg rounded-pill text-center bg-success">
                                                   <option value="high" selected="">Approved</option>
                                                   <option value="Software Engineer">Pending</option>
                                                   <option value="Software developer">Rejected</option>
                                                </select>
                                             </td>
                                             <td>Deepika</td>
                                          </tr>
                                          <tr>
                                             <td>3</td>
                                             <td>Murugan</td>
                                             <td>901799</td>
                                             <td>Loss Of Pay</td>
                                             <td>09-dec-2022</td>
                                             <td>10-dec-2022</td>
                                             <td>1 day</td>
                                             <td>Personal</td>
                                             <td>
                                                <select class="form-select form-select-lg rounded-pill text-center bg-success">
                                                   <option value="high" selected="">Approved</option>
                                                   <option value="Software Engineer">Pending</option>
                                                   <option value="Software developer">Rejected</option>
                                                </select>
                                             </td>
                                             <td>Dev</td>
                                          </tr>
                                       </tbody>
                                    </table>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="settingSidebar">
                  <a href="javascript:void(0)" class="settingPanelToggle"> <i
                     class="fa fa-spin fa-cog"></i>
                  </a>
                  <div class="settingSidebar-body ps-container ps-theme-default">
                     <div class=" fade show active">
                        <div class="setting-panel-header">Theme Customizer</div>
                        <div class="p-15 border-bottom">
                           <h6 class="font-medium m-b-10">Theme Layout</h6>
                           <div class="selectgroup layout-color w-50">
                              <label> <span class="control-label p-r-20">Light</span>
                              <input type="radio" name="custom-switch-input" value="1"
                                 class="custom-switch-input" checked> <span
                                 class="custom-switch-indicator"></span>
                              </label>
                           </div>
                           <div class="selectgroup layout-color  w-50">
                              <label> <span class="control-label p-r-20">Dark&nbsp;</span>
                              <input type="radio" name="custom-switch-input" value="2"
                                 class="custom-switch-input"> <span
                                 class="custom-switch-indicator"></span>
                              </label>
                           </div>
                        </div>
                     </div>
                     <div class="p-15 border-bottom">
                        <h6 class="font-medium m-b-10">Sidebar Colors</h6>
                        <div class="sidebar-setting-options">
                           <ul class="sidebar-color list-unstyled mb-0">
                              <li title="white" class="active">
                                 <div class="white"></div>
                              </li>
                              <li title="blue">
                                 <div class="blue"></div>
                              </li>
                              <li title="coral">
                                 <div class="coral"></div>
                              </li>
                              <li title="purple">
                                 <div class="purple"></div>
                              </li>
                              <li title="allports">
                                 <div class="allports"></div>
                              </li>
                              <li title="barossa">
                                 <div class="barossa"></div>
                              </li>
                              <li title="fancy">
                                 <div class="fancy"></div>
                              </li>
                           </ul>
                        </div>
                     </div>
                     <div class="p-15 border-bottom">
                        <h6 class="font-medium m-b-10">Theme Colors</h6>
                        <div class="theme-setting-options">
                           <ul class="choose-theme list-unstyled mb-0">
                              <li title="white" class="active">
                                 <div class="white"></div>
                              </li>
                              <li title="blue">
                                 <div class="blue"></div>
                              </li>
                              <li title="coral">
                                 <div class="coral"></div>
                              </li>
                              <li title="purple">
                                 <div class="purple"></div>
                              </li>
                              <li title="allports">
                                 <div class="allports"></div>
                              </li>
                              <li title="barossa">
                                 <div class="barossa"></div>
                              </li>
                              <li title="fancy">
                                 <div class="fancy"></div>
                              </li>
                              <li title="cyan">
                                 <div class="cyan"></div>
                              </li>
                              <li title="orange">
                                 <div class="orange"></div>
                              </li>
                              <li title="green">
                                 <div class="green"></div>
                              </li>
                              <li title="red">
                                 <div class="red"></div>
                              </li>
                           </ul>
                        </div>
                     </div>
                     <div class="p-15 border-bottom">
                        <h6 class="font-medium m-b-10">Layout Options</h6>
                        <div class="theme-setting-options">
                           <label> <span class="control-label p-r-20">Compact
                           Sidebar Menu</span> <input type="checkbox"
                              name="custom-switch-checkbox" class="custom-switch-input"
                              id="mini_sidebar_setting"> <span
                              class="custom-switch-indicator"></span>
                           </label>
                        </div>
                     </div>
                     <div class="mt-3 mb-3 align-center">
                        <a href="#"
                           class="btn btn-icon icon-left btn-outline-primary btn-restore-theme">
                        <i class="fas fa-undo"></i> Restore Default
                        </a>
                     </div>
                  </div>
               </div>
            </div>
            <footer class="main-footer">
               <div class="footer-left">
                  Copyright &copy; 2022 
                  <div class="bullet"></div>
                  Design By <a href="#">Snkthemes</a>
               </div>
               <div class="footer-right">
               </div>
            </footer>
         </div>
      </div>
      <!-- General JS Scripts -->
      <script src="assets/js/app.min.js"></script>
      <!-- JS Libraies -->
      <script src="assets/bundles/amcharts4/core.js"></script>
      <script src="assets/bundles/amcharts4/charts.js"></script>
      <script src="assets/bundles/amcharts4/animated.js"></script>
      <script src="assets/bundles/amcharts4/worldLow.js"></script>
      <script src="assets/bundles/amcharts4/maps.js"></script>
      <!-- Page Specific JS File -->
      <script src="assets/js/page/chart-amchart.js"></script>
      <!-- Template JS File -->
      <script src="assets/js/scripts.js"></script>
   </body>
</html>