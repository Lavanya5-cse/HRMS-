<?php include("connection.php");?>
<?php
$empname=$_POST['empname'];
$id=$_POST['id'];
$type=$_POST['type'];
$from=$_POST['from']; 
$to=$_POST['to'];
 $days=$_POST['days'];
 $reason=$_POST['reason'];
$status=$_POST['status'];
$approved=$_POST['approved'];
$mysql="Insert into leaves values('$empname','$id','$type','$from','$to','$days','$reason','$status','$approved')";
if(mysqli_query($con,$mysql))
{
    header("Location:Apply leave.php");
    exit();
}
else{
    echo "Error";
}
mysqli_close($con);
?>

