<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
      <title>Grexa - Admin Dashboard Template</title>
      <!-- General CSS Files -->
      <link rel="stylesheet" href="assets/css/app.min.css">
      <!-- Template CSS -->
      <link rel="stylesheet" href="assets/css/style.css">
      <link rel="stylesheet" href="assets/css/components.css">
      <!-- Custom style CSS -->
      <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.ico' />
   </head>
   <body>
      <div class="loader"></div>
      <div id="app">
         <div class="main-wrapper main-wrapper-1">
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar">
               <div class="form-inline mr-auto">
                  <ul class="navbar-nav mr-3">
                     <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg collapse-btn"><i
                        class="fas fa-bars"></i></a></li>
                     <li>
                     </li>
                  </ul>
               </div>
            </nav>
            <div class="main-sidebar sidebar-style-2">
               <aside id="sidebar-wrapper">
                  <div class="sidebar-brand">
                     <a href="index.html">
                     <img alt="image" src="assets/img/logo.png" class="header-logo" />
                     <span class="logo-name">Grexa</span>
                     </a>
                  </div>
                  <ul class="sidebar-menu">
                  <li class="menu-header">Main</li>
                  <li class="dropdown">
                     <a href="#" class="nav-link has-dropdown"><i class="fas fa-home"></i><span>Dashboard</span></a>
                     <ul class="dropdown-menu">
                        <li><a class="nav-link" href="index.php">Admin Dashboard</a></li>
                     </ul>
                  </li>
                  <li class="dropdown active">
                     <a href="#" class="nav-link has-dropdown"><i class="fas fa-leaf"></i><span>Employee
                     </span></a>
                     <ul class="dropdown-menu">
                        <li class=""><a class="nav-link" href="Employee dashboard.php">Employee Dashboard</a></li>
                        <li class="active"><a class="nav-link" href="Add Employee.php">Add Employee</a></li>
                     </ul>
                  </li>
                  <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Leaves</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Apply leave.php">Apply Leave</a></li>
         <li><a class="nav-link" href="Leave list.php">Leave List</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-anchor"></i><span> Project</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="Project lists.php">Project lists</a></li>
         <li><a class="nav-link" href="Projects_page.php">Projects</a></li>
         </ul>
         </li>
         <li class="dropdown ">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Tickets</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Tickets list.php">Tickets list</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Payroll</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Employee salary.php">Employee salary</a></li>
         <li><a class="nav-link" href="payslip.php">payslip</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Clients</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="Clients_page.php">Client form</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Leads</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Leads.php">Leads</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-hand-point-down"></i><span>Assets</span></a>
         <ul class="dropdown-menu">
         <li>  <a class="nav-link" href="Assests.php">Assets</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Performance</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="performance indicator.php">Performance Indicator</a></li>
         <li><a class="nav-link" href="performance Review.php">Performance Review</a></li>
         <li><a class="nav-link" href="performance Appraisal.php">Performance Appraisal  </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-crosshairs"></i><span>Goals</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="goals-list.php">Goal List</a></li>
         <li><a class="nav-link" href="goals-type.php">Goal type</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-pencil-alt"></i><span>Training</span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="training-list.php">Training List</a></li>
         <li><a class="nav-link" href="Trainers.php">Trainers</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-clipboard-check"></i><span>Jobs</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="job-dashboard.php">Jobs dashboard</a></li>
         <li><a class="nav-link" href="job-manage.php">ManageJobs</a></li>
         <li><a class="nav-link" href="job-resume.php">Manage Resumes</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-user-tie"></i><span>Interviews</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="interview-shortlist.php">Shortlist Candidates</a></li>
         <li><a class="nav-link" href="interview-schedule.php">Schedule time</a></li>
         <li><a class="nav-link" href="interview-offer.php">Offer  Approvals </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-file-alt"></i><span>Special Pages</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="policies.php">Policies</a></li>
         <li><a class="nav-link" href="FAQ.php">FAQ</a></li>
         <li><a class="nav-link" href="Terms of service.php">Terms Of Services</a></li>
         </ul>
         </li>
               </aside>
            </div>
            <!-- Main Content -->
            <div class="main-content">
               <div class="card">
                  <div class="row">
                     <div class="col-md-1"></div>
                     <div class="col-md-3">
                        <div class="text-left mt-4 mb-4 ms-2">
                           <img class="rounded-circle  " src="assets/img/users/user-1.png" width="190px" height="190px">
                        </div>
                     </div>
                     <div class="col-md-3 border-right " style="border: black 2px;">
                        <h5 class=" mt-4 mb-0 d-block text-center text-dark">Global Technologies</h5>
                        <div class="  lead d-block text-center text-dark">Revanth Raj</div>
                        <div class=" text-muted  d-block text-center lead text-dark">IT Dept</div>
                        <div class="    d-block text-center lead text-dark">Employee ID : CLT-0008</div>
                        <div class="text-center mb-5 "> 
                           <button type="button" class="btn btn-info " data-toggle="modal" data-target="#basicModal">
                           Edit Profile
                           </button>
                        </div>
                     </div>
                     <div class="modal fade" id="basicModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog  modal-dialog-centered modal-lg" role="document">
                           <div class="modal-content">
                              <div class="modal-header">
                                 <h5 class="modal-title">Edit employee details</h5>
                                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                 <span aria-hidden="true">&times;</span>
                                 </button>
                              </div>
                              <div class="modal-body">
                                 <div class="card ">
                                    <h4 class="text-center pt-2">Enter Personal Details</h4>
                                    <div class="card-body">
                                       <form action="addemployee1.php" method="post">
                                       <div class="row">
<div class="col-lg-12">
   <ul class="nav nav-tabs " id="myTab2" role="tablist">
      <li class="nav-item">
         <a class="nav-link text-info active" id="home-tab2" data-toggle="tab"
            href="#home2" role="tab" aria-controls="home"
            aria-selected="false">Personal Details</a>
      </li>
      <li class="nav-item">
         <a class="nav-link text-info"   data-toggle="tab"
            href="#profile2" role="tab" aria-controls="profile"
            aria-selected="false">Emergency Contact Details</a>
      </li>
      <li class="nav-item">
         <a class="nav-link text-info" id="Educational-tab2" data-toggle="tab"
            href="#Educational2" role="tab" aria-controls="Educational"
            aria-selected="true">Educational Details</a>
      </li>
      <li class="nav-item">
         <a class="nav-link text-info" id="bank-tab2" data-toggle="tab"
            href="#bank2" role="tab" aria-controls="bank" aria-selected="false">Bank
            Details</a>
      </li>
      <li class="nav-item">
         <a class="nav-link text-info" id="join-tab2" data-toggle="tab"
            href="#join2" role="tab" aria-controls="join"
            aria-selected="false">Joining Details</a>
      </li>
      <li class="nav-item">
         <a class="nav-link text-info" id="pf-tab2" data-toggle="tab" href="#pf2"
            role="tab" aria-controls="pf" aria-selected="false">PF Details</a>
      </li>
   </ul>
   <div class="tab-content tab-bordered" id="myTab3Content">
      <div class="tab-pane active" id="home2" role="tabpanel"
         aria-labelledby="home-tab2">
         <div class="row">
            <div class="col-md-12">
               <h4 class="text-center pt-2">Enter Personal Details</h4>
            </div>
            <div class="col-md-5 col-12 col-sm-12">
               <div class="form-group ">
                  <label class="form-label">
                     Employee Full Name
                      </label><br>
                  <input type="text" class="form-control"
                       name="pname">
               </div>
               <div class="form-group ">
                  <label class=" form-label"> Mobile Number</label>
                  <input type="number" class="form-control" 
                     name="number">
               </div>
               <div class="form-group ">
                  <label class=" form-label"> Country</label>
                  <select class="form-select form-select-lg form-control"
                 name="country">
                     <option></option>
                     <option value="india">India</option>
                  </select>
               </div>
               <div class="form-group ">
                  <label class=" form-label"> Passport Number</label>
                  <input type="text" class="form-control" i
                     name="passport">
               </div>
               <div class="form-group ">
                  <label class=" form-label"> Pan Card number</label>
                  <input type="text" class="form-control"  name="pan">
               </div>
               <div class="form-group ">
                  <label class=" form-label"> City</label>
                  <input type="text" class="form-control" name="city">
               </div>
               <div class="form-group ">
                  <label class=" form-label">  Address</label>
                  <textarea  name="add" rows="4" cols="50"
                     type="text" class="form-control"></textarea>
               </div>
            </div>
            <div class="col-md-2"></div>
            <div class="col-md-5 col-12 col-sm-12">
               <div class="form-group ">
                  <label class="form-label"> personal email id</label>
                  <input type="email" class="form-control"
                     name="email">
               </div>
               <div class="form-group ">
                  <label class=" form-label">Birthday</label>
                  <input type="date" class="form-control" 
                     name="bdy">
               </div>
               <div class="form-group ">
                  <label class=" form-label"> state</label>
                  <select class="form-select form-select-lg form-control"
                      name="state">
                     <option></option>
                     <option value="Buddhism">Andhra Pradesh</option>
                     <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                     <option value="Assam">Assam</option>
                     <option value="Bihar">Bihar</option>
                     <option value="Chhattisgarh">Chhattisgarh</option>
                     <option value="Goa">Goa</option>
                     <option value="Gujarat">Gujarat</option>
                     <option value="Haryana">Haryana</option>
                     <option value="Himachal Pradesh">Himachal Pradesh</option>
                     <option value="Jharkhand">Jharkhand</option>
                     <option value="Karnataka">Karnataka</option>
                     <option value="Kerala">Kerala</option>
                     <option value="Madhya Pradesh">Madhya Pradesh</option>
                     <option value="Maharashtra">Maharashtra</option>
                     <option value="Manipur">Manipur</option>
                     <option value="Meghalaya">Meghalaya</option>
                     <option value="Mizoram">Mizoram</option>
                     <option value="Nagaland">Nagaland</option>
                     <option value="Odisha">Odisha</option>
                     <option value="Punjab">Punjab</option>
                     <option value="Rajasthan">Rajasthan</option>
                     <option value="Sikkim">Sikkim</option>
                     <option value="Tamil Nadu">Tamil Nadu</option>
                     <option value="Telangana">Telangana</option>
                     <option value="Tripura">Tripura</option>
                     <option value="Uttar Pradesh">Uttar Pradesh</option>
                     <option value="Uttarakhand">Uttarakhand</option>
                     <option value="West Bengal">West Bengal</option>
                  </select>
               </div>
               <div class="form-group ">
                  <label for="">Gender</label>
                  
                     <input type="radio" value="male"  name="gen"> Male
                     
                   
                  
                     <input type="radio" value="female"   name="gen">Female

                  
               </div>
               <div class="form-group ">
                  <label class=" form-label">Aadhar Card Number</label>
                  <input type="number" class="form-control" 
                     name="aadhar">
               </div>
               <div class="form-group ">
                  <label class=" form-label">Religion</label>
                  <select class="form-select form-select-lg form-control"
                      name="religion">
                     <option></option>
                     <option value="Buddhism">Buddhism</option>
                     <option value="Christianity">Christianity</option>
                     <option value="Confucianism">Confucianism</option>
                     <option value="Gnosticism">Gnosticism</option>
                     <option value="Hinduism">Hinduism</option>
                  </select>
               </div>
               <div class="form-group ">
                  <label class=" form-label">Permanent address</label>
                  <textarea name="paddr" rows="4" cols="50"
                     type="text" class="form-control"></textarea>
               </div>
            </div>

         </div>
      </div>
      <!------------------------------------>
      <div class="tab-pane " id="profile2" role="tabpanel"
         aria-labelledby="home-tab2">
         <div class="row">
            <div class="col-md-12">
               <h4 class="text-center pt-3 pb-3">Enter Emergency Contact Details
               </h4>
            </div>
            <div class="col-md-5 col-12 col-sm-12">
               <div class="form-group ">
                  <label class="form-label">
                     Emergency Contact Name1
                     <small>(name in block letters)</small></label><br>
                  <input type="text"  class="form-control"
                     name="ename">
               </div>
               <div class="form-group ">
                  <label class=" form-label">Emergency Contact Number1</label>
                  <input type="number" class="form-control" 
                     name="enum">
               </div>
               <div class="form-group ">
                  <label class=" form-label">Emergency Contact 1 (permanent
                     Address)</label>
                  <textarea  name="eadd" rows="4"
                     cols="50" type="text" class="form-control"></textarea>
               </div>
            </div>
            <div class="col-md-2"></div>
            <div class="col-md-5 col-12 col-sm-12">
               <div class="form-group ">
                  <label class="form-label">
                     Emergency Contact Name2
                     <small>(name in block letters)</small></label><br>
                  <input type="text"  class="form-control"
                     name="ename1">
               </div>
               <div class="form-group ">
                  <label class=" form-label">Emergency Contact Number2</label>
                  <input type="number" class="form-control" 
                     name="enum1">
               </div>
               <div class="form-group ">
                  <label class=" form-label">Emergency Contact 2 (permanent
                     Address)</label>
                  <textarea  name="eadd1" rows="4"
                     cols="50" type="text" class="form-control"></textarea>
               </div>
            </div>

         </div>
      </div>
      <div class="tab-pane " id="Educational2" role="tabpanel"
         aria-labelledby="home-tab2">
         <div class="row">
            <div class="col-md-12">
               <h4 class="text-center pt-3 pb-3">Enter Educational Details</h4>
            </div>
            <div class="col-md-5 col-12 col-sm-12">
               <div class="form-group ">
                  <label class=" form-label">SSC School Name</label>
                  <input type="text" class="form-control"  name="school">
               </div>
               <div class="form-group ">
                  <label class=" form-label">Intermediate</label>
                  <input type="text" class="form-control"  name="inter">
               </div>
               <div class="form-group ">
                  <label class=" form-label">Graduate</label>
                  <input type="text" class="form-control" name="grad">
               </div>
               <div class="form-group ">
                  <label class=" form-label">Post Graduate</label>
                  <input type="text" class="form-control" name="post">
               </div>
               <div class="form-group ">
                  <label class=" form-label">Projects</label>
                  <input type="text" class="form-control"  name="project">
               </div>
            </div>
            <div class="col-md-2"></div>
            <div class="col-md-5 col-12 col-sm-12">
               <div class="form-group ">
                  <label class=" form-label"> SSC Percentage</label>
                  <input type="number" class="form-control"  name="sper">
               </div>
               <div class="form-group ">
                  <label class=" form-label">Inter Percentage</label>
                  <input type="number" class="form-control" name="iper">
               </div>
               <div class="form-group ">
                  <label class=" form-label"> Graduation Percentage</label>
                  <input type="number" class="form-control" name="gper">
               </div>
               <div class="form-group ">
                  <label class=" form-label"> Postgraduation Percentage</label>
                  <input type="number" class="form-control"  name="pper">
               </div>
            </div>
            
         </div>
      </div>
      <div class="tab-pane " id="bank2" role="tabpanel" aria-labelledby="home-tab2">
         <div class="row">
            <div class="col-md-12">
               <h4 class="text-center pt-3 pb-3">Enter Bank Details</h4>
            </div>
            <div class="col-md-5 col-12 col-sm-12">
               <div class="form-group ">
                  <label class=" form-label">Bank Account Name</label>
                  <input type="text" class="form-control" 
                     name="bank">
               </div>
               <div class="form-group ">
                  <label class=" form-label">Account Number</label>
                  <input type="text" class="form-control"
                     name="acc">
               </div>
               <div class="form-group ">
                  <label class=" form-label">Branch</label>
                  <input type="text" class="form-control"
                     name="branch">
               </div>
            </div>
            <div class="col-md-2"></div>
            <div class="col-md-5 col-12 col-sm-12">
               <div class="form-group ">
                  <label class=" form-label">Full Bank Name</label>
                  <input type="text" class="form-control" 
                     name="bankname">
               </div>
               <div class="form-group ">
                  <label class=" form-label">IFC Code</label>
                  <input type="text" class="form-control"
                     name="ifsc">
               </div>
               <div class="form-group ">
                  <label class=" form-label">bank Code</label>
                  <input type="text" class="form-control" 
                     name="code">
               </div>
            </div>
            
         </div>
      </div>
      <div class="tab-pane " id="join2" role="tabpanel" aria-labelledby="home-tab2">
         <div class="row">
            <div class="col-md-12">
               <h4 class="text-center pt-3 pb-3">Enter Joining Details</h4>
            </div>
            <div class="col-md-5 col-12 col-sm-12">
               <div class="form-group ">
                  <label class=" form-label">Joining Date</label>
                  <input type="date" class="form-control" 
                     name="joining">
               </div>
               <div class="form-group ">
                  <label class=" form-label">Employee Id</label>
                  <input type="text" class="form-control" 
                     name="eid">
               </div>
               <div class="form-group ">
                  <label class=" form-label"> Manager Name</label>
                  <input type="text" class="form-control" 
                     name="manager">
               </div>
            </div>
            <div class="col-md-2"></div>
            <div class="col-md-5 col-12 col-sm-12">
               <div class="form-group row">
                  <label class=" form-label">Joining Position</label>
                  <input type="text" class="form-control" 
                     name="join">
               </div>
               <div class="form-group row">
                  <label class=" form-label">Email Id</label>
                  <input type="text" class="form-control"
                     name="jemail">
               </div>
               <div class="form-group row">
                  <label class=" form-label"> Project Name</label>
                  <input type="text" class="form-control"
                     name="jpro">
               </div>
            </div>
            
         </div>
      </div>
      <div class="tab-pane " id="pf2" role="tabpanel" aria-labelledby="home-tab2">
         <div class="row">
            <div class="col-md-12">
               <h4 class="text-center pt-3 pb-3">Enter Pf Details</h4>
            </div>
            <div class="col-md-5 col-12 col-sm-12">
               <div class="form-group ">
                  <label class=" form-label">Pf Number</label>
                  <input type="text" class="form-control"  name="pfname">
               </div>
               <div class="form-group ">
                  <label class=" form-label">UAN Number</label>
                  <input type="text" class="form-control"  
                     name="uan">
               </div>
               <div class="form-group ">
                  <label class=" form-label">ESI Number</label>
                  <input type="text" class="form-control" 
                     name="esi">
               </div>
            </div>
            <div class="col-md-2"></div>
            <div class="col-md-5 col-12 col-sm-12">
               <div class="form-group ">
                  <label class=" form-label">PF Account Name</label>
                  <input type="text" class="form-control"  
                     name="pfacc">
               </div>
               <div class="form-group ">
                  <label class=" form-label">PF Branch</label>
                  <input type="text" class="form-control"  
                     name="pfbranch">
               </div>
               <div class="form-group ">
                  <label class=" form-label">ESI Branch</label>
                  <input type="text" class="form-control"  
                     name="esibranch">
               </div>
            </div>
            <div class="card-footer text-right">
               <button type="submit" class="btn btn-primary"
                 >Submit</button>
               <button type="button" class="btn btn-secondary"
                  data-dismiss="modal">Close</button>
            </div>
         </div>
      </div>
   </div>
</div>
</div>
<!---------------------------------->
                              </form>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-4 ">
                        <ul class="list-unstyled mt-4  ">
                           <li><span class="  w-25  font-weight-bold  lead text-dark me-5">Phone:</span>
                              <span class=" text-dark ms-5 lead me-5 "><a href="#">9876543210</a></span>
                           </li>
                           <li><span class="  w-25  font-weight-bold  lead text-dark me-5">Email:</span>
                              <span class=" text-dark ms-5 lead me-5 "><a href="#">barrycuda@example.com</a></span>
                           </li>
                           <li><span class="  w-25  font-weight-bold  lead text-dark me-5">Birthday:</span>
                              <span class=" text-dark ms-5 lead me-5 ">2nd August</span>
                           </li>
                           <li><span class="  w-25  font-weight-bold  lead text-dark me-5">Address:</span><span
                              class=" text-dark ms-5 lead me-5 ">5754 Airport Rd, Coosada, AL, 36020</span></li>
                           <li><span class="  w-25  font-weight-bold  lead text-dark me-5">Gender:</span>
                              <span class=" text-dark ms-5 lead me-5 ">Male</span>
                           </li>
                           <li><span class="  w-25  font-weight-bold  lead text-dark me-5">Employee Id:</span>
                              <span class=" text-dark ms-5 lead me-5 ">IN901786</span>
                           </li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="card">
                  <div class="card-body">
                     <div class="row">
                        <div class="col-xs-8">
                           <ul class="nav nav-tabs " id="myTab2" role="tablist" >
                              <li class="nav-item">
                                 <a class="nav-link text-info active" id="home-tab1" data-toggle="tab" href="#home1" role="tab" aria-controls="home" aria-selected="false">Personal Details</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link text-info" id="profile-tab1" data-toggle="tab" href="#profile1" role="tab" aria-controls="profile" aria-selected="false">Emergency Contact Details</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link text-info" id="Educational-tab1" data-toggle="tab" href="#Educational1" role="tab" aria-controls="Educational" aria-selected="true">Educational Details</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link text-info" id="bank-tab1" data-toggle="tab" href="#bank1" role="tab" aria-controls="bank" aria-selected="false">Bank Details</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link text-info" id="join-tab1" data-toggle="tab" href="#join1" role="tab" aria-controls="join" aria-selected="false">Joining Details</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link text-info" id="pf-tab1" data-toggle="tab" href="#pf1" role="tab" aria-controls="pf" aria-selected="false">PF Details</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link text-info" id="home-tab4" data-toggle="tab" href="#myprojects" role="tab"
                                    aria-controls="feb" aria-selected="true">Projects</a>
                              </li>
                           </ul>
                           <div class="tab-content tab-bordered" id="myTab3Content">
                              <div class="tab-pane active" id="home1" role="tabpanel" aria-labelledby="home-tab1">
                                 <div class="row">
                                    <div class="col-md-8">
                                       <strong>
                                          <h4 class="text-blue text-center">Personal Information</h4>
                                       </strong>
                                       <table class="table table-bordered table-striped table-hover">
                                          <thead></thead>
                                          <tbody>
                                             <tr>
                                                <td>Employee Full Name
                                                   (name in block letters)
                                                </td>
                                                <td class="text-dark">Revanth Raj</td>
                                             </tr>
                                             <tr>
                                                <td> personal email id</td>
                                                <td class="text-dark">barrycuda@example.com</td>
                                             </tr>
                                             <tr>
                                                <td>Mobile Number</td>
                                                <td class="text-dark"> 9876543210</td>
                                             </tr>
                                             <tr>
                                                <td>Birthday</td>
                                                <td class="text-dark">08-agu-1998</td>
                                             </tr>
                                             <tr>
                                                <td> Country</td>
                                                <td class="text-dark">India</td>
                                             </tr>
                                             <tr>
                                                <td> State</td>
                                                <td class="text-dark">Telangana</td>
                                             </tr>
                                             <tr>
                                                <td> Address</td>
                                                <td class="text-dark">5754 Airport Rd, Coosada, AL, 36020</td>
                                             </tr>
                                             <tr>
                                                <td> Gender</td>
                                                <td class="text-dark">Male</td>
                                             </tr>
                                             <tr>
                                                <td> Pan Card number</td>
                                                <td class="text-dark">ODEL21a233</td>
                                             </tr>
                                             <tr>
                                                <td>Addhar Card Number</td>
                                                <td class="text-dark">1111-2222-3333</td>
                                             </tr>
                                             <tr>
                                                <td> Marital status</td>
                                                <td class="text-dark">Unmarried</td>
                                             </tr>
                                             <tr>
                                                <td> City</td>
                                                <td class="text-dark">Warangal</td>
                                             </tr>
                                             <tr>
                                                <td>Religion</td>
                                                <td class="text-dark">Hindu</td>
                                             </tr>
                                             <tr>
                                                <td> Passport Number</td>
                                                <td class="text-dark"> 13124358745945</td>
                                             </tr>
                                             <tr>
                                                <td> permanent address</td>
                                                <td class="text-dark"> 2, Township, NJ, 08759</td>
                                             </tr>
                                          </tbody>
                                       </table>
                                    </div>
                                    <div class="col-md-4 bg-blue">
                                       <h3 class="text-danger align-center ">Managment Flow</h3>
                                       <div class="timeline-activity">
                                          <ul class="list-unstyled align-center  ">
                                             <li class="lead activity-item1">
                                                <span>Managing Director</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-2.png" alt="...">
                                                </figure>
                                                <p>Rahul</p>
                                             </li>
                                             <li class="lead activity-item2">
                                                <span>CEO</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-4.png" alt="...">
                                                </figure>
                                                <p>Peter Smith</p>
                                             </li>
                                             <li class="lead activity-item3">
                                                <span>QA Lead</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-3.png" alt="...">
                                                </figure>
                                                <p>Luke James</p>
                                             </li>
                                             <li class="lead activity-item4">
                                                <span>Team Lead</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-5.png" alt="...">
                                                </figure>
                                                <p>Susan</p>
                                             </li>
                                             <li class="lead activity-item1">
                                                <span>Sr.AnalystTeam</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-1.png" alt="...">
                                                </figure>
                                                <p>Revanth Raj</p>
                                             </li>
                                          </ul>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-md-12">
                                       <div class="card">
                                          <div class="card-header">
                                             <h4>Skills</h4>
                                          </div>
                                          <div class="card-body">
                                             <ul class="list-unstyled user-progress list-unstyled-border list-unstyled-noborder">
                                                <li class="media">
                                                   <div class="media-body">
                                                      <div class="media-title">Java</div>
                                                   </div>
                                                   <div class="media-progressbar p-t-5">
                                                      <div class="progress" data-height="15" style="height: 15px;">
                                                         <div
                                                            class="progress-bar bg-primary progress-bar-striped progress-bar-animated"
                                                            data-width="70%" style="width: 70%;">70%</div>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li class="media">
                                                   <div class="media-body">
                                                      <div class="media-title">Web Design</div>
                                                   </div>
                                                   <div class="media-progressbar p-t-5">
                                                      <div class="progress" data-height="15" style="height: 15px;">
                                                         <div
                                                            class="progress-bar bg-warning progress-bar-striped progress-bar-animated"
                                                            data-width="80%" style="width: 80%;">80%</div>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li class="media">
                                                   <div class="media-body">
                                                      <div class="media-title">Photoshop</div>
                                                   </div>
                                                   <div class="media-progressbar p-t-5">
                                                      <div class="progress" data-height="15" style="height: 15px;">
                                                         <div
                                                            class="progress-bar bg-success progress-bar-striped progress-bar-animated"
                                                            data-width="48%" style="width: 48%;">48%</div>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li class="media">
                                                   <div class="media-body">
                                                      <div class="media-title">Python</div>
                                                   </div>
                                                   <div class="media-progressbar p-t-5">
                                                      <div class="progress" data-height="15" style="height: 15px;">
                                                         <div class="progress-bar bg-red progress-bar-striped progress-bar-animated"
                                                            data-width="60%" style="width: 60%;">60%</div>
                                                      </div>
                                                   </div>
                                                </li>
                                                <li class="media">
                                                   <div class="media-body">
                                                      <div class="media-title">laravel</div>
                                                   </div>
                                                   <div class="media-progressbar p-t-5">
                                                      <div class="progress" data-height="15" style="height: 15px;">
                                                         <div class="progress-bar bg-blue progress-bar-striped progress-bar-animated"
                                                            data-width="30%" style="width: 30%;">30%</div>
                                                      </div>
                                                   </div>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="tab-pane fade" id="profile1" role="tabpanel" aria-labelledby="profile-tab1">
                                 <div class="row">
                                    <div class="col-md-8">
                                       <strong>
                                          <h4 class="text-blue text-center">Emergency contact details</h4>
                                       </strong>
                                       <table class="table table-bordered table-striped table-hover">
                                          <thead></thead>
                                          <tbody>
                                             <tr>
                                                <td>Emergency Contact Name1</td>
                                                <td class="text-dark">Ram</td>
                                             </tr>
                                             <tr>
                                                <td> Emergency Contact Number1</td>
                                                <td class="text-dark">898753531</td>
                                             </tr>
                                             <tr>
                                                <td>Emergency Contact Number (permanent Address)1</td>
                                                <td class="text-dark">Vishnupuri , Kazipet</td>
                                             </tr>
                                             <tr>
                                                <td>Emergency Contact Name2</td>
                                                <td class="text-dark">Sita</td>
                                             </tr>
                                             <tr>
                                                <td> Emergency Contact Number2</td>
                                                <td class="text-dark">9121253547</td>
                                             </tr>
                                             <tr>
                                                <td>Emergency Contact Number (permanent Address)2</td>
                                                <td class="text-dark">Vishnupuri , khammam</td>
                                             </tr>
                                          </tbody>
                                       </table>
                                    </div>
                                    <div class="col-md-4 bg-blue">
                                       <h3 class="text-danger align-center ">Managment Flow</h3>
                                       <div class="timeline-activity">
                                          <ul class="list-unstyled align-center  ">
                                             <li class="lead activity-item1">
                                                <span>Managing Director</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-2.png" alt="...">
                                                </figure>
                                                <p>Rahul</p>
                                             </li>
                                             <li class="lead activity-item2">
                                                <span>CEO</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-4.png" alt="...">
                                                </figure>
                                                <p>Peter Smith</p>
                                             </li>
                                             <li class="lead activity-item3">
                                                <span>QA Lead</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-3.png" alt="...">
                                                </figure>
                                                <p>Luke James</p>
                                             </li>
                                             <li class="lead activity-item4">
                                                <span>Team Lead</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-5.png" alt="...">
                                                </figure>
                                                <p>Susan</p>
                                             </li>
                                             <li class="lead activity-item1">
                                                <span>Sr.AnalystTeam</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-1.png" alt="...">
                                                </figure>
                                                <p>Revanth Raj</p>
                                             </li>
                                          </ul>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="tab-pane fade" id="Educational1" role="tabpanel" aria-labelledby="Educational-tab1">
                                 <div class="row">
                                    <div class="col-md-8">
                                       <strong>
                                          <h4 class="text-blue text-center">Educational details</h4>
                                       </strong>
                                       <table class="table table-bordered table-striped table-hover">
                                          <thead></thead>
                                          <tbody>
                                             <tr>
                                                <td>SSC School Name</td>
                                                <td class="text-dark">SR High School</td>
                                             </tr>
                                             <tr>
                                                <td> Obtain Grade / Percentage</td>
                                                <td class="text-dark">'A' Grade</td>
                                             </tr>
                                             <tr>
                                                <td>Intermediate</td>
                                                <td class="text-dark">Medha Jr College</td>
                                             </tr>
                                             <tr>
                                                <td>Obtain Grade / Percentage</td>
                                                <td class="text-dark">90%</td>
                                             </tr>
                                             <tr>
                                                <td>Graduate</td>
                                                <td class="text-dark">SR University</td>
                                             </tr>
                                             <tr>
                                                <td>Obtain Grade / Percentage</td>
                                                <td class="text-dark">91%</td>
                                             </tr>
                                             <tr>
                                                <td>Post Graduate</td>
                                                <td class="text-dark">Kakatiya University</td>
                                             </tr>
                                             <tr>
                                                <td>Obtain Grade / Percentage</td>
                                                <td class="text-dark">70%</td>
                                             </tr>
                                             <tr>
                                                <td>Projects</td>
                                                <td class="text-dark">Tata Motors</td>
                                             </tr>
                                          </tbody>
                                       </table>
                                    </div>
                                    <div class="col-md-4 bg-blue">
                                       <h3 class="text-danger align-center ">Managment Flow</h3>
                                       <div class="timeline-activity">
                                          <ul class="list-unstyled align-center  ">
                                             <li class="lead activity-item1">
                                                <span>Managing Director</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-2.png" alt="...">
                                                </figure>
                                                <p>Rahul</p>
                                             </li>
                                             <li class="lead activity-item2">
                                                <span>CEO</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-4.png" alt="...">
                                                </figure>
                                                <p>Peter Smith</p>
                                             </li>
                                             <li class="lead activity-item3">
                                                <span>QA Lead</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-3.png" alt="...">
                                                </figure>
                                                <p>Luke James</p>
                                             </li>
                                             <li class="lead activity-item4">
                                                <span>Team Lead</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-5.png" alt="...">
                                                </figure>
                                                <p>Susan</p>
                                             </li>
                                             <li class="lead activity-item1">
                                                <span>Sr.AnalystTeam</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-1.png" alt="...">
                                                </figure>
                                                <p>Revanth Raj</p>
                                             </li>
                                          </ul>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="tab-pane fade " id="bank1" role="tabpanel" aria-labelledby="bank-tab1">
                                 <div class="row">
                                    <div class="col-md-8">
                                       <strong>
                                          <h4 class="text-blue text-center">Bank details</h4>
                                       </strong>
                                       <table class="table table-bordered table-striped table-hover">
                                          <thead></thead>
                                          <tbody>
                                             <tr>
                                                <td>
                                                   Bank Account Name
                                                </td>
                                                <td class="text-dark">Revanth Raj</td>
                                             </tr>
                                             <tr>
                                                <td> Full Bank Name</td>
                                                <td class="text-dark">HDFC Bank</td>
                                             </tr>
                                             <tr>
                                                <td>Account Number</td>
                                                <td class="text-dark">12321 12113</td>
                                             </tr>
                                             <tr>
                                                <td>IFC Code</td>
                                                <td class="text-dark">HDFC0000368</td>
                                             </tr>
                                             <tr>
                                                <td> Branch</td>
                                                <td class="text-dark">Hyderabad - Nacharam</td>
                                             </tr>
                                             <tr>
                                                <td>Bank Code</td>
                                                <td class="text-dark">	000368</td>
                                             </tr>
                                          </tbody>
                                       </table>
                                    </div>
                                    <div class="col-md-4 bg-blue">
                                       <h3 class="text-danger align-center ">Managment Flow</h3>
                                       <div class="timeline-activity">
                                          <ul class="list-unstyled align-center  ">
                                             <li class="lead activity-item1">
                                                <span>Managing Director</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-2.png" alt="...">
                                                </figure>
                                                <p>Rahul</p>
                                             </li>
                                             <li class="lead activity-item2">
                                                <span>CEO</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-4.png" alt="...">
                                                </figure>
                                                <p>Peter Smith</p>
                                             </li>
                                             <li class="lead activity-item3">
                                                <span>QA Lead</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-3.png" alt="...">
                                                </figure>
                                                <p>Luke James</p>
                                             </li>
                                             <li class="lead activity-item4">
                                                <span>Team Lead</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-5.png" alt="...">
                                                </figure>
                                                <p>Susan</p>
                                             </li>
                                             <li class="lead activity-item1">
                                                <span>Sr.AnalystTeam</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-1.png" alt="...">
                                                </figure>
                                                <p>Revanth Raj</p>
                                             </li>
                                          </ul>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="tab-pane fade " id="join1" role="tabpanel" aria-labelledby="join-tab1">
                                 <div class="row">
                                    <div class="col-md-8">
                                       <strong>
                                          <h4 class="text-blue text-center">Joining details</h4>
                                       </strong>
                                       <table class="table table-bordered table-striped table-hover">
                                          <thead></thead>
                                          <tbody>
                                             <tr>
                                                <td>
                                                   Joining Date
                                                </td>
                                                <td class="text-dark">01/agu/2022</td>
                                             </tr>
                                             <tr>
                                                <td> Joining Position</td>
                                                <td class="text-dark">UI Developer</td>
                                             </tr>
                                             <tr>
                                                <td>Employee Id</td>
                                                <td class="text-dark">IN901786</td>
                                             </tr>
                                             <tr>
                                                <td>Email Id</td>
                                                <td class="text-dark"> barrycuda@example.com</td>
                                             </tr>
                                             <tr>
                                                <td> Manager Name</td>
                                                <td class="text-dark">Karthik</td>
                                             </tr>
                                             <tr>
                                                <td>Project Name</td>
                                                <td class="text-dark">HRMS</td>
                                             </tr>
                                          </tbody>
                                       </table>
                                    </div>
                                    <div class="col-md-4 bg-blue">
                                       <h3 class="text-danger align-center ">Managment Flow</h3>
                                       <div class="timeline-activity">
                                          <ul class="list-unstyled align-center  ">
                                             <li class="lead activity-item1">
                                                <span>Managing Director</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-2.png" alt="...">
                                                </figure>
                                                <p>Rahul</p>
                                             </li>
                                             <li class="lead activity-item2">
                                                <span>CEO</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-4.png" alt="...">
                                                </figure>
                                                <p>Peter Smith</p>
                                             </li>
                                             <li class="lead activity-item3">
                                                <span>QA Lead</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-3.png" alt="...">
                                                </figure>
                                                <p>Luke James</p>
                                             </li>
                                             <li class="lead activity-item4">
                                                <span>Team Lead</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-5.png" alt="...">
                                                </figure>
                                                <p>Susan</p>
                                             </li>
                                             <li class="lead activity-item1">
                                                <span>Sr.AnalystTeam</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-1.png" alt="...">
                                                </figure>
                                                <p>Revanth Raj</p>
                                             </li>
                                          </ul>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="tab-pane fade " id="pf1" role="tabpanel" aria-labelledby="pf-tab1">
                                 <div class="row">
                                    <div class="col-md-8">
                                       <strong>
                                          <h4 class="text-blue text-center">PF details</h4>
                                       </strong>
                                       <table class="table table-bordered table-striped table-hover">
                                          <thead></thead>
                                          <tbody>
                                             <tr>
                                                <td>
                                                   PF Number
                                                </td>
                                                <td class="text-dark">101e1e11</td>
                                             </tr>
                                             <tr>
                                                <td> PF Account Name</td>
                                                <td class="text-dark">Revanth Raj</td>
                                             </tr>
                                             <tr>
                                                <td>UAN Number</td>
                                                <td class="text-dark">10130121012</td>
                                             </tr>
                                             <tr>
                                                <td>PF Branch</td>
                                                <td class="text-dark"> Hyderabad</td>
                                             </tr>
                                             <tr>
                                                <td> ESI Number</td>
                                                <td class="text-dark">1033282</td>
                                             </tr>
                                             <tr>
                                                <td>ESI Branch</td>
                                                <td class="text-dark">Hyderabad</td>
                                             </tr>
                                          </tbody>
                                       </table>
                                    </div>
                                    <div class="col-md-4 bg-blue">
                                       <h3 class="text-danger align-center ">Managment Flow</h3>
                                       <div class="timeline-activity">
                                          <ul class="list-unstyled align-center  ">
                                             <li class="lead activity-item1">
                                                <span>Managing Director</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-2.png" alt="...">
                                                </figure>
                                                <p>Rahul</p>
                                             </li>
                                             <li class="lead activity-item2">
                                                <span>CEO</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-4.png" alt="...">
                                                </figure>
                                                <p>Peter Smith</p>
                                             </li>
                                             <li class="lead activity-item3">
                                                <span>QA Lead</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-3.png" alt="...">
                                                </figure>
                                                <p>Luke James</p>
                                             </li>
                                             <li class="lead activity-item4">
                                                <span>Team Lead</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-5.png" alt="...">
                                                </figure>
                                                <p>Susan</p>
                                             </li>
                                             <li class="lead activity-item1">
                                                <span>Sr.AnalystTeam</span><br>
                                                <figure class="avatar round mr-2">
                                                   <img src="assets/img/users/user-1.png" alt="...">
                                                </figure>
                                                <p>Revanth Raj</p>
                                             </li>
                                          </ul>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="tab-pane fade" id="myprojects" role="tabpanel">
                                 <div class="row text-dark">
                                    <div class="col-md-4 col-sm-6 col-12 flex" style="margin-bottom:30px;">
                                       <div class="card flex-fill h-100" width="1.8rem">
                                          <div class="card-header border-0">
                                             <h4>Office Management</h4>
                                          </div>
                                          <div class="card-header">
                                             <div class="block text-ellipsis m-b-15">
                                                <span _ngcontent-tqd-c60="" class="text-xs">1</span>
                                                <span _ngcontent-tqd-c60="" class="text-muted">open tasks, </span>
                                                <span ngcontent-tqd-c60="" class="text-xs">9</span><span ngcontent-tqd-c60=""
                                                   class="text-muted">tasks completed</span>
                                             </div>
                                          </div>
                                          <div class="card-body card-type-4">
                                             <p class="card-text ">
                                                Office management is a profession involving the design, implementation, evaluation, and
                                                maintenance of the process of work within an office or other organization,
                                                in order to sustain and improve efficiency and productivity.
                                             </p>
                                             <h6 class="card-title">Deadline:</h6>
                                             <h6 class="card-subtitle text-muted">17-11-2022</h6>
                                             <br>
                                             <h6 class="card-title">Project leader:</h6>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-5.png" alt="...">
                                             </figure>
                                             <h6 class="card-title">Team</h6>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-3.png" alt="...">
                                             </figure>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-3.png" alt="...">
                                             </figure>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-3.png" alt="...">
                                             </figure>
                                             <h6 class="card-title">Progress:<a href=""
                                                style="color:green; margin-left:180px;text-decoration: none;"> 40%</a></h6>
                                             <div class="progress">
                                                <div class="progress-bar bg-success" role="progressbar" aria-label="Basic example"
                                                   style="width: 35%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6 col-12 flex" style="margin-bottom:30px;">
                                       <div class="card flex-fill h-100" width="1.8rem">
                                          <div class="card-header border-0">
                                             <h4>Hospital Administration</h4>
                                          </div>
                                          <div class="card-header">
                                             <div class="block text-ellipsis m-b-15">
                                                <span _ngcontent-tqd-c60="" class="text-xs">3</span>
                                                <span _ngcontent-tqd-c60="" class="text-muted">open tasks, </span>
                                                <span ngcontent-tqd-c60="" class="text-xs">15</span><span ngcontent-tqd-c60=""
                                                   class="text-muted">tasks completed</span>
                                             </div>
                                          </div>
                                          <div class="card-body card-type-4">
                                             <p class="card-text h-98">Our project Hospital Management system includes registration of
                                                patients, storing their details into the system, and also booking their appointments
                                                with doctors.
                                             </p>
                                             <h6 class="card-title ">Deadline:</h6>
                                             <h6 class="card-subtitle text-muted">12-11-2022</h6>
                                             <br>
                                             <h6 class="card-title">Project leader:</h6>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-5.png" alt="...">
                                             </figure>
                                             <h6 class="card-title">Team</h6>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-3.png" alt="...">
                                             </figure>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-3.png" alt="...">
                                             </figure>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-3.png" alt="...">
                                             </figure>
                                             <h6 class="card-title">Progress:<a href=""
                                                style="color:green; margin-left:180px;text-decoration: none;"> 20%</a></h6>
                                             <div class="progress">
                                                <div class="progress-bar bg-success" role="progressbar" aria-label="Basic example"
                                                   style="width: 25%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6 col-12 flex" style="margin-bottom:30px;">
                                       <div class="card flex-fill h-100" width="1.8rem">
                                          <div class="card-header border-0">
                                             <h4>Project Management</h4>
                                          </div>
                                          <div class="card-header">
                                             <div class="block text-ellipsis m-b-15">
                                                <span _ngcontent-tqd-c60="" class="text-xs">2</span>
                                                <span _ngcontent-tqd-c60="" class="text-muted">open tasks, </span>
                                                <span ngcontent-tqd-c60="" class="text-xs">9</span><span ngcontent-tqd-c60=""
                                                   class="text-muted">tasks completed</span>
                                             </div>
                                          </div>
                                          <div class="card-body card-type-4 ">
                                             <p class="card-text">Project managers are involved in various daily tasks that primarily
                                                include dealing with people across teams and organizational hierarchies. They have to
                                                run through a daily checklist of monitoring the progress of projects, optimizing the
                                                critical paths, and resolving blocking issues that the teams may be facing.
                                             </p>
                                             <h6 class="card-title">Deadline:</h6>
                                             <h6 class="card-subtitle text-muted">1-12-2022</h6>
                                             <br>
                                             <h6 class="card-title">Project leader:</h6>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-5.png" alt="...">
                                             </figure>
                                             <h6 class="card-title">Team</h6>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-3.png" alt="...">
                                             </figure>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-3.png" alt="...">
                                             </figure>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-3.png" alt="...">
                                             </figure>
                                             <h6 class="card-title">Progress:<a href=""
                                                style="color:green; margin-left:180px;text-decoration: none;"> 70%</a></h6>
                                             <div class="progress">
                                                <div class="progress-bar bg-success" role="progressbar" aria-label="Basic example"
                                                   style="width: 75%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6 col-12">
                                       <div class="card flex-fill h-100" width="1.8rem">
                                          <div class="card-header border-0">
                                             <h4>Video Calling App</h4>
                                          </div>
                                          <div class="card-header">
                                             <div class="block text-ellipsis m-b-15">
                                                <span   class="text-xs">5</span>
                                                <span   class="text-muted">open tasks, </span>
                                                <span   class="text-xs">13</span><span  
                                                   class="text-muted">tasks completed</span>
                                             </div>
                                          </div>
                                          <div class="card-body">
                                             <p class="card-text">video call feature has become standard in person-to-person (P2P)
                                                mobile communication apps like WhatsApp and Viber. These messaging apps are mostly used
                                                on mobile. On the other hand, business apps like Skype and Zoom offer video call
                                                functions on mobile, desktop, and web.
                                             </p>
                                             <h6 class="card-title">Deadline:</h6>
                                             <h6 class="card-subtitle text-muted">07-12-2022</h6>
                                             <br>
                                             <h6 class="card-title">Project leader:</h6>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-5.png" alt="...">
                                             </figure>
                                             <h6 class="card-title">Team</h6>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-3.png" alt="...">
                                             </figure>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-3.png" alt="...">
                                             </figure>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-3.png" alt="...">
                                             </figure>
                                             <h6 class="card-title">Progress:<a href=""
                                                style="color:green; margin-left:180px;text-decoration: none;"> 40%</a></h6>
                                             <div class="progress">
                                                <div class="progress-bar bg-success" role="progressbar" aria-label="Basic example"
                                                   style="width: 35%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6 col-12">
                                       <div class="card flex-fill h-100" width="1.8rem">
                                          <div class="card-header border-0">
                                             <h4>Project management</h4>
                                          </div>
                                          <div class="card-header">
                                             <div class="block text-ellipsis m-b-15">
                                                <span   class="text-xs">4</span>
                                                <span class="text-muted">open tasks, </span>
                                                <span   class="text-xs">8</span><span  
                                                   class="text-muted">tasks completed</span>
                                             </div>
                                          </div>
                                          <div class="card-body">
                                             <p class="card-text">project management include conception and initiation, project
                                                planning, project execution, performance/monitoring, and project close.
                                             </p>
                                             <h6 class="card-title">Deadline:</h6>
                                             <h6 class="card-subtitle text-muted">27-09-2022</h6>
                                             <br>
                                             <h6 class="card-title">Project leader:</h6>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-5.png" alt="...">
                                             </figure>
                                             <h6 class="card-title">Team</h6>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-3.png" alt="...">
                                             </figure>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-3.png" alt="...">
                                             </figure>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-3.png" alt="...">
                                             </figure>
                                             <h6 class="card-title">Progress:<a href=""
                                                style="color:green; margin-left:180px;text-decoration: none;"> 80%</a></h6>
                                             <div class="progress">
                                                <div class="progress-bar bg-success" role="progressbar" aria-label="Basic example"
                                                   style="width: 80%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-md-4 col-sm-6 col-12">
                                       <div class="card flex-fill h-100" width="1.8rem">
                                          <div class="card-header border-0">
                                             <h4>Office Management</h4>
                                          </div>
                                          <div class="card-header">
                                             <div class="block text-ellipsis m-b-15">
                                                <span  class="text-xs">9</span>
                                                <span   class="text-muted">open tasks, </span>
                                                <span   class="text-xs">20</span><span 
                                                   class="text-muted">tasks completed</span>
                                             </div>
                                          </div>
                                          <div class="card-body">
                                             <p class="card-text">Office management is the technique of planning, organizing,
                                                coordinating and controlling office activities with a view to achieve business
                                                objectives and is concerned with efficient and effective performance of the office work.
                                             </p>
                                             <h6 class="card-title">Deadline:</h6>
                                             <h6 class="card-subtitle text-muted">16-12-2022</h6>
                                             <br>
                                             <h6 class="card-title">Project leader:</h6>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-5.png" alt="...">
                                             </figure>
                                             <h6 class="card-title">Team</h6>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-3.png" alt="...">
                                             </figure>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-3.png" alt="...">
                                             </figure>
                                             <figure class="avatar round mr-2">
                                                <img src="assets/img/users/user-3.png" alt="...">
                                             </figure>
                                             <h6 class="card-title">Progress:<a href=""
                                                style="color:green; margin-left:180px;text-decoration: none;"> 50%</a></h6>
                                             <div class="progress">
                                                <div class="progress-bar bg-success" role="progressbar" aria-label="Basic example"
                                                   style="width: 55%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="settingSidebar">
               <a href="javascript:void(0)" class="settingPanelToggle"> <i
                  class="fa fa-spin fa-cog"></i>
               </a>
               <div class="settingSidebar-body ps-container ps-theme-default">
                  <div class=" fade show active">
                     <div class="setting-panel-header">Theme Customizer</div>
                     <div class="p-15 border-bottom">
                        <h6 class="font-medium m-b-10">Theme Layout</h6>
                        <div class="selectgroup layout-color w-50">
                           <label> <span class="control-label p-r-20">Light</span>
                           <input type="radio" name="custom-switch-input" value="1"
                              class="custom-switch-input" checked> <span
                              class="custom-switch-indicator"></span>
                           </label>
                        </div>
                        <div class="selectgroup layout-color  w-50">
                           <label> <span class="control-label p-r-20">Dark&nbsp;</span>
                           <input type="radio" name="custom-switch-input" value="2"
                              class="custom-switch-input"> <span
                              class="custom-switch-indicator"></span>
                           </label>
                        </div>
                     </div>
                  </div>
                  <div class="p-15 border-bottom">
                     <h6 class="font-medium m-b-10">Sidebar Colors</h6>
                     <div class="sidebar-setting-options">
                        <ul class="sidebar-color list-unstyled mb-0">
                           <li title="white" class="active">
                              <div class="white"></div>
                           </li>
                           <li title="blue">
                              <div class="blue"></div>
                           </li>
                           <li title="coral">
                              <div class="coral"></div>
                           </li>
                           <li title="purple">
                              <div class="purple"></div>
                           </li>
                           <li title="allports">
                              <div class="allports"></div>
                           </li>
                           <li title="barossa">
                              <div class="barossa"></div>
                           </li>
                           <li title="fancy">
                              <div class="fancy"></div>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="p-15 border-bottom">
                     <h6 class="font-medium m-b-10">Theme Colors</h6>
                     <div class="theme-setting-options">
                        <ul class="choose-theme list-unstyled mb-0">
                           <li title="white" class="active">
                              <div class="white"></div>
                           </li>
                           <li title="blue">
                              <div class="blue"></div>
                           </li>
                           <li title="coral">
                              <div class="coral"></div>
                           </li>
                           <li title="purple">
                              <div class="purple"></div>
                           </li>
                           <li title="allports">
                              <div class="allports"></div>
                           </li>
                           <li title="barossa">
                              <div class="barossa"></div>
                           </li>
                           <li title="fancy">
                              <div class="fancy"></div>
                           </li>
                           <li title="cyan">
                              <div class="cyan"></div>
                           </li>
                           <li title="orange">
                              <div class="orange"></div>
                           </li>
                           <li title="green">
                              <div class="green"></div>
                           </li>
                           <li title="red">
                              <div class="red"></div>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="p-15 border-bottom">
                     <h6 class="font-medium m-b-10">Layout Options</h6>
                     <div class="theme-setting-options">
                        <label> <span class="control-label p-r-20">Compact
                        Sidebar Menu</span> <input type="checkbox"
                           name="custom-switch-checkbox" class="custom-switch-input"
                           id="mini_sidebar_setting"> <span
                           class="custom-switch-indicator"></span>
                        </label>
                     </div>
                  </div>
                  <div class="mt-3 mb-3 align-center">
                     <a href="#"
                        class="btn btn-icon icon-left btn-outline-primary btn-restore-theme">
                     <i class="fas fa-undo"></i> Restore Default
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <footer class="main-footer">
            <div class="footer-left">
               Copyright &copy; 2022 
               <div class="bullet"></div>
               Design By <a href="#">Snkthemes</a>
            </div>
            <div class="footer-right">
            </div>
         </footer>
      </div>
      </div>
      <!-- General JS Scripts -->
      <script src="assets/js/app.min.js"></script>
      <!-- JS Libraies -->
      <!-- Page Specific JS File -->
      <!-- Template JS File -->
      <script src="assets/js/scripts.js"></script>
   </body>
   <script>
      /* country*/
      $("#country10").change(function () {
        $("#country10 option:selected").each(function () {
          if ($(this).prop('selected')) {
            var drop = this.value;
            console.log("selected country" + drop);
          }
        });
      });
      /* state*/
      $("#state10").change(function () {
        $("#state10 option:selected").each(function () {
          if ($(this).prop('selected')) {
            var drop = this.value;
            console.log("selected state" + drop);
          }
        });
      });
      /* religion*/
      $("#Religion10").change(function () {
        $("#Religion10 option:selected").each(function () {
          if ($(this).prop('selected')) {
            var drop = this.value;
            console.log("selected Religion" + drop);
          }
        });
      });
      
      $("#sub10").click(function(){
      $(".error").hide();
      var ename=$("#name10").val();
      var email_pattern= /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
      var email1=$("#email10").val();
      var error=false;
      var phone=$("#mob10").val();
      var country=$("#country10").val();
      var birth=$("#birthday10").val();
      var state=$("#state10").val();
      var passport=$("#pass10").val();
      var gender=document.getElementsByName('gen');
      var aadhar=$("#adhar10").val();
      var pan=$("#pan10").val();
      var city=$("#city10").val();
      var Religion=$("#Religion10").val();
      var tempaddress=$("#paddress10").val();
      var permanentaddress=$("#nadd10").val();
      var emrgcyname=$("#ename10").val();
      var emrgcycontact=$("#econtact10").val();
      var emrgcyadd=$("#eadd10").val();
      var emrgcyname1=$("#sname10").val();
      var emrgcycontact1=$("#scontact10").val();
      var emrgcyadd1=$("#sadd10").val();
      var school=$("#school10").val();
      var Intermediate=$("#inter10").val();
      var Graduate=$("#graduate10").val();
      var PostGraduate=$("#pg10").val();
      var Projects=$("#project10").val();
      var sscobtain=$("#sccob10").val();
      var interobtain=$("#inter0b10").val();
      var graduateobtain=$("#graduateob10").val();
      var postgraduateobtain=$("#pgob10").val();
      var bank=$("#bank10").val();
      var AccountNumber=$("#bkacctno10").val();
      var Branch=$("#branch10").val();
      var FullBankName=$("#bkname10").val();
      var IFCCode=$("#ifsc10").val();
      var bankCode=$("#bkcode10").val();
      
      var joiningdate=$("#joining10").val();
      var JoiningPosition=$("#position10").val();
      var EmployeeId=$("#empid10").val();
      var Emailid=$("#offemail10").val();
      var ManagerName=$("#manager10").val();
      var ProjectName=$("#projectname10").val();
      
      var PfNumber=$("#pf10").val();
      var PFAccountName=$("#pfacct10").val();
      var UANNumber=$("#uan10").val();
      var PFBranch=$("#pfbranch10").val();
      var ESINumber=$("#esi10").val();
      var ESIBranch=$("#esibranch10").val();
      
      
      
      
      console.log("name"+ename); 
      
      if(ename=='')
      {
      $("#name10").after('<div class="error" style="color:red">Please enter full name</div>')
      error=true;
      }
      
      if(email1=='')
      {
        $("#email10").after('<div class="error" style="color:red;">Please enter your email</div>')
        error=true;
      }
      if(!email_pattern.test(email1))
      {
        $("#email10").after('<div class="error" style="color:red;">Please enter your valid email</div>')
        error=true;
      }
      if(phone=='')
      {
        $("#mob10").after('<div class="error" style="color:red">Please enter mobile number</div>')
        error=true;
      }
      if((phone.length>10)||(phone.length<10)&&(phone.length!=0))
      {
        $("#mob10").after('<div class="error" style="color:red">Please enter 10 digit valid mobile number</div>')
        error=true;
      }
      if(country=="")
      {
      $("#country10").after('<div class="error" style="color:red">please select country</div>')
      }
      if(state=="")
      {
      $("#state10").after('<div class="error" style="color:red">please select state</div>')
      }
      if(birth==""){
      $("#birthday10").after('<div class="error" style="color:red">Please select birthday</div>')
      }
      if(passport=="")
      {
      $("#pass10") .after('<div class="error" style="color:red">Please enter passport number</div>')
        error=true;
      }
      if((passport.length>12)||(passport.length<12)&&(passport.length!=0))
      {
        $("#pass10").after('<div class="error" style="color:red">Please enter 12 digit valid passport number</div>')
        error=true;
      }
      if(!(gender[0].checked || gender[1].checked))
      {
        $("#female").after('<div class="error" style="color:red;">Please enter your Gender</div>')
      }
      if(aadhar=="")
      {
      $("#adhar10") .after('<div class="error" style="color:red">Please enter aadhar number</div>')
        error=true;
      }
      if((aadhar.length>12)||(aadhar.length<12)&&(aadhar.length!=0))
      {
        $("#adhar10").after('<div class="error" style="color:red">Please enter 12 digit valid aadhar number</div>')
        error=true;
      }
      if(pan=="")
      {
      $("#pan10") .after('<div class="error" style="color:red">Please enter valid pan number</div>')
        error=true;
      }
      if(city=="")
      {
      $("#city10") .after('<div class="error" style="color:red">Please enter your city name</div>')
        error=true;
      }
      if(Religion=="")
      {
      $("#Religion10") .after('<div class="error" style="color:red">Please select religion</div>')
        error=true;
      }
      if(tempaddress=="")
      {
      $("#paddress10") .after('<div class="error" style="color:red">Please enter temporary address</div>')
        error=true;
      }
      if(permanentaddress=="")
      {
      $("#nadd10") .after('<div class="error" style="color:red">Please enter permanent address</div>')
        error=true;
      }
      if(emrgcyname=="")
      {
      $("#ename10") .after('<div class="error" style="color:red">Please enter emergency contact name </div>')
        error=true;
      }
      if(emrgcycontact=="")
      {
      $("#econtact10") .after('<div class="error" style="color:red">Please enter contact number</div>')
        error=true;
      }
      if((emrgcycontact.length>10)||(emrgcycontact.length<10)&&(emrgcycontact.length!=0))
      {
        $("#econtact10").after('<div class="error" style="color:red">Please enter 10 digit valid mob number</div>')
        error=true;
      }
      if(emrgcyadd=="")
      {
      $("#eadd10") .after('<div class="error" style="color:red">Please enter emergency contact address</div>')
        error=true;
      }
      if(emrgcyname1=="")
      {
      $("#sname10") .after('<div class="error" style="color:red">Please enter emergency contact name </div>')
        error=true;
      }
      if(emrgcycontact1=="")
      {
      $("#scontact10") .after('<div class="error" style="color:red">Please enter contact number</div>')
        error=true;
      }
      if((emrgcycontact1.length>10)||(emrgcycontact1.length<10)&&(emrgcycontact1.length!=0))
      {
        $("#scontact10").after('<div class="error" style="color:red">Please enter 10 digit valid mob number</div>')
        error=true;
      }
      if(emrgcyadd1=="")
      {
      $("#sadd10") .after('<div class="error" style="color:red">Please enter emergency contact address</div>')
        error=true;
      }
      if(school=="")
      {
      $("#school10") .after('<div class="error" style="color:red">Please enter your school name</div>')
        error=true;
      }
      if(Intermediate=="")
      {
      $("#inter10") .after('<div class="error" style="color:red">Please enter your college name</div>')
        error=true;
      }
      if(Graduate=="")
      {
      $("#graduate10") .after('<div class="error" style="color:red">Please enter your college name</div>')
        error=true;
      }
      if(PostGraduate=="")
      {
      $("#pg10") .after('<div class="error" style="color:red">Please enter your college name</div>')
        error=true;
      }
      if(Projects=="")
      {
      $("#project10") .after('<div class="error" style="color:red">Please enter your project name</div>')
        error=true;
      }
      if(sscobtain=='')
      {
        $("#sccob10").after('<div class="error" style="color:red">Please enter ssc percentage </div>')
        error=true;
      }
      if(interobtain=='')
      {
        $("#inter0b10").after('<div class="error" style="color:red">Please enter inter percentage </div>')
        error=true;
      }
      if(graduateobtain=='')
      {
        $("#graduateob10").after('<div class="error" style="color:red">Please enter graduate percentage </div>')
        error=true;
      }
      if(postgraduateobtain=='')
      {
        $("#pgob10").after('<div class="error" style="color:red">Please enter postgraduate percentage </div>')
        error=true;
      }
      if(bank=='')
      {
        $("#bank10").after('<div class="error" style="color:red">Please enter bank name </div>')
        error=true;
      }
      if(AccountNumber=='')
      {
        $("#bkacctno10").after('<div class="error" style="color:red">Please enter bank account number </div>')
        error=true;
      }
      if(Branch=='')
      {
        $("#branch10").after('<div class="error" style="color:red">Please enter branch location </div>')
        error=true;
      }
      if(FullBankName=='')
      {
        $("#bkname10").after('<div class="error" style="color:red">Please enter bank full name </div>')
        error=true;
      }
      if(IFCCode=='')
      {
        $("#ifsc10").after('<div class="error" style="color:red">Please enter ifsc code </div>')
        error=true;
      }
      if(bankCode=='')
      {
        $("#bkcode10").after('<div class="error" style="color:red">Please enter bank code  </div>')
        error=true;
      } 
      if(joiningdate=='')
      {
        $("#joining10").after('<div class="error" style="color:red">Please select joining date  </div>')
        error=true;
      }
      if(JoiningPosition=='')
      {
        $("#position10").after('<div class="error" style="color:red">Please enter position  </div>')
        error=true;
      }
      if(EmployeeId=='')
      {
        $("#empid10").after('<div class="error" style="color:red">Please enter employee id  </div>')
        error=true;
      }
      if(Emailid=='')
      {
        $("#offemail10").after('<div class="error" style="color:red">Please enter company email id  </div>')
        error=true;
      }
      if(!email_pattern.test(Emailid))
      {
        $("#offemail10").after('<div class="error" style="color:red;">Please enter your valid email</div>')
        error=true;
      }
      if(ManagerName=='')
      {
        $("#manager10").after('<div class="error" style="color:red">Please enter manager name  </div>')
        error=true;
      }
      if(ProjectName=='')
      {
        $("#projectname10").after('<div class="error" style="color:red">Please enter recent project name  </div>')
        error=true;
      }
      
      
      if(PfNumber=='')
      {
        $("#pf10").after('<div class="error" style="color:red">Please enter pf number  </div>')
        error=true;
      }
      if(PFAccountName=='')
      {
        $("#pfacct10").after('<div class="error" style="color:red">Please enter pf account name name  </div>')
        error=true;
      }
      if(UANNumber=='')
      {
        $("#uan10").after('<div class="error" style="color:red">Please enter uan number  </div>')
        error=true;
      }
      if(PFBranch=='')
      {
        $("#pfbranch10").after('<div class="error" style="color:red">Please enter pf branch location  </div>')
        error=true;
      }
      if(ESINumber=='')
      {
        $("#esi10").after('<div class="error" style="color:red">Please enter esi number  </div>')
        error=true;
      }
      if(ESIBranch=='')
      {
        $("#esibranch10").after('<div class="error" style="color:red">Please enter esi branch name </div>')
        error=true;
      }
      
      if(error==true)
      {
        return false;
      }
      });
   </script>
</html>