<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
      <title>Grexa - Admin Dashboard Template</title>
      <!-- General CSS Files -->
      <link rel="stylesheet" href="assets/css/app.min.css">
      <!-- Template CSS -->
      <link rel="stylesheet" href="assets/css/style.css">
      <link rel="stylesheet" href="assets/css/components.css">
      <!-- Custom style CSS -->
      <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.ico' />
   </head>
   <body>
      <div class="loader"></div>
      <div id="app">
      <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
      <nav class="navbar navbar-expand-lg main-navbar">
         <div class="form-inline mr-auto">
            <ul class="navbar-nav mr-3">
               <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg collapse-btn"><i
                  class="fas fa-bars"></i></a></li>
               <li>
               </li>
            </ul>
         </div>
         <ul class="navbar-nav navbar-right">
         </ul>
      </nav>
      <div class="main-sidebar sidebar-style-2">
         <aside id="sidebar-wrapper">
            <div class="sidebar-brand">
               <a href="index.html">
               <img alt="image" src="assets/img/logo.png" class="header-logo" />
               <span class="logo-name">Grexa</span>
               </a>
            </div>
            <ul class="sidebar-menu">
            <li class="menu-header">Main</li>
            <li class="dropdown">
                     <a href="#" class="nav-link has-dropdown"><i class="fas fa-home"></i><span>Dashboard</span></a>
                     <ul class="dropdown-menu">
                        <li><a class="nav-link" href="index.php">Admin Dashboard</a></li>
                     </ul>
                  </li>
                  <li class="dropdown ">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-leaf"></i><span>Employee
         </span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="Employee dashboard.php">Employee Dashboard</a></li>
         <li><a class="nav-link" href="Add Employee.php">Add Employee</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Leaves</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Apply leave.php">Apply Leave</a></li>
         <li><a class="nav-link" href="Leave list.php">Leave List</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-anchor"></i><span> Project</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="Project lists.php">Project lists</a></li>
         <li><a class="nav-link" href="Projects_page.php">Projects</a></li>
         </ul>
         </li>
         <li class="dropdown ">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Tickets</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Tickets list.php">Tickets list</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Payroll</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Employee salary.php">Employee salary</a></li>
         <li><a class="nav-link" href="payslip.php">payslip</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Clients</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link " href="Clients_page.php">Client form</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Leads</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Leads.php">Leads</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-hand-point-down"></i><span>Assets</span></a>
         <ul class="dropdown-menu">
         <li>  <a class="nav-link" href="Assests.php">Assets</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Performance</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="performance indicator.php">Performance Indicator</a></li>
         <li><a class="nav-link" href="performance Review.php">Performance Review</a></li>
         <li><a class="nav-link" href="performance Appraisal.php">Performance Appraisal  </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-crosshairs"></i><span>Goals</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="goals-list.php">Goal List</a></li>
         <li><a class="nav-link" href="goals-type.php">Goal type</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-pencil-alt"></i><span>Training</span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="training-list.php">Training List</a></li>
         <li><a class="nav-link" href="Trainers.php">Trainers</a></li>
         </ul>
         </li>
                  <li class="dropdown active">
                     <a href="#" class="nav-link has-dropdown"><i class="fas fa-clipboard-check"></i><span>Jobs</span></a>
                     <ul class="dropdown-menu">
                        <li  ><a class="nav-link" href="job-dashboard.php">Jobs dashboard</a></li>
                        <li><a class="nav-link" href="job-manage.php">ManageJobs</a></li>
                        <li class="active"><a class="nav-link" href="job-resume.php">Manage Resumes</a></li>
                     </ul>
                  </li>
                  
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-user-tie"></i><span>Interviews</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link " href="interview-shortlist.php">Shortlist Candidates</a></li>
         <li><a class="nav-link" href="interview-schedule.php">Schedule time</a></li>
         <li><a class="nav-link" href="interview-offer.php">Offer  Approvals </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-file-alt"></i><span>Special Pages</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="policies.php">Policies</a></li>
         <li><a class="nav-link" href="FAQ.php">FAQ</a></li>
         <li><a class="nav-link" href="Terms of service.php">Terms Of Services</a></li>
         </ul>
         </li>
         </aside>
      </div>
      <!-- Main Content -->
      <div class="main-content">
         <section class="section">
            <div class="section-header">
               <h1>Jobs Details</h1>
               <div class="section-header-breadcrumb">
                  <div class="breadcrumb-item"><a href="index.php">Dashboard</a></div>
                  <div class="breadcrumb-item">Jobs Details</div>
               </div>
            </div>
         </section>
         <div class="card mb-0">
            <div class="card-body">
               <div class="row">
                  <div class="col-md-4">
                     <h5 class=" m-t-0 pl-3 text-info" style="font-size:x-large">Web Developer</h5>
                     <p class=" m-t-0 mb-0 pl-3" style="font-size:larger">Robert Smith</p>
                  </div>
                  <div class="col-md-8 text-right ">
                     <ul style="list-style-type: none;">
                        <li>
                           <span class="title"><b>Phone:</b></span>
                           <span class="text">
                           <a href="" class="text-muted" style="text-decoration:none">(123) 456 789</a></span>
                        </li>
                        <li><span class="title"><b>Email:</b></span>
                           <span class="text">
                           <a href="" >RobertSmith@quikresume.com</a></span>
                        </li>
                        <li><span class="title"><b>Website:</b></span>
                           <span class="text">
                           <a href="">www.qwikresume.com</a></span>
                        </li>
                        <li><span class="title"><b>Linkedin:</b></span>
                           <span class="text">
                           <a href="">linkedin.com/qwikresume</a></span>
                        </li>
                        <li><span class="title"><b>Address:</b></span>
                           <span class="text-muted" >1737 Marshville Road, Alabama</span>
                        </li>
                     </ul>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12">
                     <h5 class=" m-t-0 p-1 bg-light text-danger" style="font: size 25px; border:1px solid black;">Objective</h5>
                     <p>A highly organized and hard-working individual looking for a responsible position to gain practical experience.
                        To make use of my interpersonal skills to achieve goals of a company that focuses on customer satisfaction and customer experience.
                     </p>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12">
                     <h5 class=" m-t-0  p-1 bg-light text-danger" style="font: size 25px; border:1px solid black; background-color: bisque;">Skills</h5>
                     <p>Leadership experience,Collaboration talent,Problem-solving abilities.
                     </p>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12">
                     <h5 class=" m-t-0 p-1 bg-light text-danger" style="font: size 25px; border:1px solid black; background-color: bisque;">Work Experience</h5>
                     <h5 class=" m-t-0 pl-3 text-info" style="font-size:large">Web Developer</h5>
                     <p class=" m-t-0 mb-0 pl-3 "><b>Black Baud -2013-2015</b></p>
                     <ul>
                        <li>Won Employee of the Year twice (2017 and 2019)</li>
                        <li>Earned highest performance ratings across 7 consecutive months for resolving project queries</li>
                        <li> Developed more efficient filing system for customer records</li>
                     </ul>
                     <h5 class=" m-t-0 pl-3 text-info" style="font-size:large">Web Developer</h5>
                     <p class=" m-t-0 mb-0 pl-3"><b>ABC Corporation -2016-2021</b></p>
                     <ul>
                        <li>Maintained updated mailing lists and sent out newsletters and briefings</li>
                        <li>Prepared and sent out invitations for seminars, webinars and conferences. Followed up with participants after events, who reported a 98% average satisfaction rate</li>
                        <li>Consulted with clients to ensure their requirements were met and came up with cost-effective strategies, saving clients an average of 8% in budget costs</li>
                     </ul>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12 mb-2">
                     <h5 class=" m-t-0 p-1 bg-light text-danger" style="font: size 25px; border:1px solid black; background-color: bisque;">Education</h5>
                     <h5  class="pt-2" style="font-size:13px">
                     2015-18<span class=" text-muted pl-3">BA Marketing, University of ohio</span>
                     <h5>
                     <h5 style="font-size:13px">
                     2010-14<span class=" text-muted pl-3">Bachelor of Degree, University of chicago </span>
                     <h5>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12">
                     <h5 class=" m-t-0 p-1 bg-light text-danger" style="font: size 25px; border:1px solid black; background-color: bisque;">Certificates</h5>
                     <ul class="pt-2" style="list-style-type:none" >
                        <li>
                           Digital Marketing Associate by Authority of computers and science Dept
                        </li>
                        <li>
                           Data Automation and artificial Intelligence Kellog school of management
                        </li>
                        <li>
                           PMP— Project Management Institute
                        </li>
                        <li>
                           Six Sigma Black Belt—ASQ
                        </li>
                     </ul>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12">
                     <h5 class=" m-t-0 p-1 bg-light text-danger" style="font: size 25px; border:1px solid black; background-color: bisque;">Additional Activities</h5>
                     <ul class="pt-2" style="list-style-type:none">
                        <li>
                           Member, ITNEA
                        </li>
                        <li>
                           President of local road cycling club
                        </li>
                     </ul>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12">
                     <h5 class=" m-t-0 p-1 bg-light text-danger" style="font: size 25px; border:1px solid black; background-color: bisque;">Conferences</h5>
                     <ul class="pt-2" style="list-style-type:none" >
                        <h5  class="pt-2" style="font-size:15px">
                        2017<span class=" text-muted pl-3">ICNP Spoke on a panel about cisco Networking</span>
                        <h5>
                        <h5  class="pt-2" style="font-size:15px">
                        2018<span class=" text-muted pl-3">Network and distributed system security</span>
                        <h5>
                     </ul>
                  </div>
               </div>
               <div class="settingSidebar">
                  <a href="javascript:void(0)" class="settingPanelToggle"> <i
                     class="fa fa-spin fa-cog"></i>
                  </a>
                  <div class="settingSidebar-body ps-container ps-theme-default">
                     <div class=" fade show active">
                        <div class="setting-panel-header">Theme Customizer</div>
                        <div class="p-15 border-bottom">
                           <h6 class="font-medium m-b-10">Theme Layout</h6>
                           <div class="selectgroup layout-color w-50">
                              <label> <span class="control-label p-r-20">Light</span>
                              <input type="radio" name="custom-switch-input" value="1"
                                 class="custom-switch-input" checked> <span
                                 class="custom-switch-indicator"></span>
                              </label>
                           </div>
                           <div class="selectgroup layout-color  w-50">
                              <label> <span class="control-label p-r-20">Dark&nbsp;</span>
                              <input type="radio" name="custom-switch-input" value="2"
                                 class="custom-switch-input"> <span
                                 class="custom-switch-indicator"></span>
                              </label>
                           </div>
                        </div>
                     </div>
                     <div class="p-15 border-bottom">
                        <h6 class="font-medium m-b-10">Sidebar Colors</h6>
                        <div class="sidebar-setting-options">
                           <ul class="sidebar-color list-unstyled mb-0">
                              <li title="white" class="active">
                                 <div class="white"></div>
                              </li>
                              <li title="blue">
                                 <div class="blue"></div>
                              </li>
                              <li title="coral">
                                 <div class="coral"></div>
                              </li>
                              <li title="purple">
                                 <div class="purple"></div>
                              </li>
                              <li title="allports">
                                 <div class="allports"></div>
                              </li>
                              <li title="barossa">
                                 <div class="barossa"></div>
                              </li>
                              <li title="fancy">
                                 <div class="fancy"></div>
                              </li>
                           </ul>
                        </div>
                     </div>
                     <div class="p-15 border-bottom">
                        <h6 class="font-medium m-b-10">Theme Colors</h6>
                        <div class="theme-setting-options">
                           <ul class="choose-theme list-unstyled mb-0">
                              <li title="white" class="active">
                                 <div class="white"></div>
                              </li>
                              <li title="blue">
                                 <div class="blue"></div>
                              </li>
                              <li title="coral">
                                 <div class="coral"></div>
                              </li>
                              <li title="purple">
                                 <div class="purple"></div>
                              </li>
                              <li title="allports">
                                 <div class="allports"></div>
                              </li>
                              <li title="barossa">
                                 <div class="barossa"></div>
                              </li>
                              <li title="fancy">
                                 <div class="fancy"></div>
                              </li>
                              <li title="cyan">
                                 <div class="cyan"></div>
                              </li>
                              <li title="orange">
                                 <div class="orange"></div>
                              </li>
                              <li title="green">
                                 <div class="green"></div>
                              </li>
                              <li title="red">
                                 <div class="red"></div>
                              </li>
                           </ul>
                        </div>
                     </div>
                     <div class="p-15 border-bottom">
                        <h6 class="font-medium m-b-10">Layout Options</h6>
                        <div class="theme-setting-options">
                           <label> <span class="control-label p-r-20">Compact
                           Sidebar Menu</span> <input type="checkbox"
                              name="custom-switch-checkbox" class="custom-switch-input"
                              id="mini_sidebar_setting"> <span
                              class="custom-switch-indicator"></span>
                           </label>
                        </div>
                     </div>
                     <div class="mt-3 mb-3 align-center">
                        <a href="#"
                           class="btn btn-icon icon-left btn-outline-primary btn-restore-theme">
                        <i class="fas fa-undo"></i> Restore Default
                        </a>
                     </div>
                  </div>
               </div>
            </div>
            <footer class="main-footer">
               <div class="footer-left">
                  Copyright &copy; 2022
                  <div class="bullet"></div>
                  Design By <a href="#">Snkthemes</a>
               </div>
               <div class="footer-right"></div>
            </footer>
         </div>
      </div>
      <!-- General JS Scripts -->
      <script src="assets/js/app.min.js"></script>
      <!-- JS Libraies -->
      <!-- Page Specific JS File -->
      <!-- Template JS File -->
      <script src="assets/js/scripts.js"></script>
   </body>
   <script>
      $("#formvalidate").click(function()
      {
      $(".error").hide();
      var name1=$("#fname").val();
      var sel2=$("#dropdown2").val();
      var vac1=$("#vac").val();
      var exp1=$("#exp").val();
       var tea=$("#team").val();
       var age1=$("#age").val(); 
      var text=$('#sugg').val();
      var text1=$('#sugg1').val();
      
       var sel1=$("#dropdown1").val();
       var sel3=$("#dropdown3").val();
       var from1=$("#from").val();
       var to1=$("#to").val();
       var st=$("#strt").val();
      var en=$("#end").val();
      var error=false;
      if(name1=='')
      {
      $("#fname").after('<div class="error" style="color:red">Please enter Employee Name</div>')
      error=true;
      }
      if(vac1=='')
      {
      $("#vac").after('<div class="error" style="color:red">Please provide skills</div>')
      error=true;
      }
      if(sel2=='')
      {
        $("#dropdown2").after('<div class="error" style="color:red;">Please enter  Designation</div>')
      }
      if(sel3=='')
      {
        $("#dropdown3").after('<div class="error" style="color:red;">Please enter Job Type</div>')
      }
      if(exp1=='')
      {
      $("#exp").after('<div class="error" style="color:red">Please enter experience </div>')
      error=true;
      } if(age1=='')
      {
      $("#age").after('<div class="error" style="color:red">Mention Last Working company </div>')
      error=true;
      }
       if(tea=='')
      {
      $("#team").after('<div class="error" style="color:red">Please enter Employee Id</div>')
      error=true;
      }
      if(from1=='')
      {
      $("#from").after('<div class="error" style="color:red">Please enter sal from date</div>')
      error=true;
      }
      if(to1=='')
      {
      $("#to").after('<div class="error" style="color:red">Please enter sal to date</div>')
      error=true;
      }
      
      if(text=='')
      {
          $("#sugg").after('<div class="error" style="color:red;">Please enter your suggestions</div>')
          error=true;
      }
      if(text1=='')
      {
          $("#sugg1").after('<div class="error" style="color:red;">Please verify resume</div>')
          error=true;
      }
       
      if(sel1=='')
      {
          $("#dropdown1").after('<div class="error" style="color:red;">Please enter Technical skills</div>')
          error=true;
      }
      if(st=='')
      {
        $("#strt").after('<div class="error" style="color:red;">Please enter  start date</div>')
        error=true;
      }
      if(en=='')
      {
        $("#end").after('<div class="error" style="color:red;">Please enter end date</div>')
        error=true;
      }
      if(error==true)
      {
          return false;
      }
      });
       
          
   </script>
</html>