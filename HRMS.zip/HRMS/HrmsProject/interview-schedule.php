<?php include("connection.php");?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
      <title>Grexa - Admin Dashboard Template</title>
      <!-- General CSS Files -->
      <link rel="stylesheet" href="assets/css/app.min.css">
      <!-- Template CSS -->
      <link rel="stylesheet" href="assets/css/style.css">
      <link rel="stylesheet" href="assets/css/components.css">
      <!-- Custom style CSS -->
      <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.ico' />
   </head>
   <body>
      <div class="loader"></div>
      <div id="app">
         <div class="main-wrapper main-wrapper-1">
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar">
               <div class="form-inline mr-auto">
                  <ul class="navbar-nav mr-3">
                     <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg collapse-btn"><i
                        class="fas fa-bars"></i></a></li>
                     <li>
                     </li>
                  </ul>
               </div>
            </nav>
            <div class="main-sidebar sidebar-style-2">
               <aside id="sidebar-wrapper">
                  <div class="sidebar-brand">
                     <a href="index.html">
                     <img alt="image" src="assets/img/logo.png" class="header-logo" />
                     <span class="logo-name">Grexa</span>
                     </a>
                  </div>
                  <ul class="sidebar-menu">
                  <li class="menu-header">Main</li>
                  <li class="dropdown ">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-leaf"></i><span>Employee
         </span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="Employee dashboard.php">Employee Dashboard</a></li>
         <li><a class="nav-link" href="Add Employee.php">Add Employee</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Leaves</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Apply leave.php">Apply Leave</a></li>
         <li><a class="nav-link" href="Leave list.php">Leave List</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-anchor"></i><span> Project</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="Project lists.php">Project lists</a></li>
         <li><a class="nav-link" href="Projects_page.php">Projects</a></li>
         </ul>
         </li>
         <li class="dropdown ">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Tickets</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Tickets list.php">Tickets list</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Payroll</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Employee salary.php">Employee salary</a></li>
         <li><a class="nav-link" href="payslip.php">payslip</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Clients</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link " href="Clients_page.php">Client form</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Leads</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Leads.php">Leads</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-hand-point-down"></i><span>Assets</span></a>
         <ul class="dropdown-menu">
         <li>  <a class="nav-link" href="Assests.php">Assets</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Performance</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="performance indicator.php">Performance Indicator</a></li>
         <li><a class="nav-link" href="performance Review.php">Performance Review</a></li>
         <li><a class="nav-link" href="performance Appraisal.php">Performance Appraisal  </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-crosshairs"></i><span>Goals</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="goals-list.php">Goal List</a></li>
         <li><a class="nav-link" href="goals-type.php">Goal type</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-pencil-alt"></i><span>Training</span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="training-list.php">Training List</a></li>
         <li><a class="nav-link" href="Trainers.php">Trainers</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-clipboard-check"></i><span>Jobs</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="job-dashboard.php">Jobs dashboard</a></li>
         <li><a class="nav-link" href="job-manage.php">ManageJobs</a></li>
         <li><a class="nav-link" href="job-resume.php">Manage Resumes</a></li>
         </ul>
         </li>
                  <li class="dropdown active">
                     <a href="#" class="nav-link has-dropdown active"><i class="fas fa-user-tie"></i><span>Interviews</span></a>
                     <ul class="dropdown-menu">
                        <li><a class="nav-link" href="interview-shortlist.php">Shortlist Candidates</a></li>
                        <li class="active"><a class="nav-link" href="interview-schedule.php">Schedule time</a></li>
                        <li><a class="nav-link" href="interview-offer.php">Offer  Approvals </a></li>
                     </ul>
                  </li>
                  <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-file-alt"></i><span>Special Pages</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="policies.php">Policies</a></li>
         <li><a class="nav-link" href="FAQ.php">FAQ</a></li>
         <li><a class="nav-link" href="Terms of service.php">Terms Of Services</a></li>
         </ul>
         </li>
               </aside>
            </div>
            <!-- Main Content -->
            <div class="main-content">
               <section class="section">
                  <div class="section-header">
                     <h1>Schedule Timing</h1>
                     <div class="section-header-breadcrumb">
                        <div class="breadcrumb-item"><a href="index.php">Dashboard</a></div>
                        <div class="breadcrumb-item"><a href="interview-shortlist.php"> shortlist candidates</a></div>
                        <div class="breadcrumb-item"> Schedule time  </div>
                        <div class="breadcrumb-item"><a href="interview-offer.php">Offer Approvals</a> </div>
                     </div>
                  </div>
               </section>
               <div class="row">
                  <div class="col-md-12">
                     <table class="table table-striped table-hover">
                        <thead>
                           <tr>
                              <th class="text-center">#</th>
                              <th class="text-center"> Name</th>
                              <th class="text-center">Job Title</th>
                              <th class="text-center">User Available Timings</th>
                              <th class="text-center">Schedule Timing</th>
                           </tr>
                        </thead>
                        <tbody>
                        <?php
                           $mysql="select * from scheduleinterview";
                           $query=mysqli_query($con,$mysql);
                           while($data=mysqli_fetch_assoc($query)){
                              ?>
                           <tr>
                              <td>1</td>
                              <td class="text-center pt-3">
                                 <div class="row">
                                    <div class="col-md-3"></div>
                                    <div class="col-md-1">
                                       <img alt="image" class="  rounded-circle" width="40" src="assets/img/users/user-5.png">
                                    </div>
                                    <div class="col-md-1"></div>
                                    <div class="col-md-5">
                                       <h6><?php echo $data["Name"];?></h6>
                                       <h6 class="text-muted"><?php echo $data["JobTitle"];?></h6>
                                    </div>
                                 </div>
                              </td>
                              <td class="text-center"><a href="job-dev.html"><?php echo $data["JobTitle"];?></a></td>
                              <td class="text-center"> 
                              <?php echo $data["ScheduleDate1"];?>-<?php echo $data["Scheduletime1"];?><br>
                              <?php echo $data["ScheduleDate2"];?> - <?php echo $data["Scheduletime2"];?><br>
                              <?php echo $data["ScheduleDate3"];?> - <?php echo $data["Scheduletime3"];?>
                              </td>
                               
                              
                              <td class="text-center">
                                 <!--  <button     data-toggle="modal" data-target="#basicModal"  style="background-color:blue;">Schedule Time</button>
                                    -->
                                 <!-- Button trigger modal -->
                                 <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#basicModal" style="background-color:blue;">
                                 Schedule Time
                                 </button>
                                 <?php
                           }?>
                                 <!-- Modal -->
                                 <div class="modal fade" id="basicModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                       <div class="modal-content">
                                          <div class="modal-body">
                                             <div class="card-body">
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                                </button>
                                                <h5 class="text-center">Edit</h5>
                                                <form action="interviewSchedule.php" method="post">
                                                   <div class="row" style="margin-bottom:30px;">
                                                      <div class="col-md-6">
                                                         <label class=" form-label">Name</label>
                                                         <input type="text" class="form-control" name="sname" required>
                                                      </div>
                                                      <div class="col-md-6">
                                                         <label class=" form-label">Job Title</label>
                                                         <input type="text" class="form-control" name="jobtitle" required>
                                                      </div>
                                                   </div>
                                                   <div class="row" style="margin-bottom:30px;">
                                                      <div class="col-md-6">
                                                         <label class="form-label">Schedule Date1</label>
                                                         <input class="form-control" type="date" name="date1"  >
                                                      </div>
                                                      <div class="col-md-6">
                                                         <label class="form-label">Schedule time1</label>
                                                         <input class="form-control" type="time" name="time1"  >
                                                      </div>
                                                   </div>
                                                   <div class="row" style="margin-bottom:30px;">
                                                   <div class="col-md-6">
                                                         <label class="form-label">Schedule Date2</label>
                                                         <input class="form-control" type="date" name="date2"  >
                                                      </div>
                                                      <div class="col-md-6">
                                                         <label class="form-label">Schedule time2</label>
                                                         <input class="form-control" type="time" name="time2"  >
                                                      </div>
                                                   </div>
                                                   <div class="row" style="margin-bottom:30px;">
                                                   <div class="col-md-6">
                                                         <label class="form-label">Schedule Date3</label>
                                                         <input class="form-control" type="date" name="date3"  >
                                                      </div>
                                                      <div class="col-md-6">
                                                         <label class="form-label">Schedule time3</label>
                                                         <input class="form-control" type="time" name="time3"  >
                                                      </div>
                                                   </div>
                                                   <button class="btn btn-primary" type="submit" style="margin-top:30px;">save</button>
                                                </form>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </td>
                           </tr>
                           
                        </tbody>
                     </table>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-4"></div>
                  <div class="col-md-3">
                     <nav aria-label="...">
                        <ul class="pagination">
                           <li class="page-item">
                              <a class="page-link " href="#" tabindex="-1" aria-disabled="true">Previous</a>
                           </li>
                           <li class="page-item active"><a class="page-link" href="#">1</a></li>
                           <li class="page-item " aria-current="page">
                              <a class="page-link" href="#">2</a>
                           </li>
                           <li class="page-item">
                              <a class="page-link" href="#">Next</a>
                           </li>
                        </ul>
                     </nav>
                  </div>
               </div>
            </div>
            <div class="settingSidebar">
               <a href="javascript:void(0)" class="settingPanelToggle"> <i
                  class="fa fa-spin fa-cog"></i>
               </a>
               <div class="settingSidebar-body ps-container ps-theme-default">
                  <div class=" fade show active">
                     <div class="setting-panel-header">Theme Customizer</div>
                     <div class="p-15 border-bottom">
                        <h6 class="font-medium m-b-10">Theme Layout</h6>
                        <div class="selectgroup layout-color w-50">
                           <label> <span class="control-label p-r-20">Light</span>
                           <input type="radio" name="custom-switch-input" value="1"
                              class="custom-switch-input" checked> <span
                              class="custom-switch-indicator"></span>
                           </label>
                        </div>
                        <div class="selectgroup layout-color  w-50">
                           <label> <span class="control-label p-r-20">Dark&nbsp;</span>
                           <input type="radio" name="custom-switch-input" value="2"
                              class="custom-switch-input"> <span
                              class="custom-switch-indicator"></span>
                           </label>
                        </div>
                     </div>
                  </div>
                  <div class="p-15 border-bottom">
                     <h6 class="font-medium m-b-10">Sidebar Colors</h6>
                     <div class="sidebar-setting-options">
                        <ul class="sidebar-color list-unstyled mb-0">
                           <li title="white" class="active">
                              <div class="white"></div>
                           </li>
                           <li title="blue">
                              <div class="blue"></div>
                           </li>
                           <li title="coral">
                              <div class="coral"></div>
                           </li>
                           <li title="purple">
                              <div class="purple"></div>
                           </li>
                           <li title="allports">
                              <div class="allports"></div>
                           </li>
                           <li title="barossa">
                              <div class="barossa"></div>
                           </li>
                           <li title="fancy">
                              <div class="fancy"></div>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="p-15 border-bottom">
                     <h6 class="font-medium m-b-10">Theme Colors</h6>
                     <div class="theme-setting-options">
                        <ul class="choose-theme list-unstyled mb-0">
                           <li title="white" class="active">
                              <div class="white"></div>
                           </li>
                           <li title="blue">
                              <div class="blue"></div>
                           </li>
                           <li title="coral">
                              <div class="coral"></div>
                           </li>
                           <li title="purple">
                              <div class="purple"></div>
                           </li>
                           <li title="allports">
                              <div class="allports"></div>
                           </li>
                           <li title="barossa">
                              <div class="barossa"></div>
                           </li>
                           <li title="fancy">
                              <div class="fancy"></div>
                           </li>
                           <li title="cyan">
                              <div class="cyan"></div>
                           </li>
                           <li title="orange">
                              <div class="orange"></div>
                           </li>
                           <li title="green">
                              <div class="green"></div>
                           </li>
                           <li title="red">
                              <div class="red"></div>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="p-15 border-bottom">
                     <h6 class="font-medium m-b-10">Layout Options</h6>
                     <div class="theme-setting-options">
                        <label> <span class="control-label p-r-20">Compact
                        Sidebar Menu</span> <input type="checkbox"
                           name="custom-switch-checkbox" class="custom-switch-input"
                           id="mini_sidebar_setting"> <span
                           class="custom-switch-indicator"></span>
                        </label>
                     </div>
                  </div>
                  <div class="mt-3 mb-3 align-center">
                     <a href="#"
                        class="btn btn-icon icon-left btn-outline-primary btn-restore-theme">
                     <i class="fas fa-undo"></i> Restore Default
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <footer class="main-footer">
            <div class="footer-left">
               Copyright &copy; 2022
               <div class="bullet"></div>
               Design By <a href="#">Snkthemes</a>
            </div>
            <div class="footer-right"></div>
         </footer>
      </div>
      </div>
      <!-- General JS Scripts -->
      <script src="assets/js/app.min.js"></script>
      <!-- JS Libraies -->
      <!-- Page Specific JS File -->
      <!-- Template JS File -->
      <script src="assets/js/scripts.js"></script>
   </body>
   <script>
      $(document).ready(function()
       {
           $("#formvalidate").click(function()
      {
           $(".error").hide();
           var Name=$("#name11").val();
      var lea=$("#title").val();
      var fname=$("#name").val();
      var fname1=$("#name1").val();
      var fname2=$("#name2").val();
      var sel=$("#dropdown").val();
      var sel1=$("#dropdown1").val();
      var sel2=$("#dropdown2").val();
      var error=false;
      if(Name=='')
      {
      $("#name11").after('<div class="error" style="color:red">Please enter name</div>')
      error=true;
      }
      if(lea=='')
      {
      $("#title").after('<div class="error" style="color:red">Please enter Job title</div>')
      error=true;
      }
      if(fname=='')
      {
      $("#name").after('<div class="error" style="color:red">Please enter  schedule date</div>')
      error=true;
      }
      if(fname1=='')
      {
      $("#name1").after('<div class="error" style="color:red">Please enter schedule date</div>')
      error=true;
      }if(fname2=='')
      {
      $("#name2").after('<div class="error" style="color:red">Please enter schedule date</div>')
      error=true;
      }
      if(sel=='')
      {
      $("#dropdown").after('<div class="error" style="color:red;">Please enter schedule time</div>')
      error=true;
      }
      if(sel1=='')
      {
      $("#dropdown1").after('<div class="error" style="color:red;">Please enter your  schedule time</div>')
      error=true;
      }if(sel2=='')
      {
      $("#dropdown2").after('<div class="error" style="color:red;">Please enter your  schedule time</div>')
      error=true;
      }
      if(error==true)
      {
      return false;
      }
       });
      });
   </script>
</html>