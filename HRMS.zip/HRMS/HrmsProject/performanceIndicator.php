<?php include("connection.php");?>
<?php
 $empid=$_POST['empid'];
 $desgn=$_POST['desgn'];
$dept=$_POST['dept']; 
$added=$_POST['added'];
$created=$_POST['created'];
 $status=$_POST['status'];
  

 $mysql="Insert into performanceindicator values('$empid', '$desgn','$dept','$added','$created', '$status' )";
if(mysqli_query($con,$mysql))
{
    header("Location:performance indicator.php");
    exit();
}
else{
    echo "Error";
}
mysqli_close($con);
?>