<?php include("connection.php");?>
<?php
$tid=$_POST['tid'];
$sub=$_POST['sub']; 
$staff=$_POST['staff'];
$createdate=$_POST['createdate'];
$last=$_POST['last'];
$priority=$_POST['priority'];
$status=$_POST['status'];
  $mysql="Insert into tickets values('$tid','$sub','$staff','$createdate','$last','$priority','$status')";
if(mysqli_query($con,$mysql))
{
    header("Location:Tickets list.php");
    exit();
}
else{
    echo "Error";
}
mysqli_close($con);
?>