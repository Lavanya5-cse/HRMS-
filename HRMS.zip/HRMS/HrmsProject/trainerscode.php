<?php include("connection.php");?>
<?php
 
$firname=$_POST['firname']; 
$contact=$_POST['contact'];
$email=$_POST['email'];
$des=$_POST['des']; 
 $status=$_POST['status'];
 
$mysql="Insert into trainers values( '$firname','$contact','$email','$des','$status')";
if(mysqli_query($con,$mysql))
{
    header("Location: Trainers.php");
    exit();
}
else{
    echo "Error";
}
mysqli_close($con);
?>