<?php include("connection.php");?>
<?php
$ename=$_POST['ename'];
$mailid=$_POST['mailid'];
$userid=$_POST['userid']; 
$assetname=$_POST['assetname'];
$assetid=$_POST['assetid'];
$purchasedate=$_POST['purchasedate'];
$warrent=$_POST['warrent'];
$warrentdate=$_POST['warrentdate'];
  $mysql="Insert into  assets values('$ename','$mailid','$userid','$assetname','$assetid','$purchasedate','$warrent',  '$warrentdate')";
if(mysqli_query($con,$mysql))
{
    header("Location:Assests.php");
    exit();
}
else{
    echo "Error";
}
mysqli_close($con);
?>