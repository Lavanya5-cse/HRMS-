<?php include("connection.php");?>
<?php
$cmpny=$_POST['cmpny'];
$empname=$_POST['empname'];
$dept=$_POST['dept']; 
 
  $mysql="Insert into addemp values('$cmpny','$empname','$dept')";
if(mysqli_query($con,$mysql))
{
    header("Location:Add Employee.php");
    exit();
}
else{
    echo "Error";
}
mysqli_close($con);
?>