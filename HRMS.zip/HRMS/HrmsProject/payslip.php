<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
      <title>Grexa - Admin Dashboard Template</title>
      <!-- General CSS Files -->
      <link rel="stylesheet" href="assets/css/app.min.css">
      <!-- Template CSS -->
      <link rel="stylesheet" href="assets/css/style.css">
      <link rel="stylesheet" href="assets/css/components.css">
      <!-- Custom style CSS -->
      <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.ico' />
   </head>
   <body>
      <div class="loader"></div>
      <div id="app">
      <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
      <nav class="navbar navbar-expand-lg main-navbar">
         <div class="form-inline mr-auto">
            <ul class="navbar-nav mr-3">
               <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg collapse-btn"><i
                  class="fas fa-bars"></i></a></li>
         </div>
         </li>
         </ul>
      </nav>
      <div class="main-sidebar sidebar-style-2">
         <aside id="sidebar-wrapper">
            <div class="sidebar-brand">
               <a href="index.html">
               <img alt="image" src="assets/img/logo.png" class="header-logo" />
               <span class="logo-name">Grexa</span>
               </a>
            </div>
            <ul class="sidebar-menu">
            <li class="menu-header">Main</li>
            <li class="dropdown">
               <a href="#" class="nav-link has-dropdown"><i class="fas fa-home"></i><span>Dashboard</span></a>
               <ul class="dropdown-menu">
                  <li><a class="nav-link" href="index.php">Admin Dashboard</a></li>
               </ul>
            </li>
            <li class="dropdown ">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-leaf"></i><span>Employee
         </span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="Employee dashboard.php">Employee Dashboard</a></li>
         <li><a class="nav-link" href="Add Employee.php">Add Employee</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Leaves</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Apply leave.php">Apply Leave</a></li>
         <li><a class="nav-link" href="Leave list.php">Leave List</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-anchor"></i><span> Project</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="Project lists.php">Project lists</a></li>
         <li><a class="nav-link" href="Projects_page.php">Projects</a></li>
         </ul>
         </li>
         <li class="dropdown ">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Tickets</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Tickets list.php">Tickets list</a></li>
         </ul>
         </li>
            <li class="dropdown active">
               <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Payroll</span></a>
               <ul class="dropdown-menu">
                  <li><a class="nav-link" href="Employee salary.php">Employee salary</a></li>
                  <li class="active"><a class="nav-link" href="payslip.php">payslip</a></li>
               </ul>
            </li>
            <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Clients</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="Clients_page.php">Client form</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Leads</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Leads.php">Leads</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-hand-point-down"></i><span>Assets</span></a>
         <ul class="dropdown-menu">
         <li>  <a class="nav-link" href="Assests.php">Assets</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Performance</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="performance indicator.php">Performance Indicator</a></li>
         <li><a class="nav-link" href="performance Review.php">Performance Review</a></li>
         <li><a class="nav-link" href="performance Appraisal.php">Performance Appraisal  </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-crosshairs"></i><span>Goals</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="goals-list.php">Goal List</a></li>
         <li><a class="nav-link" href="goals-type.php">Goal type</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-pencil-alt"></i><span>Training</span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="training-list.php">Training List</a></li>
         <li><a class="nav-link" href="Trainers.php">Trainers</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-clipboard-check"></i><span>Jobs</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="job-dashboard.php">Jobs dashboard</a></li>
         <li><a class="nav-link" href="job-manage.php">ManageJobs</a></li>
         <li><a class="nav-link" href="job-resume.php">Manage Resumes</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-user-tie"></i><span>Interviews</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="interview-shortlist.php">Shortlist Candidates</a></li>
         <li><a class="nav-link" href="interview-schedule.php">Schedule time</a></li>
         <li><a class="nav-link" href="interview-offer.php">Offer  Approvals </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-file-alt"></i><span>Special Pages</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="policies.php">Policies</a></li>
         <li><a class="nav-link" href="FAQ.php">FAQ</a></li>
         <li><a class="nav-link" href="Terms of service.php">Terms Of Services</a></li>
         </ul>
         </li>
         </aside>
      </div>
      <!-- Main Content -->
      <div class="main-content">
      <section class="section">
         <div class="section-header">
            <h1>Payslip</h1>
            <div class="section-header-breadcrumb">
               <div class="breadcrumb-item active"><a href="index.php">Dashboard</a></div>
               <div class="breadcrumb-item"><a href="Employee salary.php">Payroll</a></div>
               <div class="breadcrumb-item">payslip</div>
            </div>
            <!--section-header-breadcrumb-->
         </div>
         <!--section-header--->
         <div class="section-body">
         <div class="col-12 text-right ">
            <div class="btn-group mb-3 btn-group-sm " role="group" aria-label="Basic example">
               <button type="button" class="btn btn-primary">CSV</button>
               <button type="button" class="btn btn-primary">PDF</button>
               <button type="button" class="btn btn-primary">Print</button>
            </div>
            <!--btn-group-->
         </div>
         <!--col-12-->
         <div  class="row">
         <div  class="col-md-12">
            <div class="card">
               <div class="card-body">
                  <h4 class="payslip-title text-center"><u>PAYSLIP FOR THE MONTH OF FEB 2022</u> </h4>
                  <div class="row">
                     <div  class="col-sm-4 m-b-20">
                        <img class="" src="assets/img/users/payroll.jpeg" alt="..." width="100px">      
                        <ul  class="list-unstyled mb-0">
                           <li >Dreamguy's Technologies</li>
                           <li >3864 Quiet Valley Lane,</li>
                           <li >Sherman Oaks, CA, 91403</li>
                        </ul>
                     </div>
                     <div  class="col-sm-8 m-b-20">
                        <div  class="invoice-details">
                           <h3  class="text-uppercase text-right">Payslip #49029</h3>
                           <ul  class="list-unstyled">
                              <li class="text-right" >Salary Month: <span >March, 2019</span>
                              </li>
                           </ul>
                        </div>
                     </div>
                  </div>
                  <div  class="row">
                     <div class=" col-sm-4  m-b-20">
                        <ul  class="list-unstyled  mb-0">
                           <li >
                              <h5 class="mb-0 ">
                                 <strong >John Doe</strong>
                              </h5>
                           </li>
                           <li >
                              <span >Web Designer</span>
                           </li>
                           <li >Employee ID: FT-0009</li>
                           <li >Joining Date: 1 Jan 2013</li>
                        </ul>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-12 col-md-6 col-lg-6">
                        <div class="card mt-4">
                           <div class="card-header">
                              <h4 style="font-size:x-large">Earnings</h4>
                           </div>
                           <!--card-header-->
                           <div class="card-body">
                              <ul class="list-group">
                                 <li class="list-group-item">Basic Salary <span class="float-right">$6500</span></li>
                                 <li class="list-group-item">House Rent Allowance (H.R.A.) <span class="float-right">$55</span></li>
                                 <li class="list-group-item">Conveyance <span class="float-right">$55</span></li>
                                 <li class="list-group-item">Other allowance <span class="float-right">$55</span></li>
                                 <li class="list-group-item">Total earnings <span class="float-right" style="font-size:medium"><b>$55</b></span></li>
                              </ul>
                           </div>
                           <!--card-body-->
                        </div>
                        <!--card-->
                     </div>
                     <!--col-12 col-md-6 col-lg-6-->
                     <div class="col-12 col-md-6 col-lg-6">
                        <div class="card mt-4">
                           <div class="card-header">
                              <h4  style="font-size:x-large">Deductions</h4>
                           </div>
                           <!--card-header-->
                           <div class="card-body">
                              <ul class="list-group">
                                 <li class="list-group-item">Tax Deducted at Source (T.D.S.) <span class="float-right">$0</span></li>
                                 <li class="list-group-item">Provident Fund <span class="float-right">$0</span></li>
                                 <li class="list-group-item">ESI <span class="float-right">$0</span></li>
                                 <li class="list-group-item">Loan <span class="float-right">$300</span></li>
                                 <li class="list-group-item">Total Deductions <span class="float-right"style="font-size:medium"><b>$6500</b></span></li>
                              </ul>
                           </div>
                           <!--card-body-->
                        </div>
                        <!--card-->
                     </div>
                     <!--row--> 
                     <div class="col-sm-12">
                        <p style="font-size:medium"><strong >Net Salary: $6500</strong> (Six Thousand Five Hundred Rupees only.)</p>
                     </div>
                  </div>
                  <!--section-body-->
      </section>
      </div>
      <footer class="main-footer">
      <div class="footer-left">
      Copyright &copy; 2022 <div class="bullet"></div> Design By <a href="#">Snkthemes</a>
      </div>
      <div class="footer-right">
      </div>
      </footer>
      </div>
      </div>
      <!-- General JS Scripts -->
      <script src="assets/js/app.min.js"></script>
      <!-- JS Libraies -->
      <!-- Page Specific JS File -->
      <!-- Template JS File -->
      <script src="assets/js/scripts.js"></script>
   </body>
</html>