<?php include("connection.php");?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
      <title>Grexa - Admin Dashboard Template</title>
      <!-- General CSS Files -->
      <link rel="stylesheet" href="assets/css/app.min.css">
      <!-- Template CSS -->
      <link rel="stylesheet" href="assets/css/style.css">
      <link rel="stylesheet" href="assets/css/components.css">
      <!-- Custom style CSS -->
      <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.ico' />
   </head>
   <body>
      <div class="loader"></div>
      <div id="app">
         <div class="main-wrapper main-wrapper-1">
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar">
               <div class="form-inline mr-auto">
                  <ul class="navbar-nav mr-3">
                     <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg collapse-btn"><i
                        class="fas fa-bars"></i></a></li>
                     <li>
                     </li>
                  </ul>
               </div>
            </nav>
            <div class="main-sidebar sidebar-style-2">
               <aside id="sidebar-wrapper">
                  <div class="sidebar-brand">
                     <a href="index.html">
                     <img alt="image" src="assets/img/logo.png" class="header-logo" />
                     <span class="logo-name">Grexa</span>
                     </a>
                  </div>
                  <ul class="sidebar-menu">
                  <li class="menu-header">Main</li>
                  <li class="dropdown">
                     <a href="#" class="nav-link has-dropdown"><i class="fas fa-home"></i><span>Dashboard</span></a>
                     <ul class="dropdown-menu">
                        <li><a class="nav-link" href="index.php">Admin Dashboard</a></li>
                     </ul>
                  </li>
                  <li class="dropdown ">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-leaf"></i><span>Employee
         </span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="Employee dashboard.php">Employee Dashboard</a></li>
         <li><a class="nav-link" href="Add Employee.php">Add Employee</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Leaves</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Apply leave.php">Apply Leave</a></li>
         <li><a class="nav-link" href="Leave list.php">Leave List</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-anchor"></i><span> Project</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="Project lists.php">Project lists</a></li>
         <li><a class="nav-link" href="Projects_page.php">Projects</a></li>
         </ul>
         </li>
         <li class="dropdown ">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Tickets</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Tickets list.php">Tickets list</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Payroll</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Employee salary.php">Employee salary</a></li>
         <li><a class="nav-link" href="payslip.php">payslip</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Clients</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link " href="Clients_page.php">Client form</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Leads</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Leads.php">Leads</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-hand-point-down"></i><span>Assets</span></a>
         <ul class="dropdown-menu">
         <li>  <a class="nav-link" href="Assests.php">Assets</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Performance</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="performance indicator.php">Performance Indicator</a></li>
         <li><a class="nav-link" href="performance Review.php">Performance Review</a></li>
         <li><a class="nav-link" href="performance Appraisal.php">Performance Appraisal  </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-crosshairs"></i><span>Goals</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="goals-list.php">Goal List</a></li>
         <li><a class="nav-link" href="goals-type.php">Goal type</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-pencil-alt"></i><span>Training</span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="training-list.php">Training List</a></li>
         <li><a class="nav-link" href="Trainers.php">Trainers</a></li>
         </ul>
         </li>
                  <li class="dropdown active">
                     <a href="#" class="nav-link has-dropdown"><i class="fas fa-clipboard-check"></i><span>Jobs</span></a>
                     <ul class="dropdown-menu">
                        <li  ><a class="nav-link" href="job-dashboard.php">Jobs dashboard</a></li>
                        <li><a class="nav-link" href="job-manage.php">ManageJobs</a></li>
                        <li class="active"><a class="nav-link" href="job-resume.php">Manage Resumes</a></li>
                     </ul>
                  </li>
                  
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-user-tie"></i><span>Interviews</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link " href="interview-shortlist.php">Shortlist Candidates</a></li>
         <li><a class="nav-link" href="interview-schedule.php">Schedule time</a></li>
         <li><a class="nav-link" href="interview-offer.php">Offer  Approvals </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-file-alt"></i><span>Special Pages</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="policies.php">Policies</a></li>
         <li><a class="nav-link" href="FAQ.php">FAQ</a></li>
         <li><a class="nav-link" href="Terms of service.php">Terms Of Services</a></li>
         </ul>
         </li>
               </aside>
            </div>
            <!-- Main Content -->
            <div class="main-content">
               <section class="section">
                  <div class="section-header">
                     <h1>Manage Resumes</h1>
                     <div class="section-header-breadcrumb">
                        <div class="breadcrumb-item"><a href="index.php">Dashboard</a></div>
                        <div class="breadcrumb-item"><a href="job-dashboard.php"> Jobsdashboard</a></div>
                        <div class="breadcrumb-item"> <a href="job-manage.php">ManageJobs</a></div>
                        <div class="breadcrumb-item">  ManageResumes</div>
                     </div>
                  </div>
               </section>
               <div class="card">
                  <div class="card-body">
                     <div class="row">
                        <div class="col-md-8">
                           <button type="button" class="btn btn-info" data-toggle="modal" data-target="#basicModal">
                           + Manage Resumes
                           </button>
                        </div>
                        <div class="modal fade" id="basicModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                           <div class="modal-dialog" role="document">
                              <div class="modal-content">
                                 <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Manage Resumes</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                 </div>
                                 <div class="modal-body">
                                    <div class="card-body">
                                       <form action="jobResume.php" method="post">
                                          <div class="row">
                                             <div class="col-md-8" style="margin-bottom:30px;">
                                                <label class="form-label">Name</label>
                                                <input class="form-control" type="text"  name="rname">
                                             </div>
                                          </div>
                                          <div class="row" style="margin-bottom:30px;">
                                             <div class="col-md-6">
                                                <label class="form-label">Job Title</label>
                                                <input class="form-control" type="text" name="jobtitle" >
                                             </div>
                                             <div class="col-md-6">
                                                <div> <label class=" form-label">Departments</label></div>
                                                <select class="form-select form-select-lg" style="width:200px;height:40px;" name="dept">
                                                   <option></option>
                                                   <option value="Web development">Web development</option>
                                                   <option value="Application Development">Application Development</option>
                                                   <option value="IT Management">IT Management</option>
                                                   <option value="Accounts Management">Accounts Management</option>
                                                   <option value="Support Management">Support Management</option>
                                                   <option value="Marketing">Marketing</option>
                                                </select>
                                             </div>
                                          </div>
                                          <div class="row" style="margin-bottom:30px;">
                                             <div class="col-md-6">
                                                <label class=" form-label"> Start date</label>
                                                <input type="date" class="form-control" name="strt">
                                             </div>
                                             <div class="col-md-6">
                                                <label class=" form-label"> Expiry date</label>
                                                <input type="date" class="form-control" name="expiry">
                                             </div>
                                          </div>
                                          <div class="row" style="margin-bottom:30px;">
                                             <div class="col-md-6">
                                                <div> <label class=" form-label"> Job Types</label></div>
                                                <select class="form-select form-select-lg" style="width:200px;height:40px;" name="type">
                                                   <option></option>
                                                   <option value="Full Time">Full Time</option>
                                                   <option value="Part Time">Part Time</option>
                                                   <option value="Temporary">Temporary</option>
                                                   <option value="Remote">Remote</option>
                                                   <option value="Internship">Internship</option>
                                                   <option value="Others">Others</option>
                                                </select>
                                             </div>
                                             <div class="col-md-6">
                                                <div> <label class=" form-label"> status</label></div>
                                                <select class="form-select form-select-lg" style="width:200px;height:40px;" name="status">
                                                   <option></option>
                                                   <option value="Open">Open</option>
                                                   <option value="Closed">Closed</option>
                                                   <option value="Cancelled">Cancelled</option>
                                                </select>
                                             </div>
                                          </div>
                                          <div class="row" style="margin-bottom:30px;">
                                              
                                            <!--  <div class="col-md-6">
                                                <label class="form-label">Resume</label>
                                                <input type="file" id="myFile">
                                             </div>-->
                                          </div>
                                          <div class="row">
                                             <div class="col-md-4"></div>
                                             <div class="col-md-6">
                                                <button class="btn btn-primary rounded-pill pr-3 pt-2 pl-3 text-center">Submit</button>
                                             </div>
                                          </div>
                                       </form>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="row" style="margin-bottom:30px;">
                  <div class="col-md-12 ">
                  <div class="table-responsive-md">
                     <table class="table table-striped table-hover">
                        <thead>
                           <tr>
                              <th class="text-center">#</th>
                              <th class="text-center"> Name</th>
                              <th class="text-center">Job Title</th>
                              <th class="text-center">Departments</th>
                              <th class="text-center">Start Date</th>
                              <th class="text-center">Expire Date</th>
                              <th class="text-center">Job Types</th>
                              <th class="text-center">Status</th>
                              <th class="text-center">Resume</th>
                           </tr>
                        </thead>
                        <tbody>
                        <?php
                           $mysql="select * from manageresumes";
                           $query=mysqli_query($con,$mysql);
                           while($data=mysqli_fetch_assoc($query)){
                              ?>
                           <tr>
                              <td class="text-center">1</td>
                              <td>
                                 <div class="row pt-3">
                                    <div class="col-md-1"></div>
                                    <div class="col-md-1">
                                       <img alt="image" class="  rounded-circle" width="40" src="assets/img/users/user-5.png">
                                    </div>
                                    <div class="col-md-1"></div>
                                    <div class="col-md-5">
                                       <h6><?php echo $data["Name"];?></h6>
                                    </div>
                                 </div>
                              </td>
                              <td class="text-center"><a href="jobresume1.php"><?php echo $data["JobTitle"];?></a></td>
                              <td class="text-center"><?php echo $data["Departments"];?></td>
                              <td class="text-center"><?php echo $data["Startdate"];?></td>
                              <td class="text-center"><?php echo $data["Expirydate"];?></td>
                              <td class="text-center"><?php echo $data["JobTypes"];?>
                                 <select class="form-select form-select-lg rounded-pill text-center  ">
                                    <option value="Full time"> Full time  </option>
                                    <option value="Part time">Part time</option>
                                    <option value="Internship">Internship   </option>
                                    <option value="Temporary">Temporary   </option>
                                    <option value="Other "> Other   </option>
                                 </select>
                              </td>
                              <td class="text-center"><?php echo $data["status"];?>
                                 <select class="form-select form-select-lg rounded-pill text-center  ">
                                    <option value=" Opened"> Opened  </option>
                                    <option value="Closed"> Closed</option>
                                    <option value="Cancelled">Cancelled  </option>
                                 </select>
                              </td>
                              <td class="text-center">
                                 <a  href="javascript:void(0);" class="btn btn-sm btn-primary" style="background-color:blue;">
                                 <i  class="fas fa-download me-1"></i> Download</a>
                              </td>
                           </tr>
                           <?php
                           }?>
                        </tbody>
                     </table>
                  </div></div>
               </div>
            </div>
            <div class="settingSidebar">
               <a href="javascript:void(0)" class="settingPanelToggle"> <i
                  class="fa fa-spin fa-cog"></i>
               </a>
               <div class="settingSidebar-body ps-container ps-theme-default">
                  <div class=" fade show active">
                     <div class="setting-panel-header">Theme Customizer</div>
                     <div class="p-15 border-bottom">
                        <h6 class="font-medium m-b-10">Theme Layout</h6>
                        <div class="selectgroup layout-color w-50">
                           <label> <span class="control-label p-r-20">Light</span>
                           <input type="radio" name="custom-switch-input" value="1"
                              class="custom-switch-input" checked> <span
                              class="custom-switch-indicator"></span>
                           </label>
                        </div>
                        <div class="selectgroup layout-color  w-50">
                           <label> <span class="control-label p-r-20">Dark&nbsp;</span>
                           <input type="radio" name="custom-switch-input" value="2"
                              class="custom-switch-input"> <span
                              class="custom-switch-indicator"></span>
                           </label>
                        </div>
                     </div>
                  </div>
                  <div class="p-15 border-bottom">
                     <h6 class="font-medium m-b-10">Sidebar Colors</h6>
                     <div class="sidebar-setting-options">
                        <ul class="sidebar-color list-unstyled mb-0">
                           <li title="white" class="active">
                              <div class="white"></div>
                           </li>
                           <li title="blue">
                              <div class="blue"></div>
                           </li>
                           <li title="coral">
                              <div class="coral"></div>
                           </li>
                           <li title="purple">
                              <div class="purple"></div>
                           </li>
                           <li title="allports">
                              <div class="allports"></div>
                           </li>
                           <li title="barossa">
                              <div class="barossa"></div>
                           </li>
                           <li title="fancy">
                              <div class="fancy"></div>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="p-15 border-bottom">
                     <h6 class="font-medium m-b-10">Theme Colors</h6>
                     <div class="theme-setting-options">
                        <ul class="choose-theme list-unstyled mb-0">
                           <li title="white" class="active">
                              <div class="white"></div>
                           </li>
                           <li title="blue">
                              <div class="blue"></div>
                           </li>
                           <li title="coral">
                              <div class="coral"></div>
                           </li>
                           <li title="purple">
                              <div class="purple"></div>
                           </li>
                           <li title="allports">
                              <div class="allports"></div>
                           </li>
                           <li title="barossa">
                              <div class="barossa"></div>
                           </li>
                           <li title="fancy">
                              <div class="fancy"></div>
                           </li>
                           <li title="cyan">
                              <div class="cyan"></div>
                           </li>
                           <li title="orange">
                              <div class="orange"></div>
                           </li>
                           <li title="green">
                              <div class="green"></div>
                           </li>
                           <li title="red">
                              <div class="red"></div>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="p-15 border-bottom">
                     <h6 class="font-medium m-b-10">Layout Options</h6>
                     <div class="theme-setting-options">
                        <label> <span class="control-label p-r-20">Compact
                        Sidebar Menu</span> <input type="checkbox"
                           name="custom-switch-checkbox" class="custom-switch-input"
                           id="mini_sidebar_setting"> <span
                           class="custom-switch-indicator"></span>
                        </label>
                     </div>
                  </div>
                  <div class="mt-3 mb-3 align-center">
                     <a href="#"
                        class="btn btn-icon icon-left btn-outline-primary btn-restore-theme">
                     <i class="fas fa-undo"></i> Restore Default
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <footer class="main-footer">
            <div class="footer-left">
               Copyright &copy; 2022
               <div class="bullet"></div>
               Design By <a href="#">Snkthemes</a>
            </div>
            <div class="footer-right"></div>
         </footer>
      </div>
      </div>
      <!-- General JS Scripts -->
      <script src="assets/js/app.min.js"></script>
      <!-- JS Libraies -->
      <!-- Page Specific JS File -->
      <!-- Template JS File -->
      <script src="assets/js/scripts.js"></script>
   </body>
   <script>
      $("#formvalidate").click(function()
      {
      $(".error").hide();
      var name2=$("#name").val();
      var name1=$("#fname").val();
      var sel2=$("#dropdown2").val();
       var sel1=$("#dropdown1").val();
       var sel3=$("#dropdown3").val();
       var st=$("#strt").val();
      var en=$("#end").val();
      var app=$('#applicant').val();
      var file=$('#myFile').val();
      var error=false;
      if(name2=='')
      {
      $("#name").after('<div class="error" style="color:red">Please enter name</div>')
      error=true;
      }
      if(name1=='')
      {
      $("#fname").after('<div class="error" style="color:red">Please enter Job title</div>')
      error=true;
      }
      if(app=='')
      {
      $("#applicant").after('<div class="error" style="color:red">Please enter no of applicants</div>')
      error=true;
      }
      if(sel2=='')
      {
        $("#dropdown2").after('<div class="error" style="color:red;">Please enter your department</div>')
        error=true;
      }
      if(sel3=='')
      {
        $("#dropdown3").after('<div class="error" style="color:red;">Please enter Job Type</div>')
        error=true;
      }
      if(sel1=='')
      {
          $("#dropdown1").after('<div class="error" style="color:red;">Please enter status</div>')
          error=true;
      }
      if(st=='')
      {
        $("#strt").after('<div class="error" style="color:red;">Please enter  start date</div>')
        error=true;
      }
      if(en=='')
      {
        $("#end").after('<div class="error" style="color:red;">Please enter end date</div>')
        error=true;
      }
      if(file=='')
      {
        $("#myFile").after('<div class="error" style="color:red;">Please upload resume</div>')
        error=true;
      }
      if(error==true)
      {
          return false;
      }
      });
       
          
   </script>
</html>