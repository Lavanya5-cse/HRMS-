<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
      <title>Grexa - Admin Dashboard Template</title>
      <!-- General CSS Files -->
      <link rel="stylesheet" href="assets/css/app.min.css">
      <link rel="stylesheet" href="assets/bundles/jquery-selectric/selectric.css">
      <!-- Template CSS -->
      <link rel="stylesheet" href="assets/css/style.css">
      <link rel="stylesheet" href="assets/css/components.css">
      <!-- Custom style CSS -->
      <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.ico' />
   </head>
   <body>
      <div class="loader"></div>
      <div id="app">
         <div class="main-wrapper main-wrapper-1">
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar">
               <div class="form-inline mr-auto">
                  <ul class="navbar-nav mr-3">
                     <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg collapse-btn"><i
                        class="fas fa-bars"></i></a></li>
                  </ul>
               </div>
            </nav>
            <div class="main-sidebar sidebar-style-2">
               <aside id="sidebar-wrapper">
                  <div class="sidebar-brand">
                     <a href="index.html">
                     <img alt="image" src="assets/img/logo.png" class="header-logo" />
                     <span class="logo-name">Grexa</span>
                     </a>
                  </div>
                  <ul class="sidebar-menu">
                     <li class="menu-header">Main</li>
                     <li class="dropdown">
                        <a href="#" class="nav-link has-dropdown"><i class="fas fa-home"></i><span>Dashboard</span></a>
                        <ul class="dropdown-menu">
                           <li><a class="nav-link" href="index.php">Admin Dashboard</a></li>
                        </ul>
                     </li>
                     <li class="dropdown ">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-leaf"></i><span>Employee
         </span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="Employee dashboard.php">Employee Dashboard</a></li>
         <li><a class="nav-link" href="Add Employee.php">Add Employee</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Leaves</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Apply leave.php">Apply Leave</a></li>
         <li><a class="nav-link" href="Leave list.php">Leave List</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-anchor"></i><span> Project</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="Project lists.php">Project lists</a></li>
         <li><a class="nav-link" href="Projects_page.php">Projects</a></li>
         </ul>
         </li>
         <li class="dropdown ">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Tickets</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Tickets list.php">Tickets list</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Payroll</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Employee salary.php">Employee salary</a></li>
         <li><a class="nav-link" href="payslip.php">payslip</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Clients</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link " href="Clients_page.php">Client form</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Leads</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Leads.php">Leads</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-hand-point-down"></i><span>Assets</span></a>
         <ul class="dropdown-menu">
         <li>  <a class="nav-link" href="Assests.php">Assets</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Performance</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="performance indicator.php">Performance Indicator</a></li>
         <li><a class="nav-link" href="performance Review.php">Performance Review</a></li>
         <li><a class="nav-link" href="performance Appraisal.php">Performance Appraisal  </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-crosshairs"></i><span>Goals</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="goals-list.php">Goal List</a></li>
         <li><a class="nav-link" href="goals-type.php">Goal type</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-pencil-alt"></i><span>Training</span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="training-list.php">Training List</a></li>
         <li><a class="nav-link" href="Trainers.php">Trainers</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-clipboard-check"></i><span>Jobs</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="job-dashboard.php">Jobs dashboard</a></li>
         <li><a class="nav-link" href="job-manage.php">ManageJobs</a></li>
         <li><a class="nav-link" href="job-resume.php">Manage Resumes</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-user-tie"></i><span>Interviews</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link " href="interview-shortlist.php">Shortlist Candidates</a></li>
         <li><a class="nav-link" href="interview-schedule.php">Schedule time</a></li>
         <li><a class="nav-link" href="interview-offer.php">Offer  Approvals </a></li>
         </ul>
         </li>
                     <li class="dropdown active">
                        <a href="#" class="nav-link has-dropdown"><i class="far fa-file-alt"></i><span>Special Pages</span></a>
                        <ul class="dropdown-menu">
                           <li><a class="nav-link" href="policies.php">Policies</a></li>
                           <li><a class="nav-link" href="FAQ.php">FAQ</a></li>
                           <li class="active"><a class="nav-link" href="Terms of service.php">Terms Of Services</a></li>
                           <!---- <li><a class="nav-link" href="profile.html">Profile</a></li>-->
                        </ul>
                     </li>
                  </ul>
               </aside>
            </div>
            <!-- Main Content -->
            <div class="main-content">
               <section class="section">
                  <div class="section-header">
                     <h1>Terms Of Services</h1>
                     <div class="section-header-button">
                        <a href="create-post.html" class="btn btn-primary">FAQ</a>
                     </div>
                     <div class="section-header-breadcrumb">
                        <div class="breadcrumb-item active"><a href="index.php">Dashboard</a></div>
                        <div class="breadcrumb-item"><a href="policies.php">Policies</a></div>
                        <div class="breadcrumb-item"><a href="FAQ.php">FAQ</a></div>
                        <div class="breadcrumb-item">Terms of service </div>
                     </div>
                  </div>
               </section>
               <div class="container-fluid ">
                  <div class="row">
                     <div class="col-md-12">
                        <div class="lead text-center bg-success text-light mb-3">
                           <h1>Company Terms</h1>
                        </div>
                        <div class="card">
                           <div class="card-body">
                              <h3 class="lead  text-info mt-3" >Acceptance of Agreement</h3>
                              <p class="text-justify ">You agree to the terms and conditions outlined in this Terms of Use Agreement ("Agreement") with respect to our site (the "Site"). This Agreement constitutes the entire and only agreement between us and you, and supersedes all prior agreements, representations, warranties and understandings with respect to the Site, the content, products or services provided by or through the Site, and the subject matter of this Agreement.</p>
                              <h3 class="lead  text-info mt-3">Privacy Policy</h3>
                              <p class="text-justify ">Our Privacy Policy, as it may change from time to time, is a part of this Agreement. By using the Site you agree to our use, collection and disclosure of personally identifiable information in accordance with the Privacy Policy.</p>
                              <h3 class="lead  text-info mt-3">Registration</h3>
                              <p class="text-justify ">If you register for an account on the Site, you agree to:</p>
                              <ul>
                                 <li>provide accurate, current and complete information as may be prompted by any registration forms on the Site ("Registration Data")</li>
                                 <li>maintain the security of your password</li>
                                 <li>maintain and promptly update the Registration Data, and any other information you provide to greytHR and to keep it accurate, current and complete</li>
                                 <li>accept all risks of unauthorized access to the Registration Data and any other information you provide to us. You are responsible for all activity on your greytHR account, and for all charges incurred by your greytHR account</li>
                              </ul>
                              <h3 class="lead  text-info mt-3">Nontransferable</h3>
                              <p class="text-justify ">Your right to use the Site is not transferable or assignable. Any password or right given to you to obtain information or documents is not transferable or assignable.</p>
                              <h3 class="lead  text-info mt-3">Disclaimer</h3>
                              <p class="text-uppercase text-danger">THE INFORMATION, CONTENT AND DOCUMENTS FROM OR THROUGH THE SITE ARE PROVIDED "AS-IS," "AS AVAILABLE," WITH "ALL FAULTS", AND ALL WARRANTIES, EXPRESS OR IMPLIED, ARE DISCLAIMED (INCLUDING BUT NOT LIMITED TO THE DISCLAIMER OF ANY IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE). </p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="settingSidebar">
                  <a href="javascript:void(0)" class="settingPanelToggle"> <i
                     class="fa fa-spin fa-cog"></i>
                  </a>
                  <div class="settingSidebar-body ps-container ps-theme-default">
                     <div class=" fade show active">
                        <div class="setting-panel-header">Theme Customizer</div>
                        <div class="p-15 border-bottom">
                           <h6 class="font-medium m-b-10">Theme Layout</h6>
                           <div class="selectgroup layout-color w-50">
                              <label> <span class="control-label p-r-20">Light</span>
                              <input type="radio" name="custom-switch-input" value="1"
                                 class="custom-switch-input" checked> <span
                                 class="custom-switch-indicator"></span>
                              </label>
                           </div>
                           <div class="selectgroup layout-color  w-50">
                              <label> <span class="control-label p-r-20">Dark&nbsp;</span>
                              <input type="radio" name="custom-switch-input" value="2"
                                 class="custom-switch-input"> <span
                                 class="custom-switch-indicator"></span>
                              </label>
                           </div>
                        </div>
                     </div>
                     <div class="p-15 border-bottom">
                        <h6 class="font-medium m-b-10">Sidebar Colors</h6>
                        <div class="sidebar-setting-options">
                           <ul class="sidebar-color list-unstyled mb-0">
                              <li title="white" class="active">
                                 <div class="white"></div>
                              </li>
                              <li title="blue">
                                 <div class="blue"></div>
                              </li>
                              <li title="coral">
                                 <div class="coral"></div>
                              </li>
                              <li title="purple">
                                 <div class="purple"></div>
                              </li>
                              <li title="allports">
                                 <div class="allports"></div>
                              </li>
                              <li title="barossa">
                                 <div class="barossa"></div>
                              </li>
                              <li title="fancy">
                                 <div class="fancy"></div>
                              </li>
                           </ul>
                        </div>
                     </div>
                     <div class="p-15 border-bottom">
                        <h6 class="font-medium m-b-10">Theme Colors</h6>
                        <div class="theme-setting-options">
                           <ul class="choose-theme list-unstyled mb-0">
                              <li title="white" class="active">
                                 <div class="white"></div>
                              </li>
                              <li title="blue">
                                 <div class="blue"></div>
                              </li>
                              <li title="coral">
                                 <div class="coral"></div>
                              </li>
                              <li title="purple">
                                 <div class="purple"></div>
                              </li>
                              <li title="allports">
                                 <div class="allports"></div>
                              </li>
                              <li title="barossa">
                                 <div class="barossa"></div>
                              </li>
                              <li title="fancy">
                                 <div class="fancy"></div>
                              </li>
                              <li title="cyan">
                                 <div class="cyan"></div>
                              </li>
                              <li title="orange">
                                 <div class="orange"></div>
                              </li>
                              <li title="green">
                                 <div class="green"></div>
                              </li>
                              <li title="red">
                                 <div class="red"></div>
                              </li>
                           </ul>
                        </div>
                     </div>
                     <div class="p-15 border-bottom">
                        <h6 class="font-medium m-b-10">Layout Options</h6>
                        <div class="theme-setting-options">
                           <label> <span class="control-label p-r-20">Compact
                           Sidebar Menu</span> <input type="checkbox"
                              name="custom-switch-checkbox" class="custom-switch-input"
                              id="mini_sidebar_setting"> <span
                              class="custom-switch-indicator"></span>
                           </label>
                        </div>
                     </div>
                     <div class="mt-3 mb-3 align-center">
                        <a href="#"
                           class="btn btn-icon icon-left btn-outline-primary btn-restore-theme">
                        <i class="fas fa-undo"></i> Restore Default
                        </a>
                     </div>
                  </div>
               </div>
            </div>
            <footer class="main-footer">
               <div class="footer-left">
                  Copyright &copy; 2022 
                  <div class="bullet"></div>
                  Design By <a href="#">Snkthemes</a>
               </div>
               <div class="footer-right">
               </div>
            </footer>
         </div>
      </div>
      <!-- General JS Scripts -->
      <script src="assets/js/app.min.js"></script>
      <!-- JS Libraies -->
      <script src="assets/bundles/jquery-selectric/jquery.selectric.min.js"></script>
      <!-- Page Specific JS File -->
      <script src="assets/js/page/posts.js"></script>
      <!-- Template JS File -->
      <script src="assets/js/scripts.js"></script>
   </body>
</html>