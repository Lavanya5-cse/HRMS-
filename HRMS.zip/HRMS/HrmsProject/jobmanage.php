<?php include("connection.php");?>
<?php
 
$jobtitle=$_POST['jobtitle']; 
$dept=$_POST['dept'];
$strt=$_POST['strt'];
$expiry=$_POST['expiry']; 
$type=$_POST['type'];
 $status=$_POST['status'];
 $applicant=$_POST['applicant'];
$mysql="Insert into managejobs values( '$jobtitle','$dept','$strt','$expiry','$type','$status','$applicant')";
if(mysqli_query($con,$mysql))
{
    header("Location:job-manage.php");
    exit();
}
else{
    echo "Error";
}
mysqli_close($con);
?>