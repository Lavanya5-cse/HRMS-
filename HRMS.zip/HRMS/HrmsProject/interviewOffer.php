<?php include("connection.php");?>
<?php
 $oname=$_POST['oname'];
$jobtitle=$_POST['jobtitle']; 
$type=$_POST['type'];
 $pay=$_POST['pay'];
 $IP=$_POST['IP'];
 $status=$_POST['status'];
  

 $mysql="Insert into offerletters values('$oname', '$jobtitle','$type','$pay','$IP','$status' )";
if(mysqli_query($con,$mysql))
{
    header("Location:interview-offer.php");
    exit();
}
else{
    echo "Error";
}
mysqli_close($con);
?>