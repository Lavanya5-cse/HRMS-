<?php include("connection.php");?>
<?php
$lname=$_POST['lname'];
$email=$_POST['email']; 
$phone=$_POST['phone'];
$project=$_POST['project'];
$staff=$_POST['staff'];
$status=$_POST['status'];
$created=$_POST['created'];
  $mysql="Insert into  leads values('$lname','$email','$phone','$project','$staff','$status','$created')";
if(mysqli_query($con,$mysql))
{
    header("Location:Leads.php");
    exit();
}
else{
    echo "Error";
}
mysqli_close($con);
?>