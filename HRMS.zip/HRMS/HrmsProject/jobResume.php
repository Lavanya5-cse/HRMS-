<?php include("connection.php");?>
<?php
 $rname=$_POST['rname'];
$jobtitle=$_POST['jobtitle']; 
$dept=$_POST['dept'];
$strt=$_POST['strt'];
$expiry=$_POST['expiry']; 
$type=$_POST['type'];
 $status=$_POST['status'];
 $mysql="Insert into manageresumes values('$rname', '$jobtitle','$dept','$strt','$expiry','$type','$status' )";
if(mysqli_query($con,$mysql))
{
    header("Location:job-resume.php");
    exit();
}
else{
    echo "Error";
}
mysqli_close($con);
?>