<?php include("connection.php");?>
<!DOCTYPE html>
<html lang="en">
   <!-- Mirrored from radixtouch.in/templates/snkthemes/grexa/source/light/basic-form.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 06 Feb 2021 10:38:02 GMT -->
   <head>
      <meta charset="UTF-8">
      <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
      <title>Grexa - Admin Dashboard Template</title>
      <!-- General CSS Files -->
      <link rel="stylesheet" href="assets/css/app.min.css">
      <!-- Template CSS -->
      <link rel="stylesheet" href="assets/css/style.css">
      <link rel="stylesheet" href="assets/css/components.css">
      <!-- Custom style CSS -->
      <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.ico' />
   </head>
   <body>
      <div class="loader"></div>
      <div id="app">
         <div class="main-wrapper main-wrapper-1">
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar">
               <div class="form-inline mr-auto">
                  <ul class="navbar-nav mr-3">
                     <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg collapse-btn"><i
                        class="fas fa-bars"></i></a></li>
                     <li>
                     </li>
                  </ul>
               </div>
            </nav>
            <div class="main-sidebar sidebar-style-2">
               <aside id="sidebar-wrapper">
                  <div class="sidebar-brand">
                     <a href="index.html">
                     <img alt="image" src="assets/img/logo.png" class="header-logo" />
                     <span class="logo-name">Grexa</span>
                     </a>
                  </div>
                  <ul class="sidebar-menu">
                  <li class="menu-header">Main</li>
                  <li class="dropdown">
                     <a href="#" class="nav-link has-dropdown"><i class="fas fa-home"></i><span>Dashboard</span></a>
                     <ul class="dropdown-menu">
                        <li><a class="nav-link" href="index.php">Admin Dashboard</a></li>
                     </ul>
                  </li>
                  <li class="dropdown ">
                     <a href="#" class="nav-link has-dropdown"><i class="fas fa-leaf"></i><span>Employee
                     </span></a>
                     <ul class="dropdown-menu">
                        <li class=""><a class="nav-link" href="Employee dashboard.php">Employee Dashboard</a></li>
                        <li><a class="nav-link" href="Add Employee.php">Add Employee</a></li>
                       
                     </ul>
                  </li>
                  <li class="dropdown">
                     <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Leaves</span></a>
                     <ul class="dropdown-menu">
                        <li><a class="nav-link" href="Apply leave.php">Apply Leave</a></li>
                        <li><a class="nav-link" href="Leave list.php">Leave List</a></li>
                     </ul>
                  </li>
                  <li class="dropdown">
                     <a href="#" class="nav-link has-dropdown"><i class="fas fa-anchor"></i><span> Project</span></a>
                     <ul class="dropdown-menu">
                        <li><a class="nav-link active" href="Project lists.php">Project lists</a></li>
                        <li><a class="nav-link" href="Projects_page.php">Projects</a></li>
                     </ul>
                  </li>
                  <li class="dropdown active">
                     <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Tickets</span></a>
                     <ul class="dropdown-menu">
                        <li class="active"><a class="nav-link" href="Tickets list.php">Tickets list</a></li>
                     </ul>
                  </li>
                  <li class="dropdown">
                     <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Payroll</span></a>
                     <ul class="dropdown-menu">
                        <li><a class="nav-link" href="Employee salary.php">Employee salary</a></li>
                        <li><a class="nav-link" href="payslip.php">payslip</a></li>
                     </ul>
                  </li>
                  <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Clients</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="Clients_page.php">Client form</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Leads</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Leads.php">Leads</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-hand-point-down"></i><span>Assets</span></a>
         <ul class="dropdown-menu">
         <li>  <a class="nav-link" href="Assests.php">Assets</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Performance</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="performance indicator.php">Performance Indicator</a></li>
         <li><a class="nav-link" href="performance Review.php">Performance Review</a></li>
         <li><a class="nav-link" href="performance Appraisal.php">Performance Appraisal  </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-crosshairs"></i><span>Goals</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="goals-list.php">Goal List</a></li>
         <li><a class="nav-link" href="goals-type.php">Goal type</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-pencil-alt"></i><span>Training</span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="training-list.php">Training List</a></li>
         <li><a class="nav-link" href="Trainers.php">Trainers</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-clipboard-check"></i><span>Jobs</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="job-dashboard.php">Jobs dashboard</a></li>
         <li><a class="nav-link" href="job-manage.php">ManageJobs</a></li>
         <li><a class="nav-link" href="job-resume.php">Manage Resumes</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-user-tie"></i><span>Interviews</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="interview-shortlist.php">Shortlist Candidates</a></li>
         <li><a class="nav-link" href="interview-schedule.php">Schedule time</a></li>
         <li><a class="nav-link" href="interview-offer.php">Offer  Approvals </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-file-alt"></i><span>Special Pages</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="policies.php">Policies</a></li>
         <li><a class="nav-link" href="FAQ.php">FAQ</a></li>
         <li><a class="nav-link" href="Terms of service.php">Terms Of Services</a></li>
         </ul>
         </li>
               </aside>
            </div>
            <!-- Main Content -->
            <div class="main-content">
               <div class="card">
                  <div class="card-body">
                     <button type="button" class="btn btn-info " data-toggle="modal"
                        data-target="#basicModal">
                     + Add Ticket
                     </button>
                  </div>
               </div>
               <div class="modal fade" id="basicModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                  aria-hidden="true">
                  <div class="modal-dialog" role="document">
                     <div class="modal-content">
                        <div class="modal-header">
                           <h5 class="modal-title" id="exampleModalLabel">Ticket Form</h5>
                           <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                           </button>
                        </div>
                        <div class="modal-body">
                           <form action="ticketsList.php" method="post">
                              <div class="row" style="margin-bottom:30px;">
                                 <div class="col-md-6">
                                    <label class=" form-label">Ticket id</label>
                                    <input type="text" class="form-control"   name="tid" required>
                                 </div>
                                 <div class="col-md-6">
                                    <label class=" form-label">Ticket Subject</label>
                                    <input type="text" class="form-control"   name="sub" required>
                                 </div>
                              </div>
                              <div class="row" style="margin-bottom:30px;">
                                 <div class="col-md-6">
                                    <label class=" form-label"> Assigned Staff</label>
                                    <input type="text" class="form-control" name="staff">
                                 </div>
                                 <div class="col-md-6">
                                    <label class=" form-label"> Created date</label>
                                    <input type="date" class="form-control" name="createdate"  >
                                 </div>
                              </div>
                              <div class="row" style="margin-bottom:30px;">
                                 <div class="col-md-6">
                                    <label class=" form-label"> Last Reply </label>
                                    <input type="date" class="form-control" name="last"  >
                                 </div>
                                 <div class="col-md-6">
                                    <div> <label class=" form-label"> Priority</label></div>
                                    <select class="form-select form-select-lg" style="width:200px;height:40px;" name="priority"  >
                                       <option></option>
                                       <option value="high">High</option>
                                       <option value="medium">Medium</option>
                                       <option value="low">Low</option>
                                    </select>
                                 </div>
                              </div>
                              <div class="row" style="margin-bottom:30px;">
                                 <div class="col-md-6">
                                    <div> <label class=" form-label"> Status</label></div>
                                    <select class="form-select form-select-lg" style="width:200px;height:40px;"   name="status">
                                       <option></option>
                                       <option value="Open">Open</option>
                                       <option value="Reopened">Reopened</option>
                                       <option value="OnHold">OnHold</option>
                                       <option value="Closed">Closed</option>
                                       <option value="Reopened">Reopened</option>
                                       <option value="InProgress">InProgress</option>
                                       <option value="Cancelled">Cancelled</option>
                                    </select>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-md-4"></div>
                                 <div class="col-md-6">
                                    <button class="btn btn-primary rounded-pill pr-3 pt-2 pl-3 text-center" >Submit</button>
                                 </div>
                              </div>
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-3 col-sm-6 col-12 flex" style="margin-bottom:30px;">
                     <div class="card flex-fill h-30 bg-light" width="1.8rem">
                        <div class="card-header border-0">
                           <h4>New Tickets</h4>
                           <a href="" style="color:green;text-decoration: none; margin-left:20px; font-size:18px"> +10%</a>
                        </div>
                        <div class="card-body card-type-4">
                           <h3 class="card-title">112</h3>
                           <h6 class="card-title">
                           Progress:
                           <div class="progress">
                              <div class="progress-bar progress-bar-striped bg-info" role="progressbar" style="width: 30%" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-3 col-sm-6 col-12 flex" style="margin-bottom:30px;">
                     <div class="card flex-fill bg-light" width="1.8rem">
                        <div class="card-header border-0">
                           <h4>Solved Tickets</h4>
                           <a href="" style="color:green;text-decoration: none;  font-size:18px"> +95%</a>
                        </div>
                        <div class="card-body card-type-4">
                           <h3 class="card-title">70</h3>
                           <h6 class="card-title">
                           Progress:
                           <div class="progress">
                              <div class="progress-bar progress-bar-striped bg-info" role="progressbar" style="width: 30%" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-3 col-sm-6 col-12 flex" style="margin-bottom:30px;">
                     <div class="card flex-fill h-40  bg-light" width="1.8rem">
                        <div class="card-header border-0">
                           <h4>Open Tickets</h4>
                           <a href="" style="color:red;text-decoration: none; margin-left:20px; font-size:18px"> -2.8%</a>
                        </div>
                        <div class="card-body card-type-4">
                           <h3 class="card-title">100</h3>
                           <h6 class="card-title">
                           Progress:
                           <div class="progress">
                              <div class="progress-bar progress-bar-striped bg-info" role="progressbar" style="width: 40%" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-3 col-sm-6 col-12 flex" style="margin-bottom:30px;">
                     <div class="card flex-fill h-30  bg-light" width="1.8rem">
                        <div class="card-header border-0">
                           <h4>Pending Tickets</h4>
                           <a href="" style="color:red;text-decoration: none;  font-size:18px"> -75%</a>
                        </div>
                        <div class="card-body card-type-4">
                           <h3 class="card-title">125</h3>
                           <h6 class="card-title">
                           Progress:
                           <div class="progress">
                              <div class="progress-bar progress-bar-striped bg-info" role="progressbar" style="width: 50%" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100"></div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12">
                     <table class="table table-striped table-hover"">
                        <thead>
                           <tr>
                              
                              <th>Ticket id</th>
                              <th>Ticket Subject</th>
                              <th>Assigned staff</th>
                              <th>Created date</th>
                              <th>Last Reply</th>
                              <th>Priority</th>
                              <th>Status</th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php
                           $mysql="select * from tickets";
                           $query=mysqli_query($con,$mysql);
                           while($data=mysqli_fetch_assoc($query)){
                              ?>
                           <tr>
                            
                              <td><?php echo $data["Ticketid"];?></td>
                              <td><?php echo $data["TicketSubject"];?></td>
                              <td> 
                              <?php echo $data["AssignedStaff"];?></td>
                              <td><?php echo $data["Createddate"];?></td>
                              <td><?php echo $data["LastReply"];?></td>
                              <td><?php echo $data["Priority"];?>
                                 <select class="form-select form-select-lg rounded-pill text-center">
                                    <i  class="fas fa-dot-circle-o text-purple me-2"></i>
                                    <option value="high" selected>high</option>
                                    <option value="medium">medium</option>
                                    <option value="low">low</option>
                                 </select>
                              </td>
                              <td><?php echo $data["Status"];?>
                                  <select class="form-select form-select-lg rounded-pill text-center">
                                    </i>
                                    <option value="New" selected>New</option>
                                    <option value="open">Open</option>
                                    <option value="Reopened">Reopened</option>
                                    <option value="On Hold">On Hold</option>
                                    <option value="Closed">Closed</option>
                                    <option value="In Progress">In Progress</option>
                                    <option value="Cancelled">Cancelled</option>
                                 </select> 
                              </td>
                           </tr>
                          
                           
                           <?php
                           }?>
                        </tbody>
                     </table>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-4"></div>
                  <div class="col-md-3">
                     <nav aria-label="...">
                        <ul class="pagination">
                           <li class="page-item   ">
                              <a class="page-link " href="#" tabindex="-1" aria-disabled="true">Previous</a>
                           </li>
                           <li class="page-item active"><a class="page-link" href="#">1</a></li>
                           <li class="page-item " aria-current="page">
                              <a class="page-link" href="#">2</a>
                           </li>
                           <li class="page-item">
                              <a class="page-link" href="#">Next</a>
                           </li>
                        </ul>
                     </nav>
                  </div>
               </div>
            </div>
            <footer class="main-footer">
               <div class="footer-left">
                  Copyright &copy; 2022 
                  <div class="bullet"></div>
                  Design By <a href="#">Snkthemes</a>
               </div>
               <div class="footer-right">
               </div>
            </footer>
         </div>
      </div>
      <!-- General JS Scripts -->
      <script src="assets/js/app.min.js"></script>
      <!-- JS Libraies -->
      <!-- Page Specific JS File -->
      <!-- Template JS File -->
      <script src="assets/js/scripts.js"></script>
   </body>
   <script>
      $("#formvalidate").click(function()
      {
      $(".error").hide();
      var fname=$("#name").val();
      var lea=$("#lead").val();
      var Reply=$("#reply").val();
      var sel=$("#dropdown").val();
      var sel1=$("#dropdown1").val();
      
      var st=$("#strt").val();
      var en=$("#end").val();
      var error=false;
      
      if(fname=='')
      {
      $("#name").after('<div class="error" style="color:red">Please enter ticket id</div>')
      error=true;
      }
      if(lea=='')
      {
      $("#lead").after('<div class="error" style="color:red">Please enter ticket subject</div>')
      error=true;
      }
      if(Reply=='')
      {
      $("#reply").after('<div class="error" style="color:red">Please enter last reply date id</div>')
      error=true;
      }
      
      if(sel=='')
      {
      $("#dropdown").after('<div class="error" style="color:red">Please give priority </div>')
      error=true;
      }
      if(sel1=='')
      {
      $("#dropdown1").after('<div class="error" style="color:red">Please give status </div>')
      error=true;
      }
      if(st=='')
      {
          $("#strt").after('<div class="error" style="color:red;">Please mention assigned staff</div>')
      }
      if(en=='')
      {
          $("#end").after('<div class="error" style="color:red;">Please enter created date</div>')
      }
      
      
      
      if(error==true)
      {
          return false;
      }
      });
      
      $("#dropdown").change(function()
      {
      $("#dropdown option:selected").each(function()
      {
      if($(this).prop('selected'))
      {
      var drop=this.value;
      console.log("selected degree"+drop);
      }
      });
      });
      
      
          
          
   </script>
 </html>