<?php include("connection.php");?>
<?php
$pname=$_POST['pname'];
$email=$_POST['email'];
$number=$_POST['number'];
$bdy=$_POST['bdy'];
$country=$_POST['country'];
$state=$_POST['state'];
$passport=$_POST['passport'];
$gen=$_POST['gen'];
$pan=$_POST['pan'];
$aadhar=$_POST['aadhar'];
$city=$_POST['city'];
$religion=$_POST['religion'];
$add=$_POST['add'];
$paddr=$_POST['paddr'];

$ename=$_POST['ename'];
$ename1=$_POST['ename1'];
$enum=$_POST['enum'];
$enum1=$_POST['enum1']; 
$eadd=$_POST['eadd'];
$eadd1=$_POST['eadd1'];

$school=$_POST['school'];
$sper=$_POST['sper'];
$inter=$_POST['inter']; 
$iper=$_POST['iper'];
$grad=$_POST['grad'];
$gper=$_POST['gper'];
$post=$_POST['post'];
$pper=$_POST['pper'];
$project=$_POST['project'];
 
$bank=$_POST['bank'];
$bankname=$_POST['bankname'];
$acc=$_POST['acc'];
$ifsc=$_POST['ifsc']; 
$branch=$_POST['branch'];
$code=$_POST['code'];

$joining=$_POST['joining'];
$join=$_POST['join'];
$eid=$_POST['eid']; 
$jemail=$_POST['jemail'];
$manager=$_POST['manager'];
$jpro=$_POST['jpro'];

$pfname=$_POST['pfname'];
$pfacc=$_POST['pfacc'];
$uan=$_POST['uan']; 
$pfbranch=$_POST['pfbranch'];
$esi=$_POST['esi'];
$esibranch=$_POST['esibranch'];
 $mysql="Insert into addemployee values('$pname','$email','$number','$bdy','$country','$state','$passport','$gen','$pan','$aadhar','$city',    
 '$religion','$add','$paddr',
 '$ename','$ename1','$enum','$enum1','$eadd','$eadd1',
'$school','$sper','$inter','$iper','$grad','$gper','$post','$pper','$project',    
'$bank','$bankname','$acc','$ifsc','$branch','$code',
'$joining','$join','$eid','$jemail','$manager','$jpro',
'$pfname','$pfacc','$uan','$pfbranch','$esi', '$esibranch'
)";
if(mysqli_query($con,$mysql))
{
    header("Location:Add Employee1.php");
    exit();
}
else{
    echo "Error";
}
mysqli_close($con);
?>