<?php include("connection.php");?>
<?php
 
$company=$_POST['company']; 
$client=$_POST['client'];
$role=$_POST['role'];
 
 
$mysql="Insert into clients values( '$company','$client','$role')";
if(mysqli_query($con,$mysql))
{
    header("Location: Clients_page.php");
    exit();
}
else{
    echo "Error";
}
mysqli_close($con);
?>