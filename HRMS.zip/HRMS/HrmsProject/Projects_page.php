
<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from radixtouch.in/templates/snkthemes/grexa/source/light/avatar.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 06 Feb 2021 10:37:47 GMT -->
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title>Grexa - Admin Dashboard Template</title>
  <!-- General CSS Files -->
  <link rel="stylesheet" href="assets/css/app.min.css">
  <!-- Template CSS -->
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="assets/css/components.css">
  <!-- Custom style CSS -->
  
  <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.ico' />
  <style>
    .login{
    margin-top:60px;
    margin-left:60px;
}
.first{
    margin-top:20px;
    margin-left:210px;
}

.login button{
    margin-left:250px;
    padding:8px 15px 8px 15px;
    margin-top:10px;
  
}
  </style>

</head>

<body>
  <div class="loader"></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
      <nav class="navbar navbar-expand-lg main-navbar">
        <div class="form-inline mr-auto">
          <ul class="navbar-nav mr-3">
            <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg collapse-btn"><i
                  class="fas fa-bars"></i></a></li>
            </div>
          </li>
        </ul>
      </nav>
      <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <div class="sidebar-brand">
            <a href="index.html">
              <img alt="image" src="assets/img/logo.png" class="header-logo" />
              <span class="logo-name">Grexa</span>
            </a>
          </div>
          <ul class="sidebar-menu">
            <li class="menu-header">Main</li>
            <li class="dropdown">
              <a href="#" class="nav-link has-dropdown"><i class="fas fa-home"></i><span>Dashboard</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="index.php">Admin Dashboard</a></li>
               </ul>
            </li>
         
            <li class="dropdown ">
              <a href="#" class="nav-link has-dropdown"><i class="fas fa-leaf"></i><span>Employee
                  </span></a>
              <ul class="dropdown-menu">
                <li class=""><a class="nav-link" href="Employee dashboard.php">Employee Dashboard</a></li>
                <li><a class="nav-link" href="Add Employee.php">Add Employee</a></li>
               
               </ul>
            </li>
            <li class="dropdown">
              <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Leaves</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="Apply leave.php">Apply Leave</a></li>
                <li><a class="nav-link" href="Leave list.php">Leave List</a></li>
              </ul>
            </li>
            <li class="dropdown active">
              <a href="#" class="nav-link has-dropdown"><i class="fas fa-anchor"></i><span> Project</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link active" href="Project lists.php">Project lists</a></li>
                <li class="active"><a class="nav-link" href="Projects_page.php">Projects</a></li>

              </ul>
            </li>
          
          
            <li class="dropdown ">
              <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Tickets</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="Tickets list.php">Tickets list</a></li>
                
              </ul>
            </li>
  <li class="dropdown">
    <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Payroll</span></a>
    <ul class="dropdown-menu">
      <li><a class="nav-link" href="Employee salary.php">Employee salary</a></li>
      <li><a class="nav-link" href="payslip.php">payslip</a></li>
      
    </ul>
  </li>
  <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Clients</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="Clients_page.php">Client form</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Leads</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Leads.php">Leads</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-hand-point-down"></i><span>Assets</span></a>
         <ul class="dropdown-menu">
         <li>  <a class="nav-link" href="Assests.php">Assets</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Performance</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="performance indicator.php">Performance Indicator</a></li>
         <li><a class="nav-link" href="performance Review.php">Performance Review</a></li>
         <li><a class="nav-link" href="performance Appraisal.php">Performance Appraisal  </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-crosshairs"></i><span>Goals</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="goals-list.php">Goal List</a></li>
         <li><a class="nav-link" href="goals-type.php">Goal type</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-pencil-alt"></i><span>Training</span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="training-list.php">Training List</a></li>
         <li><a class="nav-link" href="Trainers.php">Trainers</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-clipboard-check"></i><span>Jobs</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="job-dashboard.php">Jobs dashboard</a></li>
         <li><a class="nav-link" href="job-manage.php">ManageJobs</a></li>
         <li><a class="nav-link" href="job-resume.php">Manage Resumes</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-user-tie"></i><span>Interviews</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="interview-shortlist.php">Shortlist Candidates</a></li>
         <li><a class="nav-link" href="interview-schedule.php">Schedule time</a></li>
         <li><a class="nav-link" href="interview-offer.php">Offer  Approvals </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-file-alt"></i><span>Special Pages</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="policies.php">Policies</a></li>
         <li><a class="nav-link" href="FAQ.php">FAQ</a></li>
         <li><a class="nav-link" href="Terms of service.php">Terms Of Services</a></li>
         </ul>
         </li>
        </aside>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        
        <div class="card">
          <div class="card-body">
            <button type="button" class="btn btn-info " data-toggle="modal" data-target="#basicModal">
              + Edit Project
            </button>
          </div>
        </div>

        <div class="modal fade" id="basicModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
          aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit project details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <form action="projects.php" method="post">
                  <div class="row" style="margin-bottom:30px;">
                    <div class="col-md-6">
                      <label class=" form-label">Cost</label>
                      <input type="number" class="form-control"  name="pcost" required>
                    </div>
                    <div class="col-md-6">
                      <label class=" form-label">Total hours</label>
                      <input type="number" class="form-control"  name="hours" required>
                    </div>
                  </div>
                  <div class="row" style="margin-bottom:30px;">
                    <div class="col-md-6">
                      <label class=" form-label"> Created</label>
                      <input type="date" class="form-control"  name="created">
                    </div>
                    <div class="col-md-6">
                      <label class=" form-label">Deadline</label>
                      <input type="date" class="form-control"  name="deadline">
                    </div>

                  </div>
                  <div class="row" style="margin-bottom:30px;">
                    <div class="col-md-6">
                     <div>  <label class="form-label">priority</label></div>
                         <select class="form-select form-select-lg" style="width:200px;height:40px;"   name="priority">
                             <option> </option>
                             <option value="Highest">Highest priority</option>
                                <option value="Low">Lowest priority</option>
                             <option value="Medium">Normal priority</option>
                               </select>
                    </div>
                    <div class="col-md-6">
                      <label class=" form-label">Created by</label>
                      <input type="text" class="form-control"   name="by" required>
                    </div>
                  </div>
                  <div class="row" style="margin-bottom:30px;">
                    <div class="col-md-6">
                      <label class=" form-label">Status</label>
                      <input type="text" class="form-control"   name="sta" required>
                    </div>
                    <div class="col-md-6">
                      <label class=" form-label">Progress</label>
                      <input type="number" class="form-control" name="prog"  >
                    </div>
                  </div>
                   
                  <div class="row">
                    <div class="col-md-4"></div>
                    <div class="col-md-6">
                      <button class="btn btn-primary rounded-pill pr-3 pt-2 pl-3 text-center"
                         >Submit</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>

        <div class="row">
          <div class=" col-md-8">
            <div class="card">
              <div  class="card-body">
                <div  class="project-title">
                  <h5  class="card-title">Hospital Administration</h5>
                  <small  class="block text-ellipsis m-b-15">
                    <span class="text-xs">2</span>
                    <span  class="text-muted">open tasks, </span>
                    <span  class="text-xs">5</span>
                    <span  class="text-muted">tasks completed</span>
                  </small>
                </div>
                <p>Hospital administrators oversee the organizational side of health services. Either working in a team or independently, they make sure a medical facility is employing effective and efficient practices that deliver the best care possible. What a doctor is to a patient, a hospital administrator is to a medical facility. And keeping a large organization healthy requires a robust and multidimensional skillset.
        
                  According to the Bureau of Labor Statistics (May 2021), there were 429,800 people working as medical and health service managers across the country in May 2020. More than a third of those people work in hospitals as administrators and managers (33 percent). The U.S. News & World Report ranked the position of medical and health services manager at #1 among the ‘Best Business Jobs’, #4 among the ‘100 Best Jobs’, and #4 among the ‘Best STEM Jobs.’ Average wages (annual mean wage), according to the BLS (May 2021), for professionals in this field are $119,840 per year.
                  
                <br>  On a concrete level, a bachelor’s degree in a related field is the bare minimum of education required to be a hospital administrator. However, most hospital administrators have master’s degrees (often MHAs or MBAs) that provide both the advanced technical knowledge and the leadership skills necessary to run a large, multi-faceted, health organization.Hospital administrators need to be competent in analysis, communication, and maintaining collaborative relationships. And those competencies have to be grounded in a strong technical understanding and a detail-oriented approach that can effectively handle the industry’s nuances. Often, years of work experience are required in order to move into such a senior role.
        
                  In effect, hospital administrators save lives, but they do so in complex and varied ways. Read on to learn more about what this job entails, how it can look, and where it occurs </p>
              </div>
            </div>

           
            <div class="card">
              <div  class="card-body">
                <h5 class="card-title m-b-20">Uploaded image files</h5>
                <div  class="row">
                  <div class="col-md-3 col-sm-4 col-lg-4 col-xl-3">
                    <div  class="uploaded-box">
                      <div class="uploaded-img">
                        <img src="assets/img/users/uploadimg.png" alt="" width=40px; class="img-fluid">
                      </div>
                      <div  class="uploaded-img-name"> demo.png </div>
                    </div>
                  </div>
                  <div  class="col-md-3 col-sm-4 col-lg-4 col-xl-3">
                    <div class="uploaded-box">
                      <div  class="uploaded-img">
                        <img  src="assets/img/users/uploadimg.png" alt="" width=40px; class="img-fluid">
                      </div>
                      <div class="uploaded-img-name"> demo.png </div>
                    </div>
                  </div>
                  <div  class="col-md-3 col-sm-4 col-lg-4 col-xl-3">
                    <div class="uploaded-box">
                      <div  class="uploaded-img">
                        <img  src="assets/img/users/uploadimg.png" alt="" width=40px; class="img-fluid">
                      </div>
                      <div class="uploaded-img-name"> demo.png </div>
                    </div>
                  </div>
                  <div class="col-md-3 col-sm-4 col-lg-4 col-xl-3">
                    <div class="uploaded-box">
                      <div class="uploaded-img">
                        <img  src="assets/img/users/uploadimg.png" alt="" width=40px; class="img-fluid">
                      </div>
                      <div class="uploaded-img-name"> demo.png </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="project-task">
              <ul class="nav nav-tabs nav-tabs-top nav-justified mb-0">
                <li class="nav-item">
                  <a href="#all_tasks" data-bs-toggle="tab" aria-expanded="true" class="nav-link active">All Tasks</a></li>
                  <li class="nav-item">
                    <a href="" data-bs-toggle="tab" aria-expanded="false" class="nav-link">Pending Tasks</a></li>
                    <li class="nav-item">
                      <a href="" data-bs-toggle="tab" aria-expanded="false" class="nav-link">Completed Tasks</a></li>
                    </ul>
                    </div>
                    <div class="tab-content">
                      <div id="all_tasks" class="tab-pane show active">
                        <div class="task-wrapper">
                          <div class="task-list-container">
                            <div class="task-list-body">
                              <ul  id="task-list">
                                <li class="task" style="list-style-type:none">
                                  <div class="task-container">
                                    <span  class="task-action-btn task-check">
                                      <span  title="Mark Complete" class="action-circle large complete-btn">
                                        <i class="material-icons">check</i>
                                      </span>
                                    </span>
                                    <span contenteditable="true" class="task-label">Patient appointment booking</span>
                                   
                                  </div>
                                </li>
                                <li class="task" style="list-style-type:none">
                                  <div class="task-container">
                                    <span class="task-action-btn task-check">
                                      <span title="Mark Complete" class="action-circle large complete-btn">
                                        <i  class="material-icons">check</i>
                                      </span>
                                    </span>
                                    <span  contenteditable="true" class="task-label">Appointment booking with payment gateway</span>
            
                                   
                                  </div>
                                </li>
                                <li class="completed task" style="list-style-type:none">
                                  <div class="task-container">
                                    <span class="task-action-btn task-check">
                                      <span title="Mark Complete" class="action-circle large complete-btn">
                                        <i class="material-icons bg-success" >check</i>
                                      </span>
                                    </span>
                                    <span class="task-label bg-light">Doctor available module</span>
                                    
                                  </div>
                                </li>
                                <li class="task" style="list-style-type:none">
                                  <div  class="task-container">
                                    <span class="task-action-btn task-check">
                                      <span  title="Mark Complete" class="action-circle large complete-btn">
                                        <i  class="material-icons">check</i>
                                      </span>
                                    </span>
                                    <span  contenteditable="true" class="task-label ">Patient and Doctor video conferencing</span>
                                  </div>
                                </li>  
            
                                <li class="task" style="list-style-type:none">
                                  <div  class="task-container">
                                    <span class="task-action-btn task-check">
                                      <span  title="Mark Complete" class="action-circle large complete-btn">
                                        <i  class="material-icons">check</i>
                                      </span>
                                    </span>
                                    <span  contenteditable="true" class="task-label">Patient Profile add</span>
                                  </div>
                                </li>  
                                <li class="task" style="list-style-type:none">
                                  <div  class="task-container">
                                    <span class="task-action-btn task-check">
                                      <span  title="Mark Complete" class="action-circle large complete-btn">
                                        <i  class="material-icons">check</i>
                                      </span>
                                    </span>
                                    <span  contenteditable="true" class="task-label">Private chat module</span>
                                  </div>
                                </li>  
                              </ul></div>         
          </div>




        


          
        </div>
      </div>
      </div>
      </div>
      <div class="col-md-4">
<div class="card">
  <div class="card-body">
    <h6  class="card-title m-b-15">Project details</h6>
    <table  class="table table-striped table-border">
      <tbody>
        <tr>
          <td>Cost:</td>
          <td class="text-end">$1200</td>
        </tr>
        <tr>
          <td>Total Hours:</td>
          <td class="text-end">100 Hours</td>
        </tr>
        <tr>
          <td >Created:</td>
          <td  class="text-end">17-11-2022</td>
        </tr>
        <tr>
          <td >Deadline:</td>
          <td class="text-end">25-11-2022</td>
        </tr>
        <tr>
          <td >Priority:</td>
          <td>
            
              <div class="dropdown">
                <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" style="background-color: blue;">
                  High priority
                </button>
                <ul class="dropdown-menu">
                  <li><a class="dropdown-item" href="#">High priority</a></li>
                  <li><a class="dropdown-item" href="#">Normal priority</a></li>
                  <li><a class="dropdown-item" href="#">Low priority</a></li>
                </ul>
              </div>
                    
                  </td>
                </tr>
                <tr>
                  <td>Created by:</td>
                  <td  class="text-end">
                    <a  href="">Barry Cuda</a>
                  </td>
                </tr>
                <tr>
                  <td >Status:</td>
                  <td  class="text-end">Working</td>
                </tr>
              </tbody>
            </table>
            <p  class="m-b-5">Progress <span  class="text-success float-end">40%</span></p>
            <div class="progress progress-xs mb-0">
              <div  role="progressbar" data-bs-toggle="tooltip" title="40%" class="progress-bar bg-success" style="width: 40%;">
              </div>
            </div>
          </div>
        </div>
        <div  class="card project-user">
          <div  class="card-body">
            <h6  class="card-title m-b-20 text-center">Assigned Leader
                </h6>
            <ul  class="list-box">
              <li style="list-style-type:none">
                <a  href="" style="text-decoration:none">
                  <div  class="list-item">
                    <div  class="row">
                      <div  class="col-md-3">
                        <img src="assets/img/users/user-5.png" class="rounded-circle" alt="..." width="50px">
                      </div>
                      
                      <div class="col-md-6">
                        <span class="message-author">Wilmer Deluna</span>
                        <div class="clearfix"></div>
                        <span  class="message-content" style="color:black;font-size:13px;">Team Leader</span>
                      </div>
                    </div>
                  </div>
                  </a>
                </li>
                <li style="list-style-type:none">
                  <a href="" >
                    <div  class="list-item">
                      <div  class="row">
                        <div  class="col-md-3">
                          <img src="assets/img/users/user-7.png" class="rounded-circle" alt="..." width="50px">
                        </div>
                        
                        <div  class="col-md-6">
                          <span  class="message-author">Lesley Grauer</span>
                          <div  class="clearfix"></div>
                          <span  class="message-content" style="color:black;font-size:13px;">Team Leader</span>
                        </div>
                        </div>
                      </div>
                    </a>
                  </li>
                </ul>
              </div>
            </div>


            <div  class="card project-user">
              <div  class="card-body">
                <h6  class="card-title m-b-20 text-center">Assigned Users
                    </h6>
                <ul  class="list-box">
                  <li style="list-style-type:none">
                    <a  href="" style="text-decoration:none">
                      <div  class="list-item">
                        <div  class="row">
                          <div  class="col-md-3">
                            <img src="assets/img/users/user-3.png" class="rounded-circle" alt="..." width="50px">
                          </div>
                          
                          <div class="col-md-6">
                            <span class="message-author">John Doe</span>
                            <div class="clearfix"></div>
                            <span  class="message-content" style="color:black;font-size:13px;">Web designer</span>
                          </div>
                        </div>
                      </div>
                      </a>
                    </li>
                    <li style="list-style-type:none">
                      <a href="" style="text-decoration:none">
                        <div  class="list-item">
                          <div  class="row">
                            <div  class="col-md-3">
                              <img src="assets/img/users/user-5.png" class="rounded-circle" alt="..." width="50px">
                            </div>
                            
                            <div  class="col-md-6">
                              <span  class="message-author">Richard miles</span>
                              <div  class="clearfix"></div>
                              <span  class="message-content" style="color:black;font-size:13px;">Web Developer</span>
                            </div>
                            </div>
                          </div>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
      </div>
      </div>

      </div>
      <footer class="main-footer">
        <div class="footer-left">
          Copyright &copy; 2022 <div class="bullet"></div> Design By <a href="#">Snkthemes</a>
        </div>
        <div class="footer-right">
        </div>
      </footer>
    </div>
  </div>
  <!-- General JS Scripts -->
  <script src="assets/js/app.min.js"></script>
  <!-- JS Libraies -->
  <!-- Page Specific JS File -->
  <!-- Template JS File -->
  <script src="assets/js/scripts.js"></script>
  
</body>
<script>
      
$("#formvalidate").click(function()
{
$(".error").hide();
var cost1=$("#cost").val();
var hrs1=$("#hrs").val();
var sel=$("#dropdown").val();
 var crea=$("#create").val();
   var bdy=$("#dob").val();
var sta=$('#status').val();
 var st=$("#strt").val();
var en=$("#end").val();
var pro=$("#progress").val();
var error=false;

if(cost1=='')
{
$("#cost").after('<div class="error" style="color:red">Please enter cost</div>')
error=true;
}

if(hrs1=='')
{
$("#hrs").after('<div class="error" style="color:red">Please enter total hours</div>')
error=true;
}
if(sel=='')
{
    $("#dropdown").after('<div class="error" style="color:red;">Please enter your priority</div>')
}
 if(crea=='')
{
$("#create").after('<div class="error" style="color:red">Please enter created by</div>')
error=true;
}
 
if(st=='')
{
    $("#strt").after('<div class="error" style="color:red;">Please enter created date</div>')
    error=true;

}
if(en=='')
{
    $("#end").after('<div class="error" style="color:red;">Please enter deadline</div>')
    error=true;

}

if(sta=='')
{
    $("#status").after('<div class="error" style="color:red;">Please enter your status</div>')
    error=true;

}
if(pro=='')
{
    $("#progress").after('<div class="error" style="color:red;">Please enter your progress</div>')
    error=true;
}

if(error==true)
{
    return false;
}
});
 
    </script>

<!-- Mirrored from radixtouch.in/templates/snkthemes/grexa/source/light/avatar.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 06 Feb 2021 10:37:47 GMT -->
</html>