<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
      <title>Grexa - Admin Dashboard Template</title>
      <!-- General CSS Files -->
      <link rel="stylesheet" href="assets/css/app.min.css">
      <!-- Template CSS -->
      <link rel="stylesheet" href="assets/css/style.css">
      <link rel="stylesheet" href="assets/css/components.css">
      <!-- Custom style CSS -->
      <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.ico' />
   </head>
   <body>
      <div class="loader"></div>
      <div id="app">
      <div class="main-wrapper main-wrapper-1">
         <div class="navbar-bg"></div>
         <nav class="navbar navbar-expand-lg main-navbar">
            <div class="form-inline mr-auto">
               <ul class="navbar-nav mr-3">
                  <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg collapse-btn"><i
                     class="fas fa-bars"></i></a></li>
            </div>
            </li>
            </ul>
         </nav>
         <div class="main-sidebar sidebar-style-2">
            <aside id="sidebar-wrapper">
               <div class="sidebar-brand">
                  <a href="index.html">
                  <img alt="image" src="assets/img/logo.png" class="header-logo" />
                  <span class="logo-name">Grexa</span>
                  </a>
               </div>
               <ul class="sidebar-menu">
               <li class="menu-header">Main</li>
               <li class="dropdown">
                     <a href="#" class="nav-link has-dropdown"><i class="fas fa-home"></i><span>Dashboard</span></a>
                     <ul class="dropdown-menu">
                        <li><a class="nav-link" href="index.php">Admin Dashboard</a></li>
                     </ul>
                  </li>
                  <li class="dropdown ">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-leaf"></i><span>Employee
         </span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="Employee dashboard.php">Employee Dashboard</a></li>
         <li><a class="nav-link" href="Add Employee.php">Add Employee</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Leaves</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Apply leave.php">Apply Leave</a></li>
         <li><a class="nav-link" href="Leave list.php">Leave List</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-anchor"></i><span> Project</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="Project lists.php">Project lists</a></li>
         <li><a class="nav-link" href="Projects_page.php">Projects</a></li>
         </ul>
         </li>
         <li class="dropdown ">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Tickets</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Tickets list.php">Tickets list</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Payroll</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Employee salary.php">Employee salary</a></li>
         <li><a class="nav-link" href="payslip.php">payslip</a></li>
         </ul>
         </li>
                  <li class="dropdown active">
                     <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Clients</span></a>
                     <ul class="dropdown-menu">
                        <li><a class="nav-link active" href="Clients_page.php">Client form</a></li>
                     </ul>
                  </li>
                  
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Leads</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Leads.php">Leads</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-hand-point-down"></i><span>Assets</span></a>
         <ul class="dropdown-menu">
         <li>  <a class="nav-link" href="Assests.php">Assets</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Performance</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="performance indicator.php">Performance Indicator</a></li>
         <li><a class="nav-link" href="performance Review.php">Performance Review</a></li>
         <li><a class="nav-link" href="performance Appraisal.php">Performance Appraisal  </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-crosshairs"></i><span>Goals</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="goals-list.php">Goal List</a></li>
         <li><a class="nav-link" href="goals-type.php">Goal type</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-pencil-alt"></i><span>Training</span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="training-list.php">Training List</a></li>
         <li><a class="nav-link" href="Trainers.php">Trainers</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-clipboard-check"></i><span>Jobs</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="job-dashboard.php">Jobs dashboard</a></li>
         <li><a class="nav-link" href="job-manage.php">ManageJobs</a></li>
         <li><a class="nav-link" href="job-resume.php">Manage Resumes</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-user-tie"></i><span>Interviews</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="interview-shortlist.php">Shortlist Candidates</a></li>
         <li><a class="nav-link" href="interview-schedule.php">Schedule time</a></li>
         <li><a class="nav-link" href="interview-offer.php">Offer  Approvals </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-file-alt"></i><span>Special Pages</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="policies.php">Policies</a></li>
         <li><a class="nav-link" href="FAQ.php">FAQ</a></li>
         <li><a class="nav-link" href="Terms of service.php">Terms Of Services</a></li>
         </ul>
         </li>
            </aside>
         </div>
         <!-- Main Content -->
         <div class="main-content">
            <section class="section">
               <div class="section-header">
                  <h1>Profile</h1>
                  <div class="section-header-breadcrumb">
                     <div class="breadcrumb-item active"><a href="index.php">Dashboard</a></div>
                    
                     <div class="breadcrumb-item">client projects </div>
                  </div>
                  <!--section-header-breadcrumb-->
               </div>
               <!--section-header--->
               <div class="card mb-0">
                  <div class="card-body">
                     <div class="row">
                        <div class="col-md-4 text-center">
                           <img class="rounded-circle" src="assets/img/users/user-5.png" alt="..." width="220" height="236"> </a>
                        </div>
                        <div class="col-md-4 text-center pt-4 ">
                           <h5>Global Technologies</h5>
                           <p class="mb-0" style="font-size:medium">Barry Cuda</p>
                           <small class=" text-muted ">CEO</small>
                           <p>Employee ID : CLT-0008</p>
                        </div>
                        <div class="col-md-4 pt-4">
                           <ul style="list-style-type: none;">
                              <li>
                                 <span class="title"><b>phone:</b></span>
                                 <span class="text">
                                 <a href="" style="text-decoration:none">9876543210</a></span>
                              </li>
                              <li><span class="title"><b>Email:</b></span>
                                 <span class="text">
                                 <a href="" style="text-decoration:none">barrycuda@example.com</a></span>
                              </li>
                              <li><span class="title"><b>Birthday:</b></span>
                                 <span class="text">2nd August</span>
                              </li>
                              <li><span class="title"><b>Address:</b></span>
                                 <span class="text">5754 Airport Rd, Coosada, AL, 36020</span>
                              </li>
                              <li><span class="title"><b>Gender:</b></span>
                                 <span class="text">Male</span>
                              </li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="card tab-box ">
                  <div class="row user-tabs">
                     <div class="col-lg-12 col-md-12 col-sm-12 line-tabs ">
                        <ul class="nav nav-tabs nav-tabs-bottom ">
                           <li class="nav-item col-sm-3">
                              <a data-bs-toggle="tab" href="#myprojects" class="nav-link active " style="color:blue">Projects</a>
                           </li>
                           <li class="nav-item col-sm-3">
                              <a data-bs-toggle="tab" href="#tasks" class="nav-link " style="color:blue">
                              Tasks</a>
                           </li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-4 col-sm-6 col-12 flex" style="margin-bottom:30px;">
                     <div class="card flex-fill h-100" width="1.8rem">
                        <div class="card-header border-0">
                           <h4>Office Management</h4>
                        </div>
                        <div class="card-header">
                           <div class="block text-ellipsis m-b-15">
                              <span _ngcontent-tqd-c60="" class="text-xs">1</span>
                              <span _ngcontent-tqd-c60="" class="text-muted">open tasks, </span>
                              <span ngcontent-tqd-c60="" class="text-xs">9</span><span ngcontent-tqd-c60=""
                                 class="text-muted">tasks completed</span>
                           </div>
                        </div>
                        <div class="card-body card-type-4">
                           <p class="card-text ">
                              Office management is a profession involving the design, implementation, evaluation, and maintenance
                              of the process of work within an office or other organization,
                              in order to sustain and improve efficiency and productivity.
                           </p>
                           <h6 class="card-title">Deadline:</h6>
                           <h6 class="card-subtitle text-muted">17-11-2022</h6>
                           <br>
                           <h6 class="card-title">Project leader:</h6>
                           <figure class="avatar round mr-2">
                              <img src="assets/img/users/user-5.png" alt="...">
                           </figure>
                           <h6 class="card-title">Team</h6>
                           <figure class="avatar round mr-2">
                              <img src="assets/img/users/user-3.png" alt="...">
                           </figure>
                           <figure class="avatar round mr-2">
                              <img src="assets/img/users/user-3.png" alt="...">
                           </figure>
                           <figure class="avatar round mr-2">
                              <img src="assets/img/users/user-3.png" alt="...">
                           </figure>
                           <h6 class="card-title">Progress:<a href=""
                              style="color:green; margin-left:180px;text-decoration: none;"> 40%</a></h6>
                           <div class="progress">
                              <div class="progress-bar bg-success" role="progressbar" aria-label="Basic example"
                                 style="width: 35%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-4 col-sm-6 col-12 flex" style="margin-bottom:30px;">
                     <div class="card flex-fill h-100" width="1.8rem">
                        <div class="card-header border-0">
                           <h4>Hospital Administration</h4>
                        </div>
                        <div class="card-header">
                           <div class="block text-ellipsis m-b-15">
                              <span _ngcontent-tqd-c60="" class="text-xs">3</span>
                              <span _ngcontent-tqd-c60="" class="text-muted">open tasks, </span>
                              <span ngcontent-tqd-c60="" class="text-xs">15</span><span ngcontent-tqd-c60=""
                                 class="text-muted">tasks completed</span>
                           </div>
                        </div>
                        <div class="card-body card-type-4">
                           <p class="card-text h-98">Our project Hospital Management system includes registration of patients,
                              storing their details into the system, and also booking their appointments with doctors.
                           </p>
                           <h6 class="card-title ">Deadline:</h6>
                           <h6 class="card-subtitle text-muted">12-11-2022</h6>
                           <br>
                           <h6 class="card-title">Project leader:</h6>
                           <figure class="avatar round mr-2">
                              <img src="assets/img/users/user-5.png" alt="...">
                           </figure>
                           <h6 class="card-title">Team</h6>
                           <figure class="avatar round mr-2">
                              <img src="assets/img/users/user-3.png" alt="...">
                           </figure>
                           <figure class="avatar round mr-2">
                              <img src="assets/img/users/user-3.png" alt="...">
                           </figure>
                           <figure class="avatar round mr-2">
                              <img src="assets/img/users/user-3.png" alt="...">
                           </figure>
                           <h6 class="card-title">Progress:<a href=""
                              style="color:green; margin-left:180px;text-decoration: none;"> 20%</a></h6>
                           <div class="progress">
                              <div class="progress-bar bg-success" role="progressbar" aria-label="Basic example"
                                 style="width: 25%" aria-valuenow="15" aria-valuemin="0" aria-valuemax="100"></div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-4 col-sm-6 col-12 flex" style="margin-bottom:30px;">
                     <div class="card flex-fill h-100" width="1.8rem">
                        <div class="card-header border-0">
                           <h4>Project Management</h4>
                        </div>
                        <div class="card-header">
                           <div class="block   m-b-15">
                              <span _ngcontent-tqd-c60="" class="text-xs">2</span>
                              <span _ngcontent-tqd-c60="" class="text-muted">open tasks, </span>
                              <span ngcontent-tqd-c60="" class="text-xs">9</span><span ngcontent-tqd-c60=""
                                 class="text-muted">tasks completed</span>
                           </div>
                        </div>
                        <div class="card-body card-type-4 ">
                           <p class="card-text">Project managers are involved in various daily tasks that primarily include
                              dealing with people across teams and organizational hierarchies. They have to run through a daily
                              checklist of monitoring the progress of projects, optimizing the critical paths, and resolving
                              blocking issues that the teams may be facing.
                           </p>
                           <h6 class="card-title">Deadline:</h6>
                           <h6 class="card-subtitle text-muted">1-12-2022</h6>
                           <br>
                           <h6 class="card-title">Project leader:</h6>
                           <figure class="avatar round mr-2">
                              <img src="assets/img/users/user-5.png" alt="...">
                           </figure>
                           <h6 class="card-title">Team</h6>
                           <figure class="avatar round mr-2">
                              <img src="assets/img/users/user-3.png" alt="...">
                           </figure>
                           <figure class="avatar round mr-2">
                              <img src="assets/img/users/user-3.png" alt="...">
                           </figure>
                           <figure class="avatar round mr-2">
                              <img src="assets/img/users/user-3.png" alt="...">
                           </figure>
                           <h6 class="card-title">Progress:<a href=""
                              style="color:green; margin-left:180px;text-decoration: none;"> 70%</a></h6>
                           <div class="progress">
                              <div class="progress-bar bg-success" role="progressbar" aria-label="Basic example"
                                 style="width: 75%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-md-4 col-sm-6 col-12">
                     <div class="card flex-fill h-100" width="1.8rem">
                        <div class="card-header border-0">
                           <h4>Video Calling App</h4>
                        </div>
                        <div class="card-header">
                           <div class="block text-ellipsis m-b-15">
                              <span _ngcontent-tqd-c60="" class="text-xs">5</span>
                              <span _ngcontent-tqd-c60="" class="text-muted">open tasks, </span>
                              <span ngcontent-tqd-c60="" class="text-xs">13</span><span ngcontent-tqd-c60=""
                                 class="text-muted">tasks completed</span>
                           </div>
                        </div>
                        <div class="card-body">
                           <p class="card-text">video call feature has become standard in person-to-person (P2P) mobile
                              communication apps like WhatsApp and Viber. These messaging apps are mostly used on mobile. On the
                              other hand, business apps like Skype and Zoom offer video call functions on mobile, desktop, and
                              web.
                           </p>
                           <h6 class="card-title">Deadline:</h6>
                           <h6 class="card-subtitle text-muted">07-12-2022</h6>
                           <br>
                           <h6 class="card-title">Project leader:</h6>
                           <figure class="avatar round mr-2">
                              <img src="assets/img/users/user-5.png" alt="...">
                           </figure>
                           <h6 class="card-title">Team</h6>
                           <figure class="avatar round mr-2">
                              <img src="assets/img/users/user-3.png" alt="...">
                           </figure>
                           <figure class="avatar round mr-2">
                              <img src="assets/img/users/user-3.png" alt="...">
                           </figure>
                           <figure class="avatar round mr-2">
                              <img src="assets/img/users/user-3.png" alt="...">
                           </figure>
                           <h6 class="card-title">Progress:<a href=""
                              style="color:green; margin-left:180px;text-decoration: none;"> 40%</a></h6>
                           <div class="progress">
                              <div class="progress-bar bg-success" role="progressbar" aria-label="Basic example"
                                 style="width: 35%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                           </div>
                        </div>
                     </div>
                  </div>
            </section>
            </div>
            <footer class="main-footer">
               <div class="footer-left">
                  Copyright &copy; 2022 
                  <div class="bullet"></div>
                  Design By <a href="#">Snkthemes</a>
               </div>
               <div class="footer-right">
               </div>
            </footer>
         </div>
      </div>
      <!-- General JS Scripts -->
      <script src="assets/js/app.min.js"></script>
      <!-- JS Libraies -->
      <script src="assets/bundles/amcharts4/core.js"></script>
      <script src="assets/bundles/amcharts4/charts.js"></script>
      <script src="assets/bundles/amcharts4/animated.js"></script>
      <script src="assets/bundles/amcharts4/worldLow.js"></script>
      <script src="assets/bundles/amcharts4/maps.js"></script>
      <!-- Page Specific JS File -->
      <script src="assets/js/page/chart-amchart.js"></script>
      <!-- Template JS File -->
      <script src="assets/js/scripts.js"></script>
   </body>
</html>