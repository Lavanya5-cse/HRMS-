<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from radixtouch.in/templates/snkthemes/grexa/source/light/breadcrumb.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 06 Feb 2021 10:37:44 GMT -->
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title>Grexa - Admin Dashboard Template</title>
  <!-- General CSS Files -->
  <link rel="stylesheet" href="assets/css/app.min.css">
  <!-- Template CSS -->
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="assets/css/components.css">
  <!-- Custom style CSS -->
  
  <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.ico' />
</head>

<body>
  <div class="loader"></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
      <nav class="navbar navbar-expand-lg main-navbar">
        <div class="form-inline mr-auto">
          <ul class="navbar-nav mr-3">
            <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg collapse-btn"><i
                  class="fas fa-bars"></i></a></li>
           
          </ul>
        </div>
        
      </nav>
      <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <div class="sidebar-brand">
            <a href="index.html">

              <img alt="image" src="assets/img/logo.png" class="header-logo" />
              <span class="logo-name">Grexa</span>
            </a>
          </div>
          <ul class="sidebar-menu">
			<li class="dropdown">
				<a href="#" class="nav-link has-dropdown"><i class="fas fa-home"></i><span>Dashboard</span></a>
				<ul class="dropdown-menu">
				  <li><a class="nav-link" href="index.php">Admin Dashboard</a></li>
				 </ul>
			  </li>
        <li class="dropdown ">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-leaf"></i><span>Employee
         </span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="Employee dashboard.php">Employee Dashboard</a></li>
         <li><a class="nav-link" href="Add Employee.php">Add Employee</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Leaves</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Apply leave.php">Apply Leave</a></li>
         <li><a class="nav-link" href="Leave list.php">Leave List</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-anchor"></i><span> Project</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="Project lists.php">Project lists</a></li>
         <li><a class="nav-link" href="Projects_page.php">Projects</a></li>
         </ul>
         </li>
         <li class="dropdown ">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Tickets</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Tickets list.php">Tickets list</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Payroll</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Employee salary.php">Employee salary</a></li>
         <li><a class="nav-link" href="payslip.php">payslip</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Clients</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="Clients_page.php">Client form</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Leads</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Leads.php">Leads</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-hand-point-down"></i><span>Assets</span></a>
         <ul class="dropdown-menu">
         <li>  <a class="nav-link" href="Assests.php">Assets</a></li>
         </ul>
         </li>
            <li class="dropdown active">
              <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Performance</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="performance indicator.php">Performance Indicator</a></li>
                <li class="active"><a class="nav-link" href="performance Review.php">Performance Review</a></li>
                <li><a class="nav-link" href="performance Appraisal.php">Performance Appraisal  </a></li>
                
              </ul>
            </li>
            <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-crosshairs"></i><span>Goals</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="goals-list.php">Goal List</a></li>
         <li><a class="nav-link" href="goals-type.php">Goal type</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-pencil-alt"></i><span>Training</span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="training-list.php">Training List</a></li>
         <li><a class="nav-link" href="Trainers.php">Trainers</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-clipboard-check"></i><span>Jobs</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="job-dashboard.php">Jobs dashboard</a></li>
         <li><a class="nav-link" href="job-manage.php">ManageJobs</a></li>
         <li><a class="nav-link" href="job-resume.php">Manage Resumes</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-user-tie"></i><span>Interviews</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link " href="interview-shortlist.php">Shortlist Candidates</a></li>
         <li><a class="nav-link" href="interview-schedule.php">Schedule time</a></li>
         <li><a class="nav-link" href="interview-offer.php">Offer  Approvals </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-file-alt"></i><span>Special Pages</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="policies.php">Policies</a></li>
         <li><a class="nav-link" href="FAQ.php">FAQ</a></li>
         <li><a class="nav-link" href="Terms of service.php">Terms Of Services</a></li>
         </ul>
         </li>
        </aside>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="section-header">
            <h1>Performance</h1>
            <div class="section-header-breadcrumb">
              <div class="breadcrumb-item active"><a href="index.php">Dashboard</a></div>
              <div class="breadcrumb-item"><a href="performance indicator.php"> Performance Indicate</a></div>
              <div class="breadcrumb-item">Performance review </div>
              <div class="breadcrumb-item"><a href="performance Appraisal.php">Performance Appraisal</a></div>

            </div>
          </div>
        </section>
        <!------------------section2-->
       <div class="container">
        <div class="row">
          <div class="col-md-12 ">
            <div class="card w-100">
              
              <div class="row ">
                <div class="col-md-2 ">  </div>
                <div class="col-md-6 ">
                  <div class="card-header ">
                    <div class="text-center">
                    <h3 class=" text-center">Employee Basic Information</h3>
                    <p class="text-muted">Global Technologies</p>
                    </div>

                  </div>
                  
                </div><div class="col-md-4 "></div>
                <div class="col-md-12">
                  <div class="card-body">
                    <div class="row ">
                      <div class="col-md-4">
                        <div class="table-responsive">
                          <table class="table table-bordered   mb-0">
                            <tbody>
                              <tr>
                                <td>
                                  <form>
                                    <div  class="form-group">
                                      <label for="name">Name </label>
                                      <input type="text" id="name" class="form-control">
                                    </div>
                                    <div  class="form-group">
                                      <label for="name">Department  </label>
                                      <input type="text" id="name" class="form-control">
                                    </div>
                                    <div  class="form-group">
                                      <label for="name">Designation  </label>
                                      <input type="text" id="name" class="form-control">
                                    </div>
                                    <div  class="form-group">
                                      <label for="name">Qualification </label>
                                      <input type="text" id="name" class="form-control">
                                    </div>
                                  </form>
                                </td>
                              </tr>
                            </tbody>
        
                          </table>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="table-responsive">
                          <table class="table table-bordered   mb-0">
                            <tbody>
                              <tr>
                                <td>
                                  <form>
                                    <div  class="form-group">
                                      <label for="name">Emp ID </label>
                                      <input type="text" id="name" value="IN901798" class="form-control">
                                    </div>
                                    <div  class="form-group">
                                      <label for="name">Date Of Joining  </label>
                                      <input type="text" id="name" class="form-control">
                                    </div>
                                    <div  class="form-group">
                                      <label for="name">Date Of Conformation  </label>
                                      <input type="text" id="name" class="form-control">
                                    </div>
                                    <div  class="form-group">
                                      <label for="name">Previous Years Of Exp </label>
                                      <input type="text" id="name" class="form-control">
                                    </div>
                                  </form>
                                </td>
                              </tr>
                            </tbody>
        
                          </table>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="table-responsive">
                          <table class="table table-bordered   mb-0">
                            <tbody>
                              <tr>
                                <td>
                                  <form>
                                    <div  class="form-group">
                                      <label for="name">RO's Name </label>
                                      <input type="text" id="name" value="" class="form-control">
                                    </div>
                                    <div  class="form-group">
                                      <label for="name">RO Designation  </label>
                                      <input type="text" id="name" class="form-control">
                                    </div>
                                    
                                  </form>
                                </td>
                              </tr>
                            </tbody>
        
                          </table>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-12">
                      <div class="card-body"> 
                        
                  </div>
                  </div>
                  </div>
                </div>
                  
                
              </div>
             
            </div>
          </div>
          <div class="col-md-12 ">
            <div class="card w-100">
              
              <div class="row ">
                <div class="col-md-3 ">  </div>
                <div class="col-md-6 ">
                  <div class="card-header ">
                    <div class="text-center">
                    <h3 class=" text-center">Professional Excellence</h3>
                    <p class="text-muted">Global Technologies</p>
                    </div>

                  </div>
                  
                </div><div class="col-md-3 "></div>
                <div class="col-md-12">
                  <div class="card-body">
                    <div class="row ">
                      <div class="col-md-12">
                        <div class="table-responsive-md">
                          <table class="table table-bordered   mb-0">
                            <thead>
                              <tr >
                                <th >#</th>
                                <th  >Key Result Area</th>
                                <th  >Key Performance Indicators</th>
                                <th  >Weightage</th>
                                <th  >Percentage achieved <br  >( self Score )</th>
                                <th  >Points Scored <br  >( self )</th>
                                <th  >Percentage achieved <br  >( RO's Score )</th>
                                <th  >Points Scored <br  >( RO )</th></tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td rowspan="2">1</td>
                                <td rowspan="2">Production</td>
                                <td>Quality</td>
                                <td><input type="text" readonly="" value="30" class="form-control"></td>
                                <td><input type="text" class="form-control"></td>
                                <td><input type="text" readonly="" value="0" class="form-control"></td>
                                <td><input type="text" class="form-control"></td>
                                <td><input type="text" readonly="" value="0" class="form-control"></td>
                              </tr>
                              <tr>
                                <td>TAT (turn around time)</td>
                                <td><input   type="text" readonly="" value="30" class="form-control"></td>
                                <td><input   type="text" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                                <td><input   type="text" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                              </tr>
                              <tr>
                                <td >2</td>
                                <td  >Process Improvement</td>
                                <td>PMS,New Ideas</td>
                                <td><input   type="text" readonly="" value="10" class="form-control"></td>
                                <td><input   type="text" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                                <td><input   type="text" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                              </tr>
                              <tr>
                                <td>3</td>
                                <td>Team Management</td>
                                <td>Team Productivity,dynaics,attendance,attrition</td>
                                <td><input   type="text" readonly="" value="5" class="form-control"></td>
                                <td><input   type="text" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                                <td><input   type="text" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                              </tr>
                              <tr>
                                <td>4</td>
                                <td>Knowledge Sharing</td>
                                <td>Sharing the knowledge for team productivity </td>
                                <td><input   type="text" readonly="" value="5" class="form-control"></td>
                                <td><input   type="text" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                                <td><input   type="text" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                              </tr>
                              <tr>
                                <td>5</td>
                                <td>Reporting and Communication</td>
                                <td>Emails/Calls/Reports and Other Communication</td>
                                <td><input   type="text" readonly="" value="5" class="form-control"></td>
                                <td><input   type="text" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                                <td><input   type="text" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                              </tr>
                              <tr>
                                <td colspan="3" class="text-center">Total </td>
                                <td><input   type="text" readonly="" value="85" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                              </tr>
                             
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-12">
                      <div class="card-body"> 
                        
                  </div>
                  </div>
                  </div>
                </div>
                  
                
              </div>
             
            </div>
          </div>
          <div class="col-md-12 ">
            <div class="card w-100">
              
              <div class="row ">
                <div class="col-md-3 ">  </div>
                <div class="col-md-6 ">
                  <div class="card-header ">
                    <div class="text-center">
                    <h3 class=" text-center">Personal Excellence</h3>
                    <p class="text-muted">Global Technologies</p>
                    </div>

                  </div>
                  
                </div><div class="col-md-3 "></div>
                <div class="col-md-12">
                  <div class="card-body">
                    <div class="row ">
                      <div class="col-md-12">
                        <div class="table-responsive-md">
                          <table class="table table-bordered   mb-0">
                            <thead>
                              <tr >
                                <th   style="width: 40px;">#</th>
                                <th  >Personal Attributes</th>
                                <th  >Key Indicators</th>
                                <th  >Weightage</th>
                                <th  >Percentage achieved <br  >( self Score )</th>
                                <th  >Points Scored <br  >( self )</th>
                                <th  >Percentage achieved <br  >( RO's Score )</th>
                                <th  >Points Scored <br  >( RO )</th></tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td rowspan="2">1</td>
                                <td rowspan="2">Attendance</td>
                                <td>Planned or Unplanned Leaves</td>
                                <td><input type="text" readonly="" value="2" class="form-control"></td>
                                <td><input type="text" class="form-control"></td>
                                <td><input type="text" readonly="" value="0" class="form-control"></td>
                                <td><input type="text" class="form-control"></td>
                                <td><input type="text" readonly="" value="0" class="form-control"></td>
                              </tr>
                              <tr>
                                <td>	Time Consciousness</td>
                                <td><input   type="text" readonly="" value="2" class="form-control"></td>
                                <td><input   type="text" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                                <td><input   type="text" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                              </tr>
                              <tr>
                                <td rowspan="2">2</td>
                                <td rowspan="2">	Attitude & Behavior</td>
                                <td>	Team Collaboration</td>
                                <td><input   type="text" readonly="" value="2" class="form-control"></td>
                                <td><input   type="text" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                                <td><input   type="text" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                              </tr>
                              <tr>
                                <td>Professionalism & Responsiveness</td>
                                <td><input   type="text" readonly="" value="2" class="form-control"></td>
                                <td><input   type="text" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                                <td><input   type="text" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                              </tr>
                              
                              <tr>
                                <td>3</td>
                                <td>	Policy & Procedures</td>
                                <td>	Adherence to policies and procedures</td>
                                <td><input   type="text" readonly="" value="2" class="form-control"></td>
                                <td><input   type="text" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                                <td><input   type="text" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                              </tr>
                              <tr>
                                <td>4</td>
                                <td>	Initiatives</td>
                                <td>	Special Efforts, Suggestions,Ideas,etc. </td>
                                <td><input   type="text" readonly="" value="2" class="form-control"></td>
                                <td><input   type="text" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                                <td><input   type="text" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                              </tr>
                              <tr>
                                <td>5</td>
                                <td>	Continuous Skill Improvement</td>
                                <td>Preparedness to move to next level & Training utilization</td>
                                <td><input   type="text" readonly="" value="3" class="form-control"></td>
                                <td><input   type="text" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                                <td><input   type="text" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                              </tr>
                              <tr>
                                <td colspan="3" class="text-center">Total </td>
                                <td><input   type="text" readonly="" value="15" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                                <td><input   type="text" readonly="" value="0" class="form-control"></td>
                              </tr>
                              <tr>
                                <td colspan="8" class="text-center">
                                  <div class="grade-span">
                                    <h4 class="lead">Grade</h4>
                                    <span class="badge bg-danger text-light">Below 65 Poor</span>
                                    <span class="badge bg-warning text-light">65-74 Average</span>
                                    <span class="badge bg-info text-light">75-84 Satisfactory</span>
                                    <span class="badge bg-purple text-light">85-92 Good</span>
                                    <span class="badge bg-success text-light">Above 92 Excellent</span>
                                  </div>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-12">
                      <div class="card-body"> 
                        
                  </div>
                  </div>
                  </div>
                </div>
                  
                
              </div>
             
            </div>
          </div>
         

       </div>
       </div>
       <div class="settingSidebar">
        <a href="javascript:void(0)" class="settingPanelToggle"> <i
          class="fa fa-spin fa-cog"></i>
        </a>
        <div class="settingSidebar-body ps-container ps-theme-default">
          <div class=" fade show active">
            <div class="setting-panel-header">Theme Customizer</div>
            <div class="p-15 border-bottom">
              <h6 class="font-medium m-b-10">Theme Layout</h6>
              <div class="selectgroup layout-color w-50">
                <label> <span class="control-label p-r-20">Light</span>
                  <input type="radio" name="custom-switch-input" value="1"
                  class="custom-switch-input" checked> <span
                  class="custom-switch-indicator"></span>
                </label>
              </div>
              <div class="selectgroup layout-color  w-50">
                <label> <span class="control-label p-r-20">Dark&nbsp;</span>
                  <input type="radio" name="custom-switch-input" value="2"
                  class="custom-switch-input"> <span
                  class="custom-switch-indicator"></span>
                </label>
              </div>
            </div>
          </div>
          <div class="p-15 border-bottom">
            <h6 class="font-medium m-b-10">Sidebar Colors</h6>
            <div class="sidebar-setting-options">
              <ul class="sidebar-color list-unstyled mb-0">
                <li title="white" class="active">
                  <div class="white"></div>
                </li>
                <li title="blue">
                  <div class="blue"></div>
                </li>
                <li title="coral">
                  <div class="coral"></div>
                </li>
                <li title="purple">
                  <div class="purple"></div>
                </li>
                <li title="allports">
                  <div class="allports"></div>
                </li>
                <li title="barossa">
                  <div class="barossa"></div>
                </li>
                <li title="fancy">
                  <div class="fancy"></div>
                </li>
              </ul>
            </div>
      
          </div>
          <div class="p-15 border-bottom">
            <h6 class="font-medium m-b-10">Theme Colors</h6>
            <div class="theme-setting-options">
              <ul class="choose-theme list-unstyled mb-0">
                <li title="white" class="active">
                  <div class="white"></div>
                </li>
                <li title="blue">
                  <div class="blue"></div>
                </li>
                <li title="coral">
                  <div class="coral"></div>
                </li>
                <li title="purple">
                  <div class="purple"></div>
                </li>
                <li title="allports">
                  <div class="allports"></div>
                </li>
                <li title="barossa">
                  <div class="barossa"></div>
                </li>
                <li title="fancy">
                  <div class="fancy"></div>
                </li>
                <li title="cyan">
                  <div class="cyan"></div>
                </li>
                <li title="orange">
                  <div class="orange"></div>
                </li>
                <li title="green">
                  <div class="green"></div>
                </li>
                <li title="red">
                  <div class="red"></div>
                </li>
              </ul>
            </div>
          </div>
          <div class="p-15 border-bottom">
            <h6 class="font-medium m-b-10">Layout Options</h6>
            <div class="theme-setting-options">
              <label> <span class="control-label p-r-20">Compact
                  Sidebar Menu</span> <input type="checkbox"
                name="custom-switch-checkbox" class="custom-switch-input"
                id="mini_sidebar_setting"> <span
                class="custom-switch-indicator"></span>
              </label>
            </div>
          </div>
          <div class="mt-3 mb-3 align-center">
            <a href="#"
              class="btn btn-icon icon-left btn-outline-primary btn-restore-theme">
              <i class="fas fa-undo"></i> Restore Default
            </a>
          </div>
        </div>
      </div>
      <!----------------------main content div-->    
      </div>
      <footer class="main-footer">
        <div class="footer-left">
          Copyright &copy; 2022 <div class="bullet"></div> Design By <a href="#">Snkthemes</a>
        </div>
        <div class="footer-right">
        </div>
      </footer>
    </div>
  </div>
  <!-- General JS Scripts -->
  <script src="assets/js/app.min.js"></script>
  <!-- JS Libraies -->
  <!-- Page Specific JS File -->
  <!-- Template JS File -->
  <script src="assets/js/scripts.js"></script>
  
</body>


<!-- Mirrored from radixtouch.in/templates/snkthemes/grexa/source/light/breadcrumb.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 06 Feb 2021 10:37:44 GMT -->
</html>