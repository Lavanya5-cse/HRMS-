<?php include("connection.php");?>
<?php
$pcost=$_POST['pcost'];
$hours=$_POST['hours']; 
$created=$_POST['created'];
$deadline=$_POST['deadline'];
$priority=$_POST['priority'];
$by=$_POST['by'];
$sta=$_POST['sta'];
$prog=$_POST['prog'];
 $mysql="Insert into projects values('$pcost','$hours','$created','$deadline','$priority','$by','$sta','$prog')";
if(mysqli_query($con,$mysql))
{
    header("Location:Projects_page.php");
    exit();
}
else{
    echo "Error";
}
mysqli_close($con);
?>