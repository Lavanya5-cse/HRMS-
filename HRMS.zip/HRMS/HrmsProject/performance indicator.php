<?php include("connection.php");?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
      <title>Grexa - Admin Dashboard Template</title>
      <!-- General CSS Files -->
      <link rel="stylesheet" href="assets/css/app.min.css">
      <!-- Template CSS -->
      <link rel="stylesheet" href="assets/css/style.css">
      <link rel="stylesheet" href="assets/css/components.css">
      <!-- Custom style CSS -->
      <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.ico' />
   </head>
   <body>
      <div class="loader"></div>
      <div id="app">
         <div class="main-wrapper main-wrapper-1">
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar">
               <div class="form-inline mr-auto">
                  <ul class="navbar-nav mr-3">
                     <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg collapse-btn"><i
                        class="fas fa-bars"></i></a></li>
                  </ul>
               </div>
            </nav>
            <div class="main-sidebar sidebar-style-2">
               <aside id="sidebar-wrapper">
                  <div class="sidebar-brand">
                     <a href="index.html">
                     <img alt="image" src="assets/img/logo.png" class="header-logo" />
                     <span class="logo-name">Grexa</span>
                     </a>
                  </div>
                  <ul class="sidebar-menu">
                  <li class="dropdown">
                     <a href="#" class="nav-link has-dropdown"><i class="fas fa-home"></i><span>Dashboard</span></a>
                     <ul class="dropdown-menu">
                        <li><a class="nav-link" href="index.php">Admin Dashboard</a></li>
                     </ul>
                  </li>
                  <li class="dropdown ">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-leaf"></i><span>Employee
         </span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="Employee dashboard.php">Employee Dashboard</a></li>
         <li><a class="nav-link" href="Add Employee.php">Add Employee</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Leaves</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Apply leave.php">Apply Leave</a></li>
         <li><a class="nav-link" href="Leave list.php">Leave List</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-anchor"></i><span> Project</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="Project lists.php">Project lists</a></li>
         <li><a class="nav-link" href="Projects_page.php">Projects</a></li>
         </ul>
         </li>
         <li class="dropdown ">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Tickets</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Tickets list.php">Tickets list</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Payroll</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Employee salary.php">Employee salary</a></li>
         <li><a class="nav-link" href="payslip.php">payslip</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Clients</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="Clients_page.php">Client form</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Leads</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Leads.php">Leads</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-hand-point-down"></i><span>Assets</span></a>
         <ul class="dropdown-menu">
         <li>  <a class="nav-link" href="Assests.php">Assets</a></li>
         </ul>
         </li>
                  <li class="dropdown active">
                     <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Performance</span></a>
                     <ul class="dropdown-menu">
                        <li class="active"><a class="nav-link" href="performance indicator.php">Performance Indicator</a></li>
                        <li><a class="nav-link" href="performance Review.php">Performance Review</a></li>
                        <li><a class="nav-link" href="performance Appraisal.php">Performance Appraisal  </a></li>
                     </ul>
                  </li>
                  <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-crosshairs"></i><span>Goals</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="goals-list.php">Goal List</a></li>
         <li><a class="nav-link" href="goals-type.php">Goal type</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-pencil-alt"></i><span>Training</span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="training-list.php">Training List</a></li>
         <li><a class="nav-link" href="Trainers.php">Trainers</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-clipboard-check"></i><span>Jobs</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="job-dashboard.php">Jobs dashboard</a></li>
         <li><a class="nav-link" href="job-manage.php">ManageJobs</a></li>
         <li><a class="nav-link" href="job-resume.php">Manage Resumes</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-user-tie"></i><span>Interviews</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="interview-shortlist.php">Shortlist Candidates</a></li>
         <li><a class="nav-link" href="interview-schedule.php">Schedule time</a></li>
         <li><a class="nav-link" href="interview-offer.php">Offer  Approvals </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-file-alt"></i><span>Special Pages</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="policies.php">Policies</a></li>
         <li><a class="nav-link" href="FAQ.php">FAQ</a></li>
         <li><a class="nav-link" href="Terms of service.php">Terms Of Services</a></li>
         </ul>
         </li>
               </aside>
            </div>
            <!-- Main Content -->
            <div class="main-content">
               <section class="section">
                  <div class="section-header">
                     <h1>Performance</h1>
                     <div class="section-header-breadcrumb">
                        <div class="breadcrumb-item active"><a href="index.php">Dashboard</a></div>
                        <div class="breadcrumb-item">Performance Indicate</div>
                        <div class="breadcrumb-item"><a href="performance Review.php">Performance review</a></div>
                        <div class="breadcrumb-item"><a href="performance Appraisal.php">Performance Appraisal</a></div>
                     </div>
                  </div>
                  <div class="section-body">
                     <div class="row">
                        <div class="col-12 col-md-12 col-lg-12  ">
                           <div class="card">
                              <div class="card-body">
                                 <button type="button" class="btn btn-info " data-toggle="modal" data-target="#basicModal1">
                                 + Add Indicator
                                 </button>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </section>
               <div class="modal fade" id="basicModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                     <div class="modal-content">
                        <div class="modal-header">
                           <h5 class="modal-title" id="exampleModalLabel">Set New Indicator</h5>
                           <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                           <span aria-hidden="true">×</span>
                           </button>
                        </div>
                        <div  class="modal-body">
                           <form action="performanceIndicator.php" method="post">
                              <div  class="row" style="margin-bottom:30px;">
                                 <div  class="col-sm-8">
                                   
                                       <label  class="form-label">Emp Id</label>
                                       <input type="text." class="form-control"  name="empid">
                                    
                                 </div>
</div>
<div  class="row" style="margin-bottom:30px;">
                                 <div  class="col-sm-6">
                                    
                                       <label  class="      form-label   " >Designation</label>
                                       <input type="text" class="form-control"  name="desgn">
                                       <!---->
                                    </div>
                                    <div  class="col-sm-6">
                                    
                                       <label  class="      form-label   " >Department</label>
                                       <input type="text" class="form-control"  name="dept">
                                   
</div></div>
<div  class="row" style="margin-bottom:30px;">
<div  class="col-sm-6">
                                       <label  class="      form-label   " >Added By</label>
                                       <input type="text" class="form-control"   name="added">
                                       <!---->
                                    </div>
                                    <div  class="col-sm-6">
                                    
                                       <label  class="      form-label   ">	Created At</label>
                                       <input type="date" class="form-control" name="created">
                                    </div>
                                 </div>
                                  
                                     
                                 <div  class="row" style="margin-bottom:30px;">

                                 <div  class="col-sm-8">
                                    <div  class="form-group">
                                       <label  class="      form-label   " >Status</label>
                                       <select class="form-select form-control"  name="status">
                                          <option value=""></option>
                                          <option value="Active">Active</option>
                                          <option value="Inactive">Inactive</option>
                                       </select>
                                       <!---->
                                    </div>
                                 </div>
                              </div>
                              <div  class="submit-section">
                                 <button  class="btn btn-primary submit-btn" type="submit">Submit</button>
                              </div>
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="container">
                  <div class="row">
 
                     <div class="col-12 col-md-12 col-lg-12">
                        <div class="card">
                           <div class="card-header">
                              <h4>Star Performance List</h4>
                           </div>
                           <div class="card-body">
                              <div class="table-responsive">
                                 <table class="table table-striped table-hover">
                                    <tr>
                                       <th>Emp Id</th>
                                       <th>Designation</th>
                                       <th>Department</th>
                                       <th>Added By</th>
                                       <th>Created At</th>
                                       <th>Status</th>
                                       <th>Action</th>
                                    </tr>
                                    <tbody>
                                    <?php
                           $mysql="select * from performanceindicator";
                           $query=mysqli_query($con,$mysql);
                           while($data=mysqli_fetch_assoc($query)){
                              ?>
                                    <tr>
                                       <td><?php echo $data["EmpId"];?></td>
                                       <td> <?php echo $data["Designation"];?> </td>
                                       <td> <?php echo $data["Department"];?> </td>
                                       <td>
                                          <figure class="avatar round mr-2">
                                             <img src="assets/img/users/user-1.png" alt="...">
                                          </figure>
                                          <?php echo $data["AddedBy"];?>
                                       </td>
                                       <td> <?php echo $data["CreatedAt"];?></td>
                                       <td> <?php echo $data["Status"];?>
                                          <select class="form-select form-select-lg rounded-pill text-center  ">
                                             <option value="Active">   Active </option>
                                             <option value="Inactive">Inactive</option>
                                          </select>
                                       </td>
                                       <td><a href="#" class="btn btn-outline-primary" data-toggle="modal" data-target="#basicModal">Detail</a></td>
                                    </tr>
                                    <?php
                           }?>
                           </tbody>
                                 </table>
                              </div>
                           </div>
                           <div class="card-footer text-right">
                              <nav class="d-inline-block">
                                 <ul class="pagination mb-0">
                                    <li class="page-item disabled">
                                       <a class="page-link" href="#" tabindex="-1"><i class="fas fa-chevron-left"></i></a>
                                    </li>
                                    <li class="page-item active"><a class="page-link" href="#">1 <span
                                       class="sr-only">(current)</span></a></li>
                                    <li class="page-item">
                                       <a class="page-link" href="#">2</a>
                                    </li>
                                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                                    <li class="page-item">
                                       <a class="page-link" href="#"><i class="fas fa-chevron-right"></i></a>
                                    </li>
                                 </ul>
                              </nav>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <!------------------section2-->
               <div class="settingSidebar">
                  <a href="javascript:void(0)" class="settingPanelToggle"> <i
                     class="fa fa-spin fa-cog"></i>
                  </a>
                  <div class="settingSidebar-body ps-container ps-theme-default">
                     <div class=" fade show active">
                        <div class="setting-panel-header">Theme Customizer</div>
                        <div class="p-15 border-bottom">
                           <h6 class="font-medium m-b-10">Theme Layout</h6>
                           <div class="selectgroup layout-color w-50">
                              <label> <span class="control-label p-r-20">Light</span>
                              <input type="radio" name="custom-switch-input" value="1"
                                 class="custom-switch-input" checked> <span
                                 class="custom-switch-indicator"></span>
                              </label>
                           </div>
                           <div class="selectgroup layout-color  w-50">
                              <label> <span class="control-label p-r-20">Dark&nbsp;</span>
                              <input type="radio" name="custom-switch-input" value="2"
                                 class="custom-switch-input"> <span
                                 class="custom-switch-indicator"></span>
                              </label>
                           </div>
                        </div>
                     </div>
                     <div class="p-15 border-bottom">
                        <h6 class="font-medium m-b-10">Sidebar Colors</h6>
                        <div class="sidebar-setting-options">
                           <ul class="sidebar-color list-unstyled mb-0">
                              <li title="white" class="active">
                                 <div class="white"></div>
                              </li>
                              <li title="blue">
                                 <div class="blue"></div>
                              </li>
                              <li title="coral">
                                 <div class="coral"></div>
                              </li>
                              <li title="purple">
                                 <div class="purple"></div>
                              </li>
                              <li title="allports">
                                 <div class="allports"></div>
                              </li>
                              <li title="barossa">
                                 <div class="barossa"></div>
                              </li>
                              <li title="fancy">
                                 <div class="fancy"></div>
                              </li>
                           </ul>
                        </div>
                     </div>
                     <div class="p-15 border-bottom">
                        <h6 class="font-medium m-b-10">Theme Colors</h6>
                        <div class="theme-setting-options">
                           <ul class="choose-theme list-unstyled mb-0">
                              <li title="white" class="active">
                                 <div class="white"></div>
                              </li>
                              <li title="blue">
                                 <div class="blue"></div>
                              </li>
                              <li title="coral">
                                 <div class="coral"></div>
                              </li>
                              <li title="purple">
                                 <div class="purple"></div>
                              </li>
                              <li title="allports">
                                 <div class="allports"></div>
                              </li>
                              <li title="barossa">
                                 <div class="barossa"></div>
                              </li>
                              <li title="fancy">
                                 <div class="fancy"></div>
                              </li>
                              <li title="cyan">
                                 <div class="cyan"></div>
                              </li>
                              <li title="orange">
                                 <div class="orange"></div>
                              </li>
                              <li title="green">
                                 <div class="green"></div>
                              </li>
                              <li title="red">
                                 <div class="red"></div>
                              </li>
                           </ul>
                        </div>
                     </div>
                     <div class="p-15 border-bottom">
                        <h6 class="font-medium m-b-10">Layout Options</h6>
                        <div class="theme-setting-options">
                           <label> <span class="control-label p-r-20">Compact
                           Sidebar Menu</span> <input type="checkbox"
                              name="custom-switch-checkbox" class="custom-switch-input"
                              id="mini_sidebar_setting"> <span
                              class="custom-switch-indicator"></span>
                           </label>
                        </div>
                     </div>
                     <div class="mt-3 mb-3 align-center">
                        <a href="#"
                           class="btn btn-icon icon-left btn-outline-primary btn-restore-theme">
                        <i class="fas fa-undo"></i> Restore Default
                        </a>
                     </div>
                  </div>
               </div>
               <!----------------------main content div-->    
            </div>
            <footer class="main-footer">
               <div class="footer-left">
                  Copyright &copy; 2022 
                  <div class="bullet"></div>
                  Design By <a href="#">Snkthemes</a>
               </div>
               <div class="footer-right">
               </div>
            </footer>
         </div>
      </div>
      <!-- General JS Scripts -->
      <script src="assets/js/app.min.js"></script>
      <!-- JS Libraies -->
      <!-- Page Specific JS File -->
      <!-- Template JS File -->
      <script src="assets/js/scripts.js"></script>
   </body>
   <script>
      $("#sub2").click(function(){
       $(".eerror1").hide();
       var sn=$("#one").val();
       var dept=$("#two").val();
       var desi=$("#three").val();
       var cdate=$("#four").val();
       var add=$("#five").val();
       var Status=$("#sta2").val();
       var error=false;
       console.log("employeename"+sn);
       if(sn==""){
         $("#one").after('<span class="eerror1" style="color:red">please enter employee id</span>')
         error==true;
       }
       if(dept==""){
         $("#two").after('<span class="eerror1" style="color:red">please enter department </span>')
         error==true;
       }
       if(desi==""){
         $("#three").after('<span class="eerror1" style="color:red">please enter  date </span>')
         error==true;
       }
       if(cdate==""){
         $("#four").after('<span class="eerror1" style="color:red">please enter designation </span>')
         error==true;
       }
       if(add==""){
         $("#five").after('<span class="eerror1" style="color:red">choose image </span>')
         error==true;
       }
      
       /*16*/
       if(Status==""){
         $("#sta2").after('<span class="eerror1" style="color:red">please select Status</span>')
         error==true;
       }
      
       if(error="true"){
         return false;
       }
      });
      
      
       
       
      
      
      
   </script>
</html>