<?php
global $con;
$con=mysqli_connect("localhost","root","Lavanya@123","hrmstool");
if (mysqli_connect_errno()){
    echo "Failed to connect";
}else{
    echo "Connection Successful";
}
