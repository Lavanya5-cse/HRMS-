<?php include("connection.php");?>
<?php
 
$aname=$_POST['aname']; 
$job=$_POST['job'];
$strt=$_POST['strt'];
$expiry=$_POST['expiry']; 
$type=$_POST['type'];
 $status=$_POST['status'];
 
$mysql="Insert into jobapplicants values( '$aname','$job','$strt','$expiry','$type','$status')";
if(mysqli_query($con,$mysql))
{
    header("Location:job-dashboard.php");
    exit();
}
else{
    echo "Error";
}
mysqli_close($con);
?>