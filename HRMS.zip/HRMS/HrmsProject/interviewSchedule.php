<?php include("connection.php");?>
<?php
 $sname=$_POST['sname'];
$jobtitle=$_POST['jobtitle']; 
$date1=$_POST['date1'];
 $time1=$_POST['time1'];
 $date2=$_POST['date2'];
 $time2=$_POST['time2'];
 $date3=$_POST['date3'];
 $time3=$_POST['time3'];

 $mysql="Insert into scheduleinterview values('$sname', '$jobtitle','$date1','$time1','$date2','$time2','$date3','$time3' )";
if(mysqli_query($con,$mysql))
{
    header("Location:interview-schedule.php");
    exit();
}
else{
    echo "Error";
}
mysqli_close($con);
?>