<?php include("connection.php");?>
<?php
$goal=$_POST['goal'];
$des=$_POST['des'];
$status=$_POST['status']; 
 
 
  $mysql="Insert into  goaltype values('$goal','$des','$status' )";
if(mysqli_query($con,$mysql))
{
    header("Location:goals-type.php");
    exit();
}
else{
    echo "Error";
}
mysqli_close($con);
?>