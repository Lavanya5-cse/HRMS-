<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
      <title>Grexa - Admin Dashboard Template</title>
      <!-- General CSS Files -->
      <link rel="stylesheet" href="assets/css/app.min.css">
      <link rel="stylesheet" href="assets/bundles/jqvmap/dist/jqvmap.min.css">
      <link rel="stylesheet" href="assets/bundles/weather-icon/css/weather-icons.min.css">
      <link rel="stylesheet" href="assets/bundles/weather-icon/css/weather-icons-wind.min.css">
      <link rel="stylesheet" href="assets/bundles/bootstrap-social/bootstrap-social.css">
      <!-- Template CSS -->
      <link rel="stylesheet" href="assets/css/style.css">
      <link rel="stylesheet" href="assets/css/components.css">
      <!-- Custom style CSS -->
      <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.ico' />
   </head>
   <body>
      <div class="loader"></div>
      <div id="app">
      <div class="main-wrapper main-wrapper-1">
         <div class="navbar-bg"></div>
         <nav class="navbar navbar-expand-lg main-navbar">
            <div class="form-inline mr-auto">
               <ul class="navbar-nav mr-3">
                  <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg collapse-btn"><i
                     class="fas fa-bars"></i></a></li>
               </ul>
         </nav>
         <div class="main-sidebar sidebar-style-2">
         <aside id="sidebar-wrapper">
         <div class="sidebar-brand">
         <a href="index.html">
         <img alt="image" src="assets/img/logo.png" class="header-logo" />
         <span class="logo-name">Grexa</span>
         </a>
         </div>
         <ul class="sidebar-menu">
         <li class="menu-header">Main</li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-home"></i><span>Dashboard</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="index.php">Admin Dashboard</a></li>
         </ul>
         </li>
         <li class="dropdown active">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-leaf"></i><span>Employee
         </span></a>
         <ul class="dropdown-menu">
         <li class="active"><a class="nav-link" href="Employee dashboard.php">Employee Dashboard</a></li>
         <li><a class="nav-link" href="Add Employee.php">Add Employee</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Leaves</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Apply leave.php">Apply Leave</a></li>
         <li><a class="nav-link" href="Leave list.php">Leave List</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-anchor"></i><span> Project</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="Project lists.php">Project lists</a></li>
         <li><a class="nav-link" href="Projects_page.php">Projects</a></li>
         </ul>
         </li>
         <li class="dropdown ">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Tickets</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Tickets list.php">Tickets list</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Payroll</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Employee salary.php">Employee salary</a></li>
         <li><a class="nav-link" href="payslip.php">payslip</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Clients</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="Clients_page.php">Client form</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Leads</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Leads.php">Leads</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-hand-point-down"></i><span>Assets</span></a>
         <ul class="dropdown-menu">
         <li>  <a class="nav-link" href="Assests.php">Assets</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Performance</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="performance indicator.php">Performance Indicator</a></li>
         <li><a class="nav-link" href="performance Review.php">Performance Review</a></li>
         <li><a class="nav-link" href="performance Appraisal.php">Performance Appraisal  </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-crosshairs"></i><span>Goals</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="goals-list.php">Goal List</a></li>
         <li><a class="nav-link" href="goals-type.php">Goal type</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-pencil-alt"></i><span>Training</span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="training-list.php">Training List</a></li>
         <li><a class="nav-link" href="Trainers.php">Trainers</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-clipboard-check"></i><span>Jobs</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="job-dashboard.php">Jobs dashboard</a></li>
         <li><a class="nav-link" href="job-manage.php">ManageJobs</a></li>
         <li><a class="nav-link" href="job-resume.php">Manage Resumes</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-user-tie"></i><span>Interviews</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="interview-shortlist.php">Shortlist Candidates</a></li>
         <li><a class="nav-link" href="interview-schedule.php">Schedule time</a></li>
         <li><a class="nav-link" href="interview-offer.php">Offer  Approvals </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-file-alt"></i><span>Special Pages</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="policies.php">Policies</a></li>
         <li><a class="nav-link" href="FAQ.php">FAQ</a></li>
         <li><a class="nav-link" href="Terms of service.php">Terms Of Services</a></li>
         </ul>
         </li>
         </aside>
         </div>
         <!-- Main Content -->
         <div class="main-content">
         <section class="section">
         <div class="section-header">
         <h1>Employee Dashboard</h1>
         </div>
         <div class ="row">
         <div class="col-md-1">
         <div class="welcome-box">
         <div class="welcome-img">
         <img alt="image" class="mr-3 image-square" width="60" src="assets/img/users/user-5.png">
         </div></div></div>
         <div class="col-md-6">
         <div class="welcome-det">
         <h5 style="font-weight:bold;" >Welcome, Jenny</h5>
         <p class="text-muted">Monday, 5 November 2022</p>
         </div></div> </div>
         <div class="row">
         <div class="col-md-8 ">
         <h5>Today</h5>
         <div class="card h-90 bg-purple"> 
         <div class="card-body pt-2"> 
         <div class="row">
         <div class="col-md-1"></div>
         <div class="col-md-2">
         <i class="fas fa-hourglass-start pt-1 pr-4 " style="font-size:35px;"></i>
         </div>
         <div class="col-md-6">
         <h5 class="spa pt-3"> Richard Miles is off sick today</h5>
         </div>
         <div class="col-md-2">
         <img  class="rounded pb-3"  src="assets/img/users/user-3.png" alt="" width="50px"> 
         </div>
         </div>
         <div class="row">
         <div class="col-md-1"></div>
         <div class="col-md-2">
         <i class="far fa-calendar-minus pt-1 pr-4 " style="font-size:35px;"></i>
         </div>
         <div class="col-md-6">
         <h5 class="spa pt-3"> You are away today
         </h5>
         </div>
         <div class="col-md-2">
         <img  class="rounded pb-3"  src="assets/img/users/user-5.png" alt="" width="50px"> 
         </div>
         </div>
         <div class="row">
         <div class="col-md-1"></div>
         <div class="col-md-2">
         <i class="	far fa-calendar-alt pt-1 pr-4 " style="font-size:35px;"></i>
         </div>
         <div class="col-md-6">
         <h5 class="spa pt-3"> You are working from home today
         </h5>
         </div>
         <div class="col-md-2">
         <img  class="rounded pb-3"  src="assets/img/users/user-3.png" alt="" width="50px"> 
         </div>
         </div> 
         <div >
         </div> 
         </div>
         </div>
         </div>
         <div class="col-md-4">
         <h5>Projects</h5>
         <div class="card h-90 bg-light pt-3"> 
         <div class="card-body "> 
         <div class="row">
         <div class="col-md-2"></div>
         <div class="col-md-5">
         <h4 >71</h4><p >Total Tasks</p>
         </div>
         <div class="vr"></div>
         <div class="col-md-5">
         <h4>14</h4><p >Pending Tasks</p>
         </div>
         </div>
         <h4 class="text-center"> 2</h4><p class="text-center" >Total Projects</p>
         </div>
         </div>
         </div>
         </div>
         <div class="row">
         <div class="col-md-8 ">
         <h5  class="dash-sec-title">TOMORROW</h5>
         <div class="card pt-3 bg-purple"> 
         <div class="row">
         <div class="col-md-1"></div>
         <div class="col-md-2 ">
         <i class="far fa-calendar-minus " style="font-size:35px;"></i>
         </div>
         <div class="col-md-6">
         <h5 class="spa pt-3"> You are away today
         </h5>
         </div>
         <div class="col-md-2">
         <img  class="rounded pb-3"  src="assets/img/users/user-3.png" alt="" width="50px"> 
         </div>
         </div>
         <div >
         </div>
         </div>
         </div>
         <div class="col-md-4">
         <h5>Your leave</h5>
         <div class="card pl-3 bg-light"> 
         <div class="row">
         <div class="col-md-2"></div>
         <div class="col-md-5" >
         <h4 >4.5</h4><p >LEAVE TAKEN</p>
         </div>
         <div class="vr"></div>
         <div class="col-md-5 ">
         <h4>12</h4><p >REMAINING</p>
         </div>
         </div>
         </div>
         </div>
         </div>
         <div class="row">
         <div class="col-md-8 ">
         <h5  class="dash-sec-title">NEXT SEVEN DAYS</h5>
         <div class="card   bg-purple h-90 "> 
         <div class="card-body  pt-2"> 
         <div class="row">
         <div class="col-md-1"></div>
         <div class="col-md-2">
         <i class="fas fa-calendar-plus pt-1 pr-4 " style="font-size:35px;"></i>
         </div>
         <div class="col-md-6">
         <h5 class="spa pt-3"> 
         2 people are going to be away
         </h5>
         </div>
         <div class="col-md-2">
         <img  class="rounded pb-3"  src="assets/img/users/user-3.png" alt="" width="50px"> 
         </div>
         </div>
         <div class="row">
         <div class="col-md-1"></div>
         <div class="col-md-2">
         <i class="fas fa-user-circle pt-1 pr-4 " style="font-size:35px;"></i>
         </div>
         <div class="col-md-6">
         <h5 class="spa pt-3"> Your first day is going to be on Thursday
         </h5>
         </div>
         <div class="col-md-2">
         <img  class="rounded pb-3"  src="assets/img/users/user-5.png" alt="" width="50px"> 
         </div>
         </div>
         <div class="row">
         <div class="col-md-1"></div>
         <div class="col-md-2">
         <i class="	far fa-calendar-alt pt-1 pr-4 " style="font-size:35px;"></i>
         </div>
         <div class="col-md-6">
         <h5 class="spa pt-3">  It's a spring bank holiday
         </h5>
         </div>
         <div class="col-md-2">
         <img  class="rounded pb-3"  src="assets/img/users/user-3.png" alt="" width="50px"> 
         </div>
         </div> 
         <div >
         </div> 
         </div>
         </div>
         </div>
         <div class="col-md-4">
         <h5>YOUR TIME OFF ALLOWANCE</h5>
         <div class="card h-90 bg-light pt-3"> 
         <div class="card-body"> 
         <div class="row">
         <div class="col-md-2"></div>
         <div class="col-md-5 ">
         <h4 >5.0 Hours</h4><p >APPROVED</p>
         </div>
         <div class="vr"></div>
         <div class="col-md-5 ">
         <h4>15 Hours</h4><p >REMAINING</p>
         </div>
         </div>
         <h4 class="text-center"> 2</h4><p class="text-center" >Total Projects</p>
         </div>
         </div>  </div>
         </div>
         <div class="row">
         <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12 d-flex">
         <div class="card pb-5 bg-light">
         <div class="card-header">
         <h4>User Activity</h4>
         </div>
         <div class="card-body">
         <div class="timeline-activity">
         <div class="activity-item1">
         <div class="text-muted">01-11-2022</div>
         <p>Get instant visibility into how your team works.</p>
         </div>
         <div class="activity-item2">
         <div class="text-muted">15-03-2022</div>
         <p>Analyze how employee spend their time in working hours.</p>
         </div>
         <div class="activity-item3">
         <div class="text-muted">11-04-2022</div>
         <p>Ideal for managing remote workers with proof of work.</p>
         </div>
         <div class="activity-item4">
         <div class="text-muted">21-04-2022</div>
         <p>Helps you identify productivity issue in employees.</p>
         </div>
         </div>
         </div>
         </div>
         </div>
         <div class="col-lg-8 col-md-12 col-sm-12">
         <div class="card pb-5  bg-light">
         <div class="card-header">
         <h4>Recent Client Feedback</h4>
         </div>
         <div class="card-body ">
         <ul class="list-unstyled user-progress list-unstyled-border list-unstyled-noborder mt-2">
         <li class="media">
         <img alt="image" class="mr-3 image-square" width="50" src="assets/img/users/user-1.png">
         <div class="media-body">
         <div class="media-title">Michael Gardner</div>
         <div >
         <i class="fa fa-star" aria-hidden="true"></i>
         <i class="fa fa-star" aria-hidden="true"></i>
         <i class="fa fa-star" aria-hidden="true"></i>
         <i class="fa fa-star" aria-hidden="true"></i>
         <i class="fa fa-star-half" aria-hidden="true"></i>
         </div>
         <div class="text-muted">“You always work so passionately to make sure our customers get the best experience and insight and they
         really are reaping the rewards from your efforts!   
         .”</div>
         </div>
         <div class="media-cta">
         <div class="text-job text-muted">10-11-2012 11:50 PM</div>
         </div>
         </li>
         <li class="media">
         <img alt="image" class="mr-3 image-square" width="50" src="assets/img/users/user-5.png">
         <div class="media-body">
         <div class="media-title">Amiah Smith</div>
         <div >
         <i class="fa fa-star" aria-hidden="true"></i>
         <i class="fa fa-star" aria-hidden="true"></i>
         <i class="fa fa-star" aria-hidden="true"></i>
         <i class="fa fa-star-half" aria-hidden="true"></i>
         </div>
         <div class="text-muted">“You’ve done an incredible job taking on new responsibilities and stepping up to your new role.
         .
         .”</div>
         </div>
         <div class="media-cta">
         <div class="text-job text-muted">14-11-2022 01:50 AM</div>
         </div>
         </li>
         <li class="media">
         <img alt="image" class="mr-3 image-square" width="50" src="assets/img/users/user-4.png">
         <div class="media-body">
         <div class="media-title">John Doe</div>
         <div >
         <i class="fa fa-star" aria-hidden="true"></i>
         <i class="fa fa-star" aria-hidden="true"></i>
         <i class="fa fa-star" aria-hidden="true"></i>
         <i class="fa fa-star" aria-hidden="true"></i>
         <i class="fa fa-star-half" aria-hidden="true"></i>
         </div>
         <div class="text-muted">“Your management of the team has been unreal since taking on that responsibility.
         The team all trust and respect you, and rightly so.
         ”</div>
         </div>
         <div class="media-cta">
         <div class="text-job text-muted">03-11-2022 10:50 PM</div>
         </div>
         </li>
         </ul>
         </div>
         </div>
         </div>
         </div>
         <div class="row">
         <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">
         <div class="card bg-light">
         <div class="card-header">
         <h4>Task Issues</h4>
         </div>
         <div class="card-body">
         <div id="taskIssuesChart"></div>
         </div>
         </div>
         </div>
         <div class="col-lg-8 col-md-12 col-12 col-sm-12">
         <div class="card bg-light">
         <div class="card-header">
         <h4>Task Details</h4>
         </div>
         <div class="card-body mt-3 mb-3">
         <div class="table-responsive">
         <table class="table">
         <thead>
         <tr>
         <th>Assigned Person</th>
         <th>Task Name</th>
         <th>Progress</th>
         <th>Priority</th>
         </tr>
         </thead>
         <tr>
         <td class="media">
         <img alt="image" class="mr-3 mt-2 image-square" width="40" src="assets/img/users/user-1.png">
         <div class="media-body">
         <div class="media-tab-title">Michael Gardner</div>
         <div class="text-job text-muted">Web Developer</div>
         </div>
         </td>
         <td>Ecommerce website</td>
         <td class="align-middle">
         <div class="progress" data-height="5" data-toggle="tooltip" title="100%">
         <div class="progress-bar bg-success progress-bar-striped progress-bar-animated" data-width="100"></div>
         </div>
         </td>
         <td><div class="badge badge-flat-success badge-shadow">Low</div></td>
         </tr>
         <tr>
         <td class="media">
         <img alt="image" class="mr-3 mt-2 image-square" width="40" src="assets/img/users/user-5.png">
         <div class="media-body">
         <div class="media-tab-title">Amiah Smith</div>
         <div class="text-job text-muted">Web Developer</div>
         </div>
         </td>
         <td>Android App</td>
         <td class="align-middle">
         <div class="progress" data-height="5" data-toggle="tooltip" title="30%">
         <div class="progress-bar bg-warning progress-bar-striped progress-bar-animated" data-width="30"></div>
         </div>
         </td>
         <td><div class="badge badge-flat-warning badge-shadow">Medium</div></td>
         </tr>
         <tr>
         <td class="media">
         <img alt="image" class="mr-3 mt-2 image-square" width="40" src="assets/img/users/user-4.png">
         <div class="media-body">
         <div class="media-tab-title">John Doe</div>
         <div class="text-job text-muted">Web Developer</div>
         </div>
         </td>
         <td>Logo Design</td>
         <td class="align-middle">
         <div class="progress" data-height="5" data-toggle="tooltip" title="67%">
         <div class="progress-bar bg-danger progress-bar-striped progress-bar-animated" data-width="67"></div>
         </div>
         </td>
         <td><div class="badge badge-flat-danger badge-shadow">High</div></td>
         </tr>
         <tr>
         <td class="media">
         <img alt="image" class="mr-3 mt-2 image-square" width="40" src="assets/img/users/user-2.png">
         <div class="media-body">
         <div class="media-tab-title">Nancy Burton</div>
         <div class="text-job text-muted">Manager</div>
         </div>
         </td>
         <td>Java Project</td>
         <td class="align-middle">
         <div class="progress" data-height="5" data-toggle="tooltip" title="43%">
         <div class="progress-bar bg-success progress-bar-striped progress-bar-animated" data-width="43"></div>
         </div>
         </td>
         <td><div class="badge badge-flat-success badge-shadow">Low</div></td>
         </tr>
         <tr>
         <td class="media">
         <img alt="image" class="mr-3 mt-2 image-square" width="40" src="assets/img/users/user-3.png">
         <div class="media-body">
         <div class="media-tab-title">Wiltor Stone</div>
         <div class="text-job text-muted">Java Developer</div>
         </div>
         </td>
         <td>Android App</td>
         <td class="align-middle">
         <div class="progress" data-height="5" data-toggle="tooltip" title="30%">
         <div class="progress-bar bg-danger progress-bar-striped progress-bar-animated" data-width="30"></div>
         </div>
         </td>
         <td><div class="badge badge-flat-danger badge-shadow">High</div></td>
         </tr>
         </table>
         </div>
         </div>
         </div>
         </div>
         </div> 
         </section>
         <div class="settingSidebar">
         <a href="javascript:void(0)" class="settingPanelToggle"> <i
            class="fa fa-spin fa-cog"></i>
         </a>
         <div class="settingSidebar-body ps-container ps-theme-default">
         <div class=" fade show active">
         <div class="setting-panel-header">Theme Customizer</div>
         <div class="p-15 border-bottom">
         <h6 class="font-medium m-b-10">Theme Layout</h6>
         <div class="selectgroup layout-color w-50">
         <label> <span class="control-label p-r-20">Light</span>
         <input type="radio" name="custom-switch-input" value="1"
            class="custom-switch-input" checked> <span
            class="custom-switch-indicator"></span>
         </label>
         </div>
         <div class="selectgroup layout-color  w-50">
         <label> <span class="control-label p-r-20">Dark&nbsp;</span>
         <input type="radio" name="custom-switch-input" value="2"
            class="custom-switch-input"> <span
            class="custom-switch-indicator"></span>
         </label>
         </div>
         </div>
         </div>
         <div class="p-15 border-bottom">
         <h6 class="font-medium m-b-10">Sidebar Colors</h6>
         <div class="sidebar-setting-options">
         <ul class="sidebar-color list-unstyled mb-0">
         <li title="white" class="active">
         <div class="white"></div>
         </li>
         <li title="blue">
         <div class="blue"></div>
         </li>
         <li title="coral">
         <div class="coral"></div>
         </li>
         <li title="purple">
         <div class="purple"></div>
         </li>
         <li title="allports">
         <div class="allports"></div>
         </li>
         <li title="barossa">
         <div class="barossa"></div>
         </li>
         <li title="fancy">
         <div class="fancy"></div>
         </li>
         </ul>
         </div>
         </div>
         <div class="p-15 border-bottom">
         <h6 class="font-medium m-b-10">Theme Colors</h6>
         <div class="theme-setting-options">
         <ul class="choose-theme list-unstyled mb-0">
         <li title="white" class="active">
         <div class="white"></div>
         </li>
         <li title="blue">
         <div class="blue"></div>
         </li>
         <li title="coral">
         <div class="coral"></div>
         </li>
         <li title="purple">
         <div class="purple"></div>
         </li>
         <li title="allports">
         <div class="allports"></div>
         </li>
         <li title="barossa">
         <div class="barossa"></div>
         </li>
         <li title="fancy">
         <div class="fancy"></div>
         </li>
         <li title="cyan">
         <div class="cyan"></div>
         </li>
         <li title="orange">
         <div class="orange"></div>
         </li>
         <li title="green">
         <div class="green"></div>
         </li>
         <li title="red">
         <div class="red"></div>
         </li>
         </ul>
         </div>
         </div>
         <div class="p-15 border-bottom">
         <h6 class="font-medium m-b-10">Layout Options</h6>
         <div class="theme-setting-options">
         <label> <span class="control-label p-r-20">Compact
         Sidebar Menu</span> <input type="checkbox"
            name="custom-switch-checkbox" class="custom-switch-input"
            id="mini_sidebar_setting"> <span
            class="custom-switch-indicator"></span>
         </label>
         </div>
         </div>
         <div class="mt-3 mb-3 align-center">
         <a href="#"
            class="btn btn-icon icon-left btn-outline-primary btn-restore-theme">
         <i class="fas fa-undo"></i> Restore Default
         </a>
         </div>
         </div>
         </div>
         </div>
         <footer class="main-footer">
         <div class="footer-left">
         Copyright &copy; 2022 <div class="bullet"></div> Design By <a href="#">Snkthemes</a>
         </div>
         <div class="footer-right">
         </div>
         </footer>
         </div>
      </div>
      <!-- General JS Scripts -->
      <script src="assets/js/app.min.js"></script>
      <!-- JS Libraies -->
      <script src="assets/bundles/chartjs/chart.min.js"></script>
      <script src="assets/bundles/apexcharts/apexcharts.min.js"></script>
      <!-- Page Specific JS File -->
      <script src="assets/js/page/index2.js"></script>
      <!-- Template JS File -->
      <script src="assets/js/scripts.js"></script>
   </body>
</html>