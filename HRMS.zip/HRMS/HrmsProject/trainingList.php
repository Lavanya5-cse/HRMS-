<?php include("connection.php");?>
<?php
 
$type=$_POST['type']; 
$trainer=$_POST['trainer'];
$time=$_POST['time'];
$des=$_POST['des']; 
$cost=$_POST['cost']; 
$status=$_POST['status']; 
 
$mysql="Insert into traininglist values( '$type','$trainer','$time','$des','$cost','$status')";
if(mysqli_query($con,$mysql))
{
    header("Location: training-list.php");
    exit();
}
else{
    echo "Error";
}
mysqli_close($con);
?>