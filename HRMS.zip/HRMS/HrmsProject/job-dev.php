<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
      <title>Grexa - Admin Dashboard Template</title>
      <!-- General CSS Files -->
      <link rel="stylesheet" href="assets/css/app.min.css">
      <!-- Template CSS -->
      <link rel="stylesheet" href="assets/css/style.css">
      <link rel="stylesheet" href="assets/css/components.css">
      <!-- Custom style CSS -->
      <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.ico' />
   </head>
   <body>
      <div class="loader"></div>
      <div id="app">
         <div class="main-wrapper main-wrapper-1">
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar">
               <div class="form-inline mr-auto">
                  <ul class="navbar-nav mr-3">
                     <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg collapse-btn"><i
                        class="fas fa-bars"></i></a></li>
                     <li>
                     </li>
                  </ul>
               </div>
               <ul class="navbar-nav navbar-right">
               </ul>
            </nav>
            <div class="main-sidebar sidebar-style-2">
               <aside id="sidebar-wrapper">
                  <div class="sidebar-brand">
                     <a href="index.html">
                     <img alt="image" src="assets/img/logo.png" class="header-logo" />
                     <span class="logo-name">Grexa</span>
                     </a>
                  </div>
                  <ul class="sidebar-menu">
                  <li class="menu-header">Main</li>
                  <li class="dropdown">
                     <a href="#" class="nav-link has-dropdown"><i class="fas fa-home"></i><span>Dashboard</span></a>
                     <ul class="dropdown-menu">
                        <li><a class="nav-link" href="index.php">Admin Dashboard</a></li>
                     </ul>
                  </li>
                  <li class="dropdown">
            <a href="#" class="nav-link has-dropdown"><i class="fas fa-home"></i><span>Dashboard</span></a>
            <ul class="dropdown-menu">
            <li><a class="nav-link" href="index.php">Admin Dashboard</a></li>
            </ul>
            </li>
            <li class="dropdown ">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-leaf"></i><span>Employee
         </span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="Employee dashboard.php">Employee Dashboard</a></li>
         <li><a class="nav-link" href="Add Employee.php">Add Employee</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Leaves</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Apply leave.php">Apply Leave</a></li>
         <li><a class="nav-link" href="Leave list.php">Leave List</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-anchor"></i><span> Project</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="Project lists.php">Project lists</a></li>
         <li><a class="nav-link" href="Projects_page.php">Projects</a></li>
         </ul>
         </li>
         <li class="dropdown ">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Tickets</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Tickets list.php">Tickets list</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Payroll</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Employee salary.php">Employee salary</a></li>
         <li><a class="nav-link" href="payslip.php">payslip</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Clients</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link " href="Clients_page.php">Client form</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Leads</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Leads.php">Leads</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-hand-point-down"></i><span>Assets</span></a>
         <ul class="dropdown-menu">
         <li>  <a class="nav-link" href="Assests.php">Assets</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Performance</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="performance indicator.php">Performance Indicator</a></li>
         <li><a class="nav-link" href="performance Review.php">Performance Review</a></li>
         <li><a class="nav-link" href="performance Appraisal.php">Performance Appraisal  </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-crosshairs"></i><span>Goals</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="goals-list.php">Goal List</a></li>
         <li><a class="nav-link" href="goals-type.php">Goal type</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-pencil-alt"></i><span>Training</span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="training-list.php">Training List</a></li>
         <li><a class="nav-link" href="Trainers.php">Trainers</a></li>
         </ul>
         </li>
                  <li class="dropdown active">
                     <a href="#" class="nav-link has-dropdown"><i class="fas fa-clipboard-check"></i><span>Jobs</span></a>
                     <ul class="dropdown-menu">
                        <li><a class="nav-link" href="job-dashboard.php">Jobs dashboard</a></li>
                        <li class="active"><a class="nav-link" href="job-manage.php">ManageJobs</a></li>
                        <li><a class="nav-link" href="job-resume.php">Manage Resumes</a></li>
                     </ul>
                  </li>
                  <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-user-tie"></i><span>Interviews</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="interview-shortlist.php">Shortlist Candidates</a></li>
         <li><a class="nav-link" href="interview-schedule.php">Schedule time</a></li>
         <li><a class="nav-link" href="interview-offer.php">Offer  Approvals </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-file-alt"></i><span>Special Pages</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="policies.php">Policies</a></li>
         <li><a class="nav-link" href="FAQ.php">FAQ</a></li>
         <li><a class="nav-link" href="Terms of service.php">Terms Of Services</a></li>
         </ul>
         </li>
               </aside>
            </div>
            <!-- Main Content -->
            <div class="main-content">
               <section class="section">
                  <div class="section-header">
                     <h1>Jobs Details</h1>
                     <div class="section-header-breadcrumb">
                        <div class="breadcrumb-item"><a href="index.html">Dashboard</a></div>
                        <div class="breadcrumb-item">Jobs Details</div>
                     </div>
                  </div>
               </section>
               <div class="row">
                  <div class="col-md-8">
                     <div  class="card pt-3 pl-5">
                        <h3  class="job-title ">Web Developer</h3>
                        <span   class="text-muted pb-3">Web Development</span>
                        <div   class="row  ">
                           <div class="col-md-4 pb-3">
                              <div  ><i   class="fa fa-calendar" style="font-size:20px;">
                                 </i> Post Date: <span   class="text-blue">Aug 18, 2022</span>
                              </div>
                           </div>
                           <div class="col-md-4 pb-3"> 
                              <i   class="fa fa-calendar" style="font-size:20px;"></i> Last Date:
                              <span   class="text-blue">Oct 31, 2022</span>
                           </div>
                           <div class="col-md-4 pb-3">
                              <i   class="fa fa-user" style="font-size:20px;"></i> Applicants: 
                              <span class="text-blue">4</span>
                           </div>
                        </div>
                     </div>
                     <div class="card p-5">
                        <h4>Job Description</h4>
                        <p>Our firm is seeking a creative Web Developer that can work with our software application team to achieve our business’ digital goals. The ideal candidate for this position is a hands-on professional with strong knowledge of content management platforms, and an ability to translate our business needs into client-friendly functions that will expand our website’s influence in our industry. The Web Developer will be responsible for updating our current online applications, as well as developing and implementing a usability testing process to insure that new website applications meet our company’s requirements.</p>
                        <h4>Responsibilities</h4>
                        <ul>
                           <li>Create applications that address the phases of SDLC (software development life cycle)</li>
                           <li>Develop comprehensive application testing procedures</li>
                           <li>Update existing applications to meet the security and functionality standards as outlined in the company’s website policies</li>
                           <li>Implement testing tools that monitor the ongoing performance of the company website</li>
                        </ul>
                        <h4>Requirements and skills</h4>
                        <ul>
                           <li>Bachelor’s Degree in Computer Science or related field (Master’s preferred)</li>
                           <li>2+ years’ experience in application development and testing</li>
                           <li>1+ years’ SDLC implementation experience</li>
                           <li>Ability to create support documentation for all new applications</li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-md-4">
                     <div  class="card pt-5 pl-5 pr-5 pb-5">
                        <button data-toggle="modal" data-target="#edit_job" class="btn" style="background-color:grey;font-size:15px;">Edit</button>
                        <div class="modal fade" id="edit_job" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                           <div class="modal-dialog" role="document">
                              <div class="modal-content">
                                 <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Edit Job</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                 </div>
                                 <div class="modal-body">
                                    <div class="card-body">
                                       <form action="jobDev.php" method="post">
                                          <div class="row" style="margin-bottom:30px;">
                                             <div class="col-md-8">
                                                <div> <label class=" form-label"> Job Type</label></div>
                                                <select class="form-select form-select-lg" style="width:200px;height:40px;" name="type">
                                                   <option></option>
                                                   <option value="Full Time">Full Time</option>
                                                   <option value="Part Time">Part Time</option>
                                                   <option value="Temporary">Temporary</option>
                                                   <option value="Remote">Remote</option>
                                                   <option value="Internship">Internship</option>
                                                   <option value="Others">Others</option>
                                                </select>
                                             </div>
                                          </div>
                                          <div class="row" style="margin-bottom:30px;">
                                             <div class="col-md-6">
                                                <label class=" form-label">Salary</label>
                                                <input type="number" class="form-control" name="salary" required>
                                             </div>
                                             <div class="col-md-6">
                                                <label class=" form-label">Experience</label>
                                                <input type="text" class="form-control"  name="experience" required>
                                             </div>
                                          </div>
                                          <div class="row" style="margin-bottom:30px;">
                                             <div class="col-md-6">
                                                <label class=" form-label">Vacancy</label>
                                                <input type="number" class="form-control" name="vacancy" required>
                                             </div>
                                             <div class="col-md-6">
                                                <label class="form-label">Location</label>
                                                <input type="text" class="form-control" name="loc" required>
                                             </div>
                                          </div>
                                          <div class="row">
                                             <div class="col-md-4"></div>
                                             <div class="col-md-6">
                                                <button class="btn btn-primary rounded-pill pr-3 pt-2 pl-3 text-center" >Save</button>
                                             </div>
                                          </div>
                                       </form>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div  class="info-list pt-3">
                           <div class="row">
                              <div class="col-md-1 pt-1">
                                 <span>
                                 <i  class="fas fa-bars" style="font-size:20px;color:blue;"></i>
                                 </span>
                              </div>
                              <div class="col-md-6">
                                 <h5>Job Type</h5>
                                 <p> Full Time</p>
                              </div>
                           </div>
                        </div>
                        <div  class="info-list pt-3">
                           <div class="row">
                              <div class="col-md-1 pt-1">
                                 <span>
                                 <i  class="fas fa-money-bill" style="font-size:20px;color:blue;"></i>
                                 </span>
                              </div>
                              <div class="col-md-6">
                                 <h5>Salary</h5>
                                 <p>$32k - $38k</p>
                              </div>
                           </div>
                        </div>
                        <div  class="info-list pt-3">
                           <div class="row">
                              <div class="col-md-1 pt-1">
                                 <span>
                                 <i  class="fas fa-suitcase" style="font-size:20px;color:blue;"></i>
                                 </span>
                              </div>
                              <div class="col-md-7">
                                 <h5>Experience</h5>
                                 <p>2 Years</p>
                              </div>
                           </div>
                        </div>
                        <div  class="info-list pt-3">
                           <div class="row">
                              <div class="col-md-1 pt-1">
                                 <span>
                                 <i  class="fas fa-ticket-alt" style="font-size:20px;color:blue;"></i>
                                 </span>
                              </div>
                              <div class="col-md-6">
                                 <h5>Vacancy</h5>
                                 <p>5</p>
                              </div>
                           </div>
                        </div>
                        <div  class="info-list pt-3">
                           <div class="row">
                              <div class="col-md-1 pt-1">
                                 <span>
                                 <i  class="
                                    far fa-map" style="font-size:20px;color:blue;"></i>
                                 </span>
                              </div>
                              <div class="col-md-6">
                                 <h5>Location</h5>
                                 <p> Dreamguy's Technologies 
                                    <br> 3864 Quiet Valley Lane, <br> Sherman Oaks, <br> California, 91403
                                 </p>
                              </div>
                           </div>
                        </div>
                        <div  class="info-list pt-3">
                           <div class="row">
                              <div class="col-md-1 pt-1">
                              </div>
                              <div class="col-md-6">
                                 <p  class="text-truncate"> 818-978-7102 <br>
                                    <a href="mailto:danielporter@example.com" title="danielporter@example.com">danielporter@example.com</a>
                                    <br><a  href="https://www.example.com" target="_blank" title="https://www.example.com">
                                    https://www.example.com</a>
                                 </p>
                              </div>
                           </div>
                        </div>
                        <div   class="info-list text-center">
                           <a  class="app-ends text-success">Application ends in 2d 7h 6m</a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="settingSidebar">
               <a href="javascript:void(0)" class="settingPanelToggle"> <i
                  class="fa fa-spin fa-cog"></i>
               </a>
               <div class="settingSidebar-body ps-container ps-theme-default">
                  <div class=" fade show active">
                     <div class="setting-panel-header">Theme Customizer</div>
                     <div class="p-15 border-bottom">
                        <h6 class="font-medium m-b-10">Theme Layout</h6>
                        <div class="selectgroup layout-color w-50">
                           <label> <span class="control-label p-r-20">Light</span>
                           <input type="radio" name="custom-switch-input" value="1"
                              class="custom-switch-input" checked> <span
                              class="custom-switch-indicator"></span>
                           </label>
                        </div>
                        <div class="selectgroup layout-color  w-50">
                           <label> <span class="control-label p-r-20">Dark&nbsp;</span>
                           <input type="radio" name="custom-switch-input" value="2"
                              class="custom-switch-input"> <span
                              class="custom-switch-indicator"></span>
                           </label>
                        </div>
                     </div>
                  </div>
                  <div class="p-15 border-bottom">
                     <h6 class="font-medium m-b-10">Sidebar Colors</h6>
                     <div class="sidebar-setting-options">
                        <ul class="sidebar-color list-unstyled mb-0">
                           <li title="white" class="active">
                              <div class="white"></div>
                           </li>
                           <li title="blue">
                              <div class="blue"></div>
                           </li>
                           <li title="coral">
                              <div class="coral"></div>
                           </li>
                           <li title="purple">
                              <div class="purple"></div>
                           </li>
                           <li title="allports">
                              <div class="allports"></div>
                           </li>
                           <li title="barossa">
                              <div class="barossa"></div>
                           </li>
                           <li title="fancy">
                              <div class="fancy"></div>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="p-15 border-bottom">
                     <h6 class="font-medium m-b-10">Theme Colors</h6>
                     <div class="theme-setting-options">
                        <ul class="choose-theme list-unstyled mb-0">
                           <li title="white" class="active">
                              <div class="white"></div>
                           </li>
                           <li title="blue">
                              <div class="blue"></div>
                           </li>
                           <li title="coral">
                              <div class="coral"></div>
                           </li>
                           <li title="purple">
                              <div class="purple"></div>
                           </li>
                           <li title="allports">
                              <div class="allports"></div>
                           </li>
                           <li title="barossa">
                              <div class="barossa"></div>
                           </li>
                           <li title="fancy">
                              <div class="fancy"></div>
                           </li>
                           <li title="cyan">
                              <div class="cyan"></div>
                           </li>
                           <li title="orange">
                              <div class="orange"></div>
                           </li>
                           <li title="green">
                              <div class="green"></div>
                           </li>
                           <li title="red">
                              <div class="red"></div>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="p-15 border-bottom">
                     <h6 class="font-medium m-b-10">Layout Options</h6>
                     <div class="theme-setting-options">
                        <label> <span class="control-label p-r-20">Compact
                        Sidebar Menu</span> <input type="checkbox"
                           name="custom-switch-checkbox" class="custom-switch-input"
                           id="mini_sidebar_setting"> <span
                           class="custom-switch-indicator"></span>
                        </label>
                     </div>
                  </div>
                  <div class="mt-3 mb-3 align-center">
                     <a href="#"
                        class="btn btn-icon icon-left btn-outline-primary btn-restore-theme">
                     <i class="fas fa-undo"></i> Restore Default
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <footer class="main-footer">
            <div class="footer-left">
               Copyright &copy; 2022
               <div class="bullet"></div>
               Design By <a href="#">Snkthemes</a>
            </div>
            <div class="footer-right"></div>
         </footer>
      </div>
      </div>
      <!-- General JS Scripts -->
      <script src="assets/js/app.min.js"></script>
      <!-- JS Libraies -->
      <!-- Page Specific JS File -->
      <!-- Template JS File -->
      <script src="assets/js/scripts.js"></script>
   </body>
   <script>
      $("#formvalidate").click(function()
      {
      $(".error").hide();
       
       var vac1=$("#vac").val();
      var exp1=$("#exp").val();
       var loc=$("#location").val();
          var sel3=$("#dropdown3").val();
       var from1=$("#from").val();
      var error=false;
       
      if(vac1=='')
      {
      $("#vac").after('<div class="error" style="color:red">Please enter no of vacancies</div>')
      error=true;
      }
       
      if(sel3=='')
      {
        $("#dropdown3").after('<div class="error" style="color:red;">Please enter Job Type</div>')
        error=true;
      
      }
      if(exp1=='')
      {
      $("#exp").after('<div class="error" style="color:red">Please enter experience years</div>')
      error=true;
      } 
       if(loc=='')
      {
      $("#location").after('<div class="error" style="color:red">Please enter Job Location</div>')
      error=true;
      }
      if(from1=='')
      {
      $("#from").after('<div class="error" style="color:red">Please enter salary</div>')
      error=true;
      }
      if(error==true)
      {
          return false;
      }
      });
       
          
   </script>
</html>