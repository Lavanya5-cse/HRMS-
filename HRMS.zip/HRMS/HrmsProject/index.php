<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
      <title>Grexa - Admin Dashboard Template</title>
      <!-- General CSS Files -->
      <link rel="stylesheet" href="assets/css/app.min.css">
      <!-- Template CSS -->
      <link rel="stylesheet" href="assets/css/style.css">
      <link rel="stylesheet" href="assets/css/components.css">
      <link rel="stylesheet" href="assets/bundles/bootstrap-social/bootstrap-social.css">
      <link rel="stylesheet" href="assets/bundles/flag-icon-css/css/flag-icon.min.css">
      <!-- Custom style CSS -->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.ico' />
   </head>
   <body>
      <div class="loader"></div>
      <div id="app">
      <div class="main-wrapper main-wrapper-1">
         <div class="navbar-bg"></div>
         <nav class="navbar navbar-expand-lg main-navbar">
            <div class="form-inline mr-auto">
               <ul class="navbar-nav mr-3">
                  <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg collapse-btn"><i
                     class="fas fa-bars"></i></a></li>
               </ul>
         </nav>
         <div class="main-sidebar sidebar-style-2">
         <aside id="sidebar-wrapper">
         <div class="sidebar-brand">
         <a href="index.html">
         <img alt="image" src="assets/img/logo.png" class="header-logo" />
         <span class="logo-name">Grexa</span>
         </a>
         </div>
         <ul class="sidebar-menu">
         <li class="menu-header">Main</li>
         <li class="dropdown active">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-home"></i><span>Dashboard</span></a>
         <ul class="dropdown-menu">
         <li class="active"><a class="nav-link" href="index.php">Admin Dashboard</a></li>
         </ul>
         </li>
         <li class="dropdown ">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-leaf"></i><span>Employee
         </span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="Employee dashboard.php">Employee Dashboard</a></li>
         <li><a class="nav-link" href="Add Employee.php">Add Employee</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Leaves</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Apply leave.php">Apply Leave</a></li>
         <li><a class="nav-link" href="Leave list.php">Leave List</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-anchor"></i><span> Project</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link active" href="Project lists.php">Project lists</a></li>
         <li><a class="nav-link" href="Projects_page.php">Projects</a></li>
         </ul>
         </li>
         <li class="dropdown ">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Tickets</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Tickets list.php">Tickets list</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-wpforms"></i><span>Payroll</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Employee salary.php">Employee salary</a></li>
         <li><a class="nav-link" href="payslip.php">payslip</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-chart-bar"></i><span>Clients</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link " href="Clients_page.php">Client form</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Leads</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="Leads.php">Leads</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-hand-point-down"></i><span>Assets</span></a>
         <ul class="dropdown-menu">
         <li>  <a class="nav-link" href="Assests.php">Assets</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fab fa-airbnb"></i><span>Performance</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="performance indicator.php">Performance Indicator</a></li>
         <li><a class="nav-link" href="performance Review.php">Performance Review</a></li>
         <li><a class="nav-link" href="performance Appraisal.php">Performance Appraisal  </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-crosshairs"></i><span>Goals</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="goals-list.php">Goal List</a></li>
         <li><a class="nav-link" href="goals-type.php">Goal type</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-pencil-alt"></i><span>Training</span></a>
         <ul class="dropdown-menu">
         <li class=""><a class="nav-link" href="training-list.php">Training List</a></li>
         <li><a class="nav-link" href="Trainers.php">Trainers</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-clipboard-check"></i><span>Jobs</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="job-dashboard.php">Jobs dashboard</a></li>
         <li><a class="nav-link" href="job-manage.php">ManageJobs</a></li>
         <li><a class="nav-link" href="job-resume.php">Manage Resumes</a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="fas fa-user-tie"></i><span>Interviews</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link " href="interview-shortlist.php">Shortlist Candidates</a></li>
         <li><a class="nav-link" href="interview-schedule.php">Schedule time</a></li>
         <li><a class="nav-link" href="interview-offer.php">Offer  Approvals </a></li>
         </ul>
         </li>
         <li class="dropdown">
         <a href="#" class="nav-link has-dropdown"><i class="far fa-file-alt"></i><span>Special Pages</span></a>
         <ul class="dropdown-menu">
         <li><a class="nav-link" href="policies.php">Policies</a></li>
         <li><a class="nav-link" href="FAQ.php">FAQ</a></li>
         <li><a class="nav-link" href="Terms of service.php">Terms Of Services</a></li>
         </ul>
         </li>
         </aside>
         </div>
         <!-- Main Content -->
         <div class="main-content">
         <section class="section">
         <div class="section-header">
         <h1 style="color:blueviolet;">Welcome Admin!</h1>
         </div>
         <div class="row">
         <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
         <div class="card text-center bg-light"  >
         <div class="card-body">
         <h5 class="card-title"><i class="fa fa-users fa-2x" aria-hidden="true"  style="color:blue" ></i></h5>
         <h5 class="card-subtitle mb-2 text-muted">Total Employees</h5>
         <h4 class="card-text">6,578</h4>
         </div>
         </div>
         </div>
         <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
         <div class="card text-center bg-light"  >
         <div class="card-body">
         <h5 class="card-title"><i class="fas fa-clipboard-check" aria-hidden="true"  style="color:blue;font-size:40px"></i></h5>
         <h5 class="card-subtitle mb-2 text-muted"> Departments</h5>
         <h4 class="card-text">20</h4>
         </div>
         </div>
         </div>
         <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
         <div class="card text-center bg-light"  >
         <div class="card-body">
         <h5 class="card-title"><i class="fa fa-cubes fa-2x" aria-hidden="true"  style="color:blue; "></i></h5>
         <h5 class="card-subtitle mb-2 text-muted"> Total Tasks</h5>
         <h4 class="card-text">150</h4>
         </div>
         </div>
         </div>
         <div class="col-md-6 col-sm-6 col-lg-6 col-xl-3">
         <div class="card text-center bg-light"  >
         <div class="card-body">
         <h5 class="card-title"><i class="fas fa-dollar-sign" aria-hidden="true"  style="color:blue;font-size:40px; "></i></h5>
         <h5 class="card-subtitle mb-2 text-muted">  clients</h5>
         <h4 class="card-text">70</h4>
         </div>
         </div>
         </div>
         </div>
         <div class="row">
         <div class="col-md-4 d-flex">
         <div class="card bg-light flex-fill">
         <div class="card-header">
         <h4> Statistics</h4>
         </div>
         <div class="card-body card-type-4">
         <div class="row">
         <div class="col">
         <div class="text-small float-right font-weight-bold text-muted"><span class="text-success">5</span></div>
         <div class="font-weight-bold">Today Leave</div>
         <div class="progress" data-height="5">
         <div class="progress-bar l-bg-green" role="progressbar" data-width="80%" aria-valuenow="80"
            aria-valuemin="0" aria-valuemax="100"></div>
         </div>
         <div class="text-small float-right font-weight-bold text-muted">9,917</div>
         </div>
         </div>
         <div class="row pt-3 pb-3">
         <div class="col">
         <div class="text-small float-right font-weight-bold text-muted"><span class="text-danger"> 100</span></div>
         <div class="font-weight-bold">Pending Invoice</div>
         <div class="progress" data-height="5">
         <div class="progress-bar l-bg-cyan" role="progressbar" data-width="37%" aria-valuenow="25"
            aria-valuemin="0" aria-valuemax="100"></div>
         </div>
         <div class="text-small float-right font-weight-bold text-muted">1,053</div>
         </div>
         </div>
         <div class="row pt-3 pb-3">
         <div class="col">
         <div class="text-small float-right font-weight-bold text-muted"><span class="text-success">90</span></div>
         <div class="font-weight-bold">Completed Projects</div>
         <div class="progress" data-height="5">
         <div class="progress-bar l-bg-orange" role="progressbar" data-width="58%" aria-valuenow="25"
            aria-valuemin="0" aria-valuemax="100"></div>
         </div>
         <div class="text-small float-right font-weight-bold text-muted">150</div>
         </div>
         </div>
         <div class="row pt-3 pb-3">
         <div class="col">
         <div class="text-small float-right font-weight-bold text-muted"><span class="text-success"> 10</span></div>
         <div class="font-weight-bold">Open Tickets</div>
         <div class="progress" data-height="5">
         <div class="progress-bar l-bg-purple" role="progressbar" data-width="48%" aria-valuenow="25"
            aria-valuemin="0" aria-valuemax="100"></div>
         </div>
         <div class="text-small float-right font-weight-bold text-muted">55</div>
         </div>
         </div>
         <div class="row pt-3 pb-3">
         <div class="col">
         <div class="text-small float-right font-weight-bold text-muted"><span class="text-info"> 30</span></div>
         <div class="font-weight-bold">closed Tickets</div>
         <div class="progress" data-height="5">
         <div class="progress-bar l-bg-yellow" role="progressbar" data-width="87%" aria-valuenow="25"
            aria-valuemin="0" aria-valuemax="100"></div>
         </div>
         <div class="text-small float-right font-weight-bold text-muted">40</div>
         </div>
         </div>
         </div>
         </div>
         </div>
         <div  class="col-md-4 col-lg-6 col-xl-4 d-flex">
         <div  class="card flex-fill bg-light">
         <div class="card-header">
         <h4  class="card-title">Task Statistics</h4>
         </div>
         <div   class="card-body">
         <div   class="statistics">
         <div   class="row">
         <div   class="col-md-6 col-6 text-center">
         <div   class="stats-box mb-4 l-bg-cyan">
         <p>Total Tasks</p>
         <h3  >235</h3>
         </div></div>
         <div   class="col-md-6 col-6 text-center">
         <div   class="stats-box mb-4 l-bg-cyan">
         <p  >Overdue Tasks</p>
         <h3  >69</h3>
         </div></div></div></div>
         <div   class="progress mb-4"><div   role="progressbar" aria-valuenow="30" aria-valuemin="0" 
            aria-valuemax="100" class="progress-bar bg-purple" style="width: 30%;">30%</div>
         <div   role="progressbar" aria-valuenow="18" aria-valuemin="0" aria-valuemax="100" class="progress-bar bg-warning" 
            style="width: 22%;">22%</div>
         <div   role="progressbar" aria-valuenow="12" aria-valuemin="0" aria-valuemax="100" class="progress-bar bg-success" 
            style="width: 24%;">24%</div>
         <div  role="progressbar" aria-valuenow="14" aria-valuemin="0" aria-valuemax="100"
            class="progress-bar bg-danger" style="width: 26%;">21%</div>
         <div   role="progressbar" aria-valuenow="14" aria-valuemin="0" aria-valuemax="100" class="progress-bar bg-info" 
            style="width: 10%;">10%</div>
         </div><div>
         <p> <i class="fa fa-dot-circle-o text-purple me-2" style="margin-right:10px"></i>Completed Tasks:<span   class="float-end">156</span></p>
         <p> <i  class="fa fa-dot-circle-o text-warning me-2" style="margin-right:10px"></i> Inprogress Tasks :<span  class="float-end">105</span></p>
         <p><i  class="fa fa-dot-circle-o text-success me-2" style="margin-right:10px"></i> On Hold Tasks :<span  class="float-end">23</span></p>
         <p><i class="fa fa-dot-circle-o text-danger me-2" style="margin-right:10px"></i>Pending Tasks:<span class="float-end">57</span></p>
         <p class="mb-0"> <i  class="fa fa-dot-circle-o text-info me-2" style="margin-right:10px"></i>Review Tasks 
         <span  class="float-end">16</span></p>
         </div></div></div></div>
         <div  class="col-md-4 col-lg-6 col-xl-4 d-flex ">
         <div  class="card flex-fill bg-light">
         <div class="card-header">
         <h4  class="card-title">Notice Board</h4>
         </div>
         <div   class="card-body">
         <div class="pt-2">
         <div class="list-group">
         <div class="list-group-item d-flex pt-3 pb-3 border-0">
         <div class="me-3 me-xs-0">
         <div class="calendar-icon icons">
         <div class="badge badge-info" style="margin-right:10px;"> <span class=" ">12</span> <span class="month">NOV</span> </div>
         </div>
         </div>
         <div class="ms-1">
         <div class="font-weight-bold">Board meeting Completed</div> <small class="text-muted">Attend with team leads</small>
         </div>
         </div>
         <div class="list-group-item d-flex pt-3 pb-3 border-0">
         <div class="me-3 me-xs-0">
         <div class="calendar-icon icons">
         <div class="badge badge-dark" style="margin-right:10px;"> <span class="date">23</span> <span class="month">NOV</span> </div>
         </div>
         </div>
         <div class="ms-1">
         <div class="font-weight-bold">Updated the Company Policy</div>
         <small class="text-muted">some changes &amp; add the  terms &amp; conditions </small>
         </div>
         </div>
         <div class="list-group-item d-flex pt-3 pb-3 border-0">
         <div class="me-3 me-xs-0">
         <div class="calendar-icon icons">
         <div class="badge badge-success " style="margin-right:10px;"> <span class="date">28</span> <span class="month">NOV</span> </div>
         </div>
         </div>
         <div class="ms-1">
         <div class="font-weight-bold">Office Timings Changed</div> <small class="text-muted">  changing  after December 01st 9:30 Am To 7:00 Pm</small>
         </div>
         </div>
         <div class="list-group-item d-flex pt-3 pb-5 border-0">
         <div class="me-3 me-xs-0">
         <div class="calendar-icon icons">
         <div class="badge badge-light " style="margin-right:10px;"> <span class="date">25</span> <span class="month">DEC</span> </div>
         </div>
         </div>
         <div class="ms-1">
         <div class="font-weight-bold">  Christmas Celebrated </div> <small class="text-muted">participate the all employess </small>
         </div>
         </div>
         </div>
         </div>
         </div></div>
         </div>
         </div>
         <div class="row">
         <div class="col-lg-7 col-md-12 col-sm-12 d-flex">
         <div class="card">
         <div class="card-header">
         <h4>Recent Project in Queue</h4>
         </div>
         <div class="card-body">
         <div class="table-responsive table-invoice">
         <table class="table table-striped">
         <tr>
         <th>Project Name</th>
         <th>Client</th>
         <th>Conversion Start Date</th>
         <th>Status</th>
         <th>Action</th>
         </tr>
         <tr>
         <td>Office Management</td>
         <td class="font-weight-600">Amiah Smith</td>
         <td>April 30, 2022</td>
         <td>
         <div class="badge badge-danger">cancelled</div>
         </td>
         <td>
         <div class="media-cta-square">
         <a href="#" class="btn btn-outline-primary">Detail</a>
         </div>
         </td>
         </tr>
         <tr>
         <td>Video Calling App</td>
         <td class="font-weight-600">Dorothy Hike</td>
         <td>March 18, 2022</td>
         <td>
         <div class="badge badge-info">Pending</div>
         </td>
         <td>
         <div class="media-cta-square">
         <a href="#" class="btn btn-outline-primary">Detail</a>
         </div>
         </td>
         </tr>
         <tr>
         <td>Project Management</td>
         <td class="font-weight-600">Nancy Burton</td>
         <td>November 01, 2022</td>
         <td>
         <div class="badge badge-success">Completed</div>
         </td>
         <td>
         <div class="media-cta-square">
         <a href="#" class="btn btn-outline-primary">Detail</a>
         </div>
         </td>
         </tr>
         <tr>
         <td>Hospital Administration</td>
         <td class="font-weight-600">Jessica Hill</td>
         <td>May 25, 2022</td>
         <td>
         <div class="badge badge-warning">In Progress</div>
         </td>
         <td>
         <div class="media-cta-square">
         <a href="#" class="btn btn-outline-primary">Detail</a>
         </div>
         </td>
         </tr>                    
         <tr>
         <td>Digital Marketplace</td>
         <td class="font-weight-600">Michael Gardner</td>
         <td>February 05, 2022</td>
         <td>
         <div class="badge badge-danger">cancelled</div>
         </td>
         <td>
         <div class="media-cta-square">
         <a href="#" class="btn btn-outline-primary">Detail</a>
         </div>
         </td>
         </tr>
         <tr>
         <td>Project Management</td>
         <td class="font-weight-600">Wiltor Stone</td>
         <td>February 29, 2022</td>
         <td>
         <div class="badge badge-success">Completed</div>
         </td>
         <td>
         <div class="media-cta-square">
         <a href="#" class="btn btn-outline-primary">Detail</a>
         </div>
         </td>
         </tr>
         <tr>
         <td>Office Management</td>
         <td class="font-weight-600">Emily Johnson</td>
         <td>March 25, 2022</td>
         <td>
         <div class="badge badge-info">Pending</div>
         </td>
         <td>
         <div class="media-cta-square">
         <a href="#" class="btn btn-outline-primary">Detail</a>
         </div>
         </td>
         </tr>
         </table>
         </div>
         </div>
         </div>
         </div>
         <div class="col-lg-5 col-md-12 col-sm-12 d-flex">
         <div class="card bg-light">
         <div class="card-header">
         <h4>Inbox</h4>
         </div>
         <div class="card-body mt-2">
         <ul class="list-unstyled user-progress list-unstyled-border list-unstyled-noborder mt-2">
         <li class="media">
         <img alt="image" class="mr-3 rounded-circle" width="50" src="assets/img/users/user-5.png">
         <div class="media-body">
         <div class="media-title">Amiah Smith</div>
         <div class="text-muted">I just finished my work.Let me know...</div>
         </div>
         <div class="media-cta">
         <div class="text-job text-muted">09:30 PM</div>
         </div>
         </li>
         <li class="media">
         <img alt="image" class="mr-3 rounded-circle" width="50" src="assets/img/users/user-4.png">
         <div class="media-body">
         <div class="media-title">John Doe</div>
         <div class="text-muted">Your password will be expired...</div>
         </div>
         <div class="media-cta">
         <div class="text-job text-muted">10:01 PM</div>
         </div>
         </li>
         <li class="media">
         <img alt="image" class="mr-3 rounded-circle" width="50" src="assets/img/users/user-1.png">
         <div class="media-body">
         <div class="media-title">Michael Gardner</div>
         <div class="text-muted">We are introducing new features...</div>
         </div>
         <div class="media-cta">
         <div class="text-job text-muted">11:50 PM</div>
         </div>
         </li>
         <li class="media">
         <img alt="image" class="mr-3 rounded-circle" width="50" src="assets/img/users/user-3.png">
         <div class="media-body">
         <div class="media-title">Wiltor Stone</div>
         <div class="text-muted">We will solve your issue soon...</div>
         </div>
         <div class="media-cta">
         <div class="text-job text-muted">01:15 AM</div>
         </div>
         </li>
         <li class="media">
         <img alt="image" class="mr-3 rounded-circle" width="50" src="assets/img/users/user-2.png">
         <div class="media-body">
         <div class="media-title">Nancy Burton</div>
         <div class="text-muted">please find attached My email copy...</div>
         </div>
         <div class="media-cta">
         <div class="text-job text-muted">08:11 AM</div>
         </div>
         </li>
         </ul>
         </div>
         </div>
         </div>
         </div>
         <div class="row">
         <div class=" col-lg-5 col-md-12 col-sm-12 d-flex">
         <div class="card author-box bg-light">
         <div class="card-header">
         <h4>Social Source</h4>
         </div>
         <div class="card-body">
         <div class="author-box-center">
         <img alt="image" src="assets/img/logo.png" class="author-box-picture">
         <div class="clearfix"></div>
         <div class="author-box-name">
         <a href="#">Grexa</a>
         </div>
         <div class="author-box-job">Total - 1076 Sales</div>
         </div>
         <div class="text-center">
         <div class="author-box-description">
         <p>
         CSR is a business model that helps a company remain socially accountable to itself, its community, and its stakeholders. 
         </p>
         </div>
         <div class="mb-2 mt-3">
         <div class="text-small font-weight-bold">Follow Grexa On</div>
         </div>
         <a href="#" class="btn btn-social-icon mr-1 btn-facebook" data-toggle="tooltip" title="" data-original-title="501 Sales">
         <i class="fab fa-facebook-f"></i>
         </a>
         <a href="#" class="btn btn-social-icon mr-1 btn-twitter" data-toggle="tooltip" title="" data-original-title="267 Sales">
         <i class="fab fa-twitter"></i>
         </a>
         <a href="#" class="btn btn-social-icon mr-1 btn-instagram" data-toggle="tooltip" title="" data-original-title="308 Sales">
         <i class="fab fa-instagram"></i>
         </a>
         <div class="w-100 d-sm-none"></div>
         </div>
         </div>
         </div>
         </div>
         <div class=" col-lg-7 col-md-12 col-sm-12 d-flex">
         <div class="card p-5">
         <div class="card-header">
         <h4>Latest Transaction</h4>
         </div>
         <div class="card-body">
         <div class="table-responsive mt-1">
         <table class="table table-striped">
         <tr>
         <th>Order ID</th>
         <th>Billing Name</th>
         <th>Total</th>
         <th>Due Date</th>
         <th>Payment Status</th>
         <th>Action</th>
         </tr>
         <tr>
         <td>#TD1230</td>
         <td>John Mitchell</td>
         <td>150$</td>
         <td>2022-10-02</td>
         <td>
         <div class="badge badge-success badge-shadow">Paid</div>
         </td>
         <td>
         <div class="media-cta-square">
         <a href="#" class="btn btn-outline-primary">Detail</a>
         </div>
         </td>
         </tr>
         <tr>
         <td>#TD1231</td>
         <td>Henry Smith</td>
         <td>250$</td>
         <td>2022-10-08</td>
         <td>
         <div class="badge badge-info badge-shadow">Refund</div>
         </td>
         <td>
         <div class="media-cta-square">
         <a href="#" class="btn btn-outline-primary">Detail</a>
         </div>
         </td>
         </tr>
         <tr>
         <td>#TD1232</td>
         <td>Barry Hick</td>
         <td>350$</td>
         <td>2022-10-29</td>
         <td>
         <div class="badge badge-success badge-shadow">Paid</div>
         </td>
         <td>
         <div class="media-cta-square">
         <a href="#" class="btn btn-outline-primary">Detail</a>
         </div>
         </td>
         </tr>
         <tr>
         <td>#TD1233</td>
         <td>Ronald Taylor</td>
         <td>435$</td>
         <td>2022-11-02</td>
         <td>
         <div class="badge badge-danger badge-shadow">Chargeback</div>
         </td>
         <td>
         <div class="media-cta-square">
         <a href="#" class="btn btn-outline-primary">Detail</a>
         </div>
         </td>
         </tr>
         <tr>
         <td>#TD1234</td>
         <td>Ava Johnson</td>
         <td>220$</td>
         <td>2022-11-07</td>
         <td>
         <div class="badge badge-info badge-shadow">Refund</div>
         </td>
         <td>
         <div class="media-cta-square">
         <a href="#" class="btn btn-outline-primary">Detail</a>
         </div>
         </td>
         </tr>
         </table>
         </div>
         </div>
         </div>
         </div>
         </div>
         </section>
         <div class="settingSidebar">
         <a href="javascript:void(0)" class="settingPanelToggle"> <i
            class="fa fa-spin fa-cog"></i>
         </a>
         <div class="settingSidebar-body ps-container ps-theme-default">
         <div class=" fade show active">
         <div class="setting-panel-header">Theme Customizer</div>
         <div class="p-15 border-bottom">
         <h6 class="font-medium m-b-10">Theme Layout</h6>
         <div class="selectgroup layout-color w-50">
         <label> <span class="control-label p-r-20">Light</span>
         <input type="radio" name="custom-switch-input" value="1"
            class="custom-switch-input" checked> <span
            class="custom-switch-indicator"></span>
         </label>
         </div>
         <div class="selectgroup layout-color  w-50">
         <label> <span class="control-label p-r-20">Dark&nbsp;</span>
         <input type="radio" name="custom-switch-input" value="2"
            class="custom-switch-input"> <span
            class="custom-switch-indicator"></span>
         </label>
         </div>
         </div>
         </div>
         <div class="p-15 border-bottom">
         <h6 class="font-medium m-b-10">Sidebar Colors</h6>
         <div class="sidebar-setting-options">
         <ul class="sidebar-color list-unstyled mb-0">
         <li title="white" class="active">
         <div class="white"></div>
         </li>
         <li title="blue">
         <div class="blue"></div>
         </li>
         <li title="coral">
         <div class="coral"></div>
         </li>
         <li title="purple">
         <div class="purple"></div>
         </li>
         <li title="allports">
         <div class="allports"></div>
         </li>
         <li title="barossa">
         <div class="barossa"></div>
         </li>
         <li title="fancy">
         <div class="fancy"></div>
         </li>
         </ul>
         </div>
         </div>
         <div class="p-15 border-bottom">
         <h6 class="font-medium m-b-10">Theme Colors</h6>
         <div class="theme-setting-options">
         <ul class="choose-theme list-unstyled mb-0">
         <li title="white" class="active">
         <div class="white"></div>
         </li>
         <li title="blue">
         <div class="blue"></div>
         </li>
         <li title="coral">
         <div class="coral"></div>
         </li>
         <li title="purple">
         <div class="purple"></div>
         </li>
         <li title="allports">
         <div class="allports"></div>
         </li>
         <li title="barossa">
         <div class="barossa"></div>
         </li>
         <li title="fancy">
         <div class="fancy"></div>
         </li>
         <li title="cyan">
         <div class="cyan"></div>
         </li>
         <li title="orange">
         <div class="orange"></div>
         </li>
         <li title="green">
         <div class="green"></div>
         </li>
         <li title="red">
         <div class="red"></div>
         </li>
         </ul>
         </div>
         </div>
         <div class="p-15 border-bottom">
         <h6 class="font-medium m-b-10">Layout Options</h6>
         <div class="theme-setting-options">
         <label> <span class="control-label p-r-20">Compact
         Sidebar Menu</span> <input type="checkbox"
            name="custom-switch-checkbox" class="custom-switch-input"
            id="mini_sidebar_setting"> <span
            class="custom-switch-indicator"></span>
         </label>
         </div>
         </div>
         <div class="mt-3 mb-3 align-center">
         <a href="#"
            class="btn btn-icon icon-left btn-outline-primary btn-restore-theme">
         <i class="fas fa-undo"></i> Restore Default
         </a>
         </div>
         </div>
         </div>
         </div>
         <footer class="main-footer">
         <div class="footer-left">
         Copyright &copy; 2022 <div class="bullet"></div> Design By <a href="#">Snkthemes</a>
         </div>
         <div class="footer-right">
         </div>
         </footer>
         </div>
      </div>
      <!-- General JS Scripts -->
      <script src="assets/js/app.min.js"></script>
      <!-- JS Libraies -->
      <script src="assets/bundles/echart/echarts.js"></script>
      <script src="assets/bundles/chartjs/chart.min.js"></script>
      <script src="assets/bundles/apexcharts/apexcharts.min.js"></script>
      <!-- Page Specific JS File -->
      <script src="assets/js/page/index.js"></script>
      <!-- Template JS File -->
      <script src="assets/js/scripts.js"></script>
   </body>
</html>