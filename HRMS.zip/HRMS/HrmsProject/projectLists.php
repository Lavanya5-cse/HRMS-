<?php include("connection.php");?>
<?php
$pname=$_POST['pname'];
$open=$_POST['open']; 
$task=$_POST['task'];
$des=$_POST['des'];
$deadline=$_POST['deadline'];
$leads=$_POST['leads'];
$teams=$_POST['teams'];
$prog=$_POST['prog'];
 $mysql="Insert into projectlist values('$pname','$open','$task','$des','$deadline','$leads','$teams','$prog')";
if(mysqli_query($con,$mysql))
{
    header("Location:Project lists.php");
    exit();
}
else{
    echo "Error";
}
mysqli_close($con);
?>